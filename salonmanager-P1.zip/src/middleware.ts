import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { auth } from "@/auth"

export async function middleware(req: NextRequest) {
  const resHeaders = new Headers()
  const rid = req.headers.get("x-request-id") || crypto.randomUUID()
  resHeaders.set("x-request-id", rid)

  const session = await auth()

  const url = req.nextUrl

  const protectedPaths = [
    { prefix: "/owner", roles: ["OWNER", "ADMIN"] },
    { prefix: "/staff", roles: ["STAFF", "ADMIN"] },
    { prefix: "/me", roles: ["CUSTOMER", "ADMIN", "OWNER", "STAFF"] }
  ]

  for (const p of protectedPaths) {
    if (url.pathname.startsWith(p.prefix)) {
      if (!session?.user) return NextResponse.redirect(new URL("/login", url), { headers: resHeaders })
      const role = (session.user as any).role as string
      if (!p.roles.includes(role)) return NextResponse.redirect(new URL("/", url), { headers: resHeaders })
    }
  }
  const res = NextResponse.next({ headers: resHeaders })
  return res
}

export const config = {
  matcher: ["/owner/:path*", "/staff/:path*", "/me/:path*"]
}
