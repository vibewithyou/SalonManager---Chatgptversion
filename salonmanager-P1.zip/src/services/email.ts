import { Resend } from "resend"
import { enqueue } from "@/lib/jobs"
import { prisma } from "@/lib/prisma"

const resend = new Resend(process.env.RESEND_API_KEY)

export async function sendMail(to: string, subject: string, html: string) {
  // Queue nutzen, wenn Redis vorhanden; sonst synchron senden
  if (process.env.REDIS_URL) {
    await prisma.emailEvent.create({ data: { to, subject, status: "queued" } })
    await enqueue({ t: "email", to, subject, html })
    return
  }
  if (!process.env.RESEND_API_KEY) { console.warn("RESEND_API_KEY not set"); return }
  await resend.emails.send({ from: "SalonManager <noreply@mail.salonmanager.tld>", to, subject, html })
}
