import { NextResponse } from "next/server"
import { processBatch } from "@/lib/jobs"
import { Resend } from "resend"
import { revalidate } from "@/lib/revalidate"

export async function POST(req: Request) {
  const auth = req.headers.get("authorization") || ""
  if (auth !== `Bearer ${process.env.JOBS_SECRET}`) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const resend = new Resend(process.env.RESEND_API_KEY)

  const done = await processBatch(50, {
    email: async (j) => {
      if (!process.env.RESEND_API_KEY) throw new Error("RESEND_API_KEY missing")
      await resend.emails.send({ from: "SalonManager <noreply@mail.salonmanager.tld>", to: j.to, subject: j.subject, html: j.html })
    },
    revalidate: async (j) => {
      revalidate(j.tag)
    }
  })

  return NextResponse.json({ ok: true, processed: done })
}
