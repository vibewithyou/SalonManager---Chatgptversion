import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getRedis } from "@/lib/redis"

export async function GET() {
  const start = Date.now()
  let dbMs = -1, redisMs = -1
  try {
    const t0 = Date.now()
    await prisma.$queryRaw`SELECT 1`
    dbMs = Date.now() - t0
  } catch (e: any) {
    return NextResponse.json({ ok: false, db: { ok: false, error: String(e?.message ?? e) } }, { status: 500 })
  }

  const r = getRedis()
  if (r) {
    try {
      const t1 = Date.now()
      await r.ping()
      redisMs = Date.now() - t1
    } catch (e: any) {
      return NextResponse.json({ ok: false, db: { ok: true, ms: dbMs }, redis: { ok: false, error: String(e?.message ?? e) } }, { status: 500 })
    }
  }

  return NextResponse.json({
    ok: true,
    uptimeSec: Math.floor((process as any).uptime?.() ?? 0),
    db: { ok: true, ms: dbMs },
    redis: r ? { ok: true, ms: redisMs } : { ok: false, reason: "not-configured" },
    totalMs: Date.now() - start
  })
}
