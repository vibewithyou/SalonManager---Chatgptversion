import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { audit } from "@/lib/audit"

export async function POST(req: Request) {
  const evt = await req.json()
  // Optional: Signaturprüfung, falls verfügbar
  const type = evt.type as string
  const to: string | undefined = evt.data?.to || evt.data?.email

  if (!to) return NextResponse.json({ ok: true })
  if (type === "email.bounced" || type === "email.complained") {
    await prisma.emailSuppression.upsert({
      where: { email: to },
      update: { reason: type },
      create: { email: to, reason: type }
    })
    await prisma.emailEvent.create({ data: { to, subject: evt.data?.subject ?? "", status: type } })
    await audit({ action: "EMAIL_SUPPRESS", entity: `Email:${to}`, meta: { type } })
  }
  return NextResponse.json({ ok: true })
}
