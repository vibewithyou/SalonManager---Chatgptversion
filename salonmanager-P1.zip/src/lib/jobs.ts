import { getRedis } from "./redis"
import { prisma } from "@/lib/prisma"

type Job =
  | { t: "email"; to: string; subject: string; html: string }
  | { t: "revalidate"; tag: string }

const QUEUE_KEY = "queue:jobs"

export async function enqueue(job: Job) {
  const r = getRedis()
  if (!r) throw new Error("Redis not configured")
  await r.rpush(QUEUE_KEY, JSON.stringify(job))
}

export async function processOne(handler?: Partial<{
  email: (job: Extract<Job, {t:"email"}>) => Promise<void>,
  revalidate: (job: Extract<Job, {t:"revalidate"}>) => Promise<void>
}>) {
  const r = getRedis()
  if (!r) return 0
  const data = await r.lpop(QUEUE_KEY)
  if (!data) return 0
  const job: Job = JSON.parse(data)

  try {
    if (job.t === "email") {
      // Skip if suppressed
      const sup = await prisma.emailSuppression.findUnique({ where: { email: job.to } })
      if (!sup) await handler?.email?.(job)
      await prisma.emailEvent.create({ data: { to: job.to, subject: job.subject, status: "sent" } })
    } else if (job.t === "revalidate") {
      await handler?.revalidate?.(job)
    }
  } catch (e: any) {
    if (job.t === "email") {
      await prisma.emailEvent.create({
        data: { to: job.to, subject: job.subject, status: "error", error: String(e?.message ?? e) }
      })
    }
  }
  return 1
}

export async function processBatch(n = 25, handler?: Parameters<typeof processOne>[0]) {
  let done = 0
  for (let i = 0; i < n; i++) {
    const r = await processOne(handler)
    if (!r) break
    done += r
  }
  return done
}
