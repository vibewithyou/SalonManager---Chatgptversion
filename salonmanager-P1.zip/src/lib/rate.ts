import { getRedis } from "./redis"

/**
 * Verteiltes Rate-Limit pro (ip,key). Sliding Window via ZSET.
 * windowMs: Fenstergröße; limit: max Events im Fenster.
 */
export async function rateLimit(ip: string, key: string, limit = 20, windowMs = 60_000) {
  const r = getRedis()
  if (!r) {
    // Fallback: kein Redis konfiguriert -> großzügig erlauben
    return true
  }
  const now = Date.now()
  const k = `ratelimit:${key}:${ip}`
  const tx = r.multi()
  // drop alte Einträge, add neuen, zähle
  tx.zremrangebyscore(k, 0, now - windowMs)
  tx.zadd(k, now, String(now))
  tx.zcard(k)
  tx.pexpire(k, windowMs)
  const [, , count] = (await tx.exec()) as [any, any, [null, number], any]
  return (count?.[1] ?? count) <= limit
}
