import Redis from "ioredis"

let client: any = null

export function getRedis() {
  if (!process.env.REDIS_URL) return null
  if (!client) client = new Redis(process.env.REDIS_URL, { lazyConnect: true, maxRetriesPerRequest: 2 })
  return client
}
