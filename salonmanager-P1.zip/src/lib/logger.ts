export function log(event: string, meta: Record<string, any> = {}) {
  const rid = (meta.rid as string) || (typeof window === "undefined" ? process.env.REQUEST_ID : undefined)
  const payload = { ts: new Date().toISOString(), event, ...meta, rid }
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(payload))
}
