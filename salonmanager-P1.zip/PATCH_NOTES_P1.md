# Phase P1 Patch Notes (Reliability & Ops)

This folder contains **only the new/updated files** for Phase P1:
- Redis client, distributed rate limit (sliding window)
- Job queue & worker (emails + revalidate)
- Resend webhook (bounces/complaints -> suppressions)
- Request-ID header in middleware, JSON logger, optional Sentry init
- Extended health endpoint (DB/Redis latency)
- Optional Vercel cron config
- Snippets for package.json/.env/prisma additions

## Apply in your repo
- Merge files under `src/` into your project.
- Add the snippets from `snippets/` to your existing files.
- Run `pnpm add ioredis @sentry/nextjs` and set env vars from the snippet.
- Run `pnpm prisma:generate && pnpm prisma:migrate` after updating the Prisma schema.

## Touch points
- Use `rateLimit(ip, "key", limit, windowMs)` in critical API routes.
- Use `enqueue({ t: "revalidate", tag: "salons" })` after mutations affecting public pages.
- Configure Resend webhook to `/api/webhooks/resend`.
- Schedule the worker (`/api/jobs/worker`) with `Authorization: Bearer $JOBS_SECRET`.
