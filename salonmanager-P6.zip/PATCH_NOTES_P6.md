# Phase P6 — Apply Notes

## 1) ENV
Add to `.env` (or set in hosting provider):
```
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URL=https://your.app/api/integrations/google/callback
GOOGLE_SCOPES=https://www.googleapis.com/auth/calendar
```

## 2) Prisma
- Insert the models from `prisma/schema.P6.patch.prisma` into your existing `schema.prisma`.
- Add `externalEventId String?` to `Booking` (plus optional index).
- Run:
  ```bash
  pnpm prisma:generate && pnpm prisma:migrate
  ```

## 3) Install deps
```bash
pnpm add googleapis
```

## 4) CSP
In `next.config.js` CSP `connect-src` add:
`https://www.googleapis.com https://accounts.google.com`

## 5) Worker
We placed full `src/app/api/jobs/worker/route.ts` with:
- recurring expander call
- email / revalidate / gcalSync handlers

## 6) Jobs
Replace your `src/lib/jobs.ts` with the provided version (adds `gcalSync` type).

## 7) Booking enqueue
Enqueue Google sync:
- In `POST /api/bookings` after create:
  ```ts
  import { enqueue } from "@/lib/jobs"
  await enqueue({ t: "gcalSync", bookingId: created.id })
  ```
- In `PATCH /api/bookings/[id]` after update:
  ```ts
  await enqueue({ t: "gcalSync", bookingId: booking.id })
  ```

## 8) ICS tokens & feeds
- New: `src/app/api/ical/token/route.ts`
- Replace Salon & Staff ICS routes to require `?t=<token>`
- UI example under `/owner/integrations`

## 9) Recurring schedules
- New APIs under `src/app/api/staff/recurring/...`
- New UI under `/staff/schedule/recurring`
- Expander job file at `src/lib/recurring-expander.ts`

## 10) Google OAuth
- Start connect: `/api/integrations/google/auth`
- Callback persists tokens: `/api/integrations/google/callback`
- Helper: `src/services/google.ts`

## 11) Navigation (manual)
- Link Owner menu -> `/owner/integrations`
- Link Staff schedule menu -> `/staff/schedule/recurring`
- In Staff Agenda header, consider a link to `/api/integrations/google/auth`

## 12) Rebuild
```bash
pnpm build && pnpm start
```
