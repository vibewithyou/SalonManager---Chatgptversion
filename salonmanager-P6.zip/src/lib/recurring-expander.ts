import { prisma } from "@/lib/prisma"
import { DateTime } from "luxon"

export async function expandRecurringWeeks(weeks = 8) {
  const rules = await prisma.recurringSchedule.findMany({ where: { isActive: true } })
  const now = DateTime.utc()
  const horizonEnd = now.plus({ weeks })
  for (const r of rules) {
    const from = DateTime.fromJSDate(r.validFrom)
    const to = r.validTo ? DateTime.fromJSDate(r.validTo) : horizonEnd
    let cursor = (from < now ? now : from).startOf("week")
    while (cursor < horizonEnd && cursor < to) {
      const weeksFromStart = Math.floor(cursor.diff(from.startOf("week"), "weeks").weeks)
      if (weeksFromStart % r.repeatEvery === 0) {
        const day = cursor.plus({ days: r.weekday })
        const [sh, sm] = r.startTime.split(":").map(Number)
        const [eh, em] = r.endTime.split(":").map(Number)
        const start = day.set({ hour: sh, minute: sm }).toJSDate()
        const end = day.set({ hour: eh, minute: em }).toJSDate()
        const exists = await prisma.schedule.findFirst({ where: { staffId: r.staffId, start, end } })
        if (!exists) {
          await prisma.schedule.create({ data: { staffId: r.staffId, start, end, isAvailable: true } })
        }
      }
      cursor = cursor.plus({ weeks: 1 })
    }
  }
}
