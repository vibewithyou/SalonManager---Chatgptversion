"use client"

import useSWR from "swr"
import { useState } from "react"
const fetcher = (u: string) => fetch(u).then(r=>r.json())

export default function RecurringPage() {
  const { data, mutate } = useSWR("/api/staff/recurring", fetcher)
  const [form, setForm] = useState({ weekday: 1, startTime: "09:00", endTime: "17:00", repeatEvery: 1, validFrom: new Date().toISOString().slice(0,16), validTo: "" })

  async function add() {
    const body = { ...form, validFrom: new Date(form.validFrom).toISOString(), validTo: form.validTo ? new Date(form.validTo).toISOString() : null }
    await fetch("/api/staff/recurring", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body) })
    mutate()
  }
  async function del(id: string) {
    await fetch(`/api/staff/recurring/${id}`, { method:"DELETE" })
    mutate()
  }

  return (
    <div className="grid gap-4 max-w-2xl">
      <h1 className="text-2xl font-semibold text-gold">Serien-Verfügbarkeiten</h1>
      <div className="card grid grid-cols-2 md:grid-cols-6 gap-2 items-end">
        <select className="input" value={form.weekday} onChange={e=>setForm(f=>({...f, weekday: Number(e.target.value)}))}>
          {["So","Mo","Di","Mi","Do","Fr","Sa"].map((d,i)=><option key={i} value={i}>{d}</option>)}
        </select>
        <input className="input" type="time" value={form.startTime} onChange={e=>setForm(f=>({...f, startTime: e.target.value}))}/>
        <input className="input" type="time" value={form.endTime} onChange={e=>setForm(f=>({...f, endTime: e.target.value}))}/>
        <input className="input" type="number" min={1} max={8} value={form.repeatEvery} onChange={e=>setForm(f=>({...f, repeatEvery: Number(e.target.value)}))}/>
        <input className="input" type="datetime-local" value={form.validFrom} onChange={e=>setForm(f=>({...f, validFrom: e.target.value}))}/>
        <input className="input" type="datetime-local" value={form.validTo} onChange={e=>setForm(f=>({...f, validTo: e.target.value}))}/>
        <button className="btn md:col-span-6" onClick={add}>Regel hinzufügen</button>
      </div>

      <div className="grid gap-2">
        {(data ?? []).map((r: any)=>(
          <div key={r.id} className="card flex items-center justify-between text-sm">
            <div>{["So","Mo","Di","Mi","Do","Fr","Sa"][r.weekday]} · {r.startTime}–{r.endTime} · alle {r.repeatEvery} Woche(n)</div>
            <button className="underline hover:text-gold" onClick={()=>del(r.id)}>Löschen</button>
          </div>
        ))}
      </div>
    </div>
  )
}
