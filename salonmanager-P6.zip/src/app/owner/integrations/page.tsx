"use client"

import useSWR from "swr"
const fetcher = (u: string) => fetch(u).then(r=>r.json())

export default function Integrations() {
  const { data, mutate } = useSWR("/api/ical/token", fetcher)

  async function revoke(t: string) {
    await fetch("/api/ical/token", { method:"DELETE", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ token: t }) })
    mutate()
  }

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Integrationen</h1>
      <div className="card">
        <h2 className="font-medium mb-2">ICS Tokens</h2>
        <p className="text-sm text-muted mb-3">Nutze Tokens als <code>?t=TOKEN</code> in den ICS-URLs (Salon & Staff).</p>
        <div className="grid gap-2">
          {(data ?? []).map((t: any)=>(
            <div key={t.token} className="flex items-center justify-between text-sm border border-border rounded p-2">
              <div>{t.type} • {t.salonId ?? t.staffId} • last used: {t.lastUsedAt ? new Date(t.lastUsedAt).toLocaleString() : "—"}</div>
              <button className="underline hover:text-gold" onClick={()=>revoke(t.token)}>Revoke</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
