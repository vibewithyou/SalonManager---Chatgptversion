import { NextResponse } from "next/server"
import { exchangeCode } from "@/services/google"
import { auth } from "@/auth"

export async function GET(req: Request) {
  const session = await auth()
  if (!session?.user) return NextResponse.redirect(new URL("/", process.env.NEXTAUTH_URL))
  const code = new URL(req.url).searchParams.get("code")
  if (!code) return NextResponse.redirect(new URL("/", process.env.NEXTAUTH_URL))
  await exchangeCode((session.user as any).id, code)
  return NextResponse.redirect(new URL("/staff/agenda", process.env.NEXTAUTH_URL))
}
