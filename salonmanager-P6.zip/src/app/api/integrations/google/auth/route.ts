import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import { getAuthUrl } from "@/services/google"

export async function GET() {
  await getSessionOrThrow()
  const url = getAuthUrl()
  return NextResponse.redirect(url)
}
