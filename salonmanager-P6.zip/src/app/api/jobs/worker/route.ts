import { NextResponse } from "next/server"
import { processBatch } from "@/lib/jobs"
import { Resend } from "resend"
import { revalidate } from "@/lib/revalidate"
import { prisma } from "@/lib/prisma"
import { getAuthedCalendar } from "@/services/google"
import { expandRecurringWeeks } from "@/lib/recurring-expander"

export async function POST(req: Request) {
  const auth = req.headers.get("authorization") || ""
  if (auth !== `Bearer ${process.env.JOBS_SECRET}`) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const resend = new Resend(process.env.RESEND_API_KEY)

  // Expand recurring schedules into concrete Schedule rows (next 8 weeks)
  await expandRecurringWeeks(8)

  const done = await processBatch(50, {
    email: async (j) => {
      if (!process.env.RESEND_API_KEY) throw new Error("RESEND_API_KEY missing")
      await resend.emails.send({ from: "SalonManager <noreply@mail.salonmanager.tld>", to: j.to, subject: j.subject, html: j.html })
    },
    revalidate: async (j) => { revalidate(j.tag) },
    gcalSync: async (j) => {
      const b = await prisma.booking.findUnique({
        where: { id: j.bookingId },
        include: { salon: true, service: true, staff: { include: { user: true } } }
      })
      if (!b || !b.staff?.user) return
      const gc = await getAuthedCalendar(b.staff.userId)
      if (!gc) return
      const { cal, calendarId } = gc
      const evt = {
        summary: `${b.service.name} – ${b.salon.name}`,
        description: b.note || "",
        start: { dateTime: b.start.toISOString() },
        end: { dateTime: b.end.toISOString() },
        location: `${b.salon.address}, ${b.salon.postalCode} ${b.salon.city}`
      }
      if (b.status === "CANCELLED" || b.status === "DECLINED") {
        if (b.externalEventId) {
          try { await (cal.events as any).delete({ calendarId, eventId: b.externalEventId }) } catch {}
          await prisma.booking.update({ where: { id: b.id }, data: { externalEventId: null } })
        }
        return
      }
      if (b.externalEventId) {
        const res = await cal.events.update({ calendarId, eventId: b.externalEventId, requestBody: evt })
        await prisma.booking.update({ where: { id: b.id }, data: { externalEventId: (res.data as any).id || b.externalEventId } })
      } else {
        const res = await cal.events.insert({ calendarId, requestBody: evt })
        await prisma.booking.update({ where: { id: b.id }, data: { externalEventId: (res.data as any).id || undefined } })
      }
    }
  })

  return NextResponse.json({ ok: true, processed: done })
}
