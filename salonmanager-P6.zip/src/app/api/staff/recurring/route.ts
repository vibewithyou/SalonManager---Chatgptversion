import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, getStaffProfileForUser } from "@/lib/user"
import { z } from "zod"

const ruleSchema = z.object({
  weekday: z.number().int().min(0).max(6),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  endTime: z.string().regex(/^\d{2}:\d{2}$/),
  repeatEvery: z.number().int().min(1).max(8).default(1),
  validFrom: z.string().datetime(),
  validTo: z.string().datetime().nullable().optional()
})

export async function GET() {
  const session = await getSessionOrThrow()
  const staff = await getStaffProfileForUser((session.user as any).id)
  if (!staff) return NextResponse.json([])
  const rules = await prisma.recurringSchedule.findMany({ where: { staffId: staff.id }, orderBy: { createdAt: "desc" } })
  return NextResponse.json(rules)
}

export async function POST(req: Request) {
  const session = await getSessionOrThrow()
  const staff = await getStaffProfileForUser((session.user as any).id)
  if (!staff) return NextResponse.json({ error: "No staff" }, { status: 403 })
  const input = ruleSchema.parse(await req.json())
  const created = await prisma.recurringSchedule.create({ data: { ...input, staffId: staff.id } })
  return NextResponse.json(created, { status: 201 })
}
