import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, getStaffProfileForUser } from "@/lib/user"

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const staff = await getStaffProfileForUser((session.user as any).id)
  if (!staff) return NextResponse.json({ error: "No staff" }, { status: 403 })
  const rule = await prisma.recurringSchedule.findUnique({ where: { id: params.id } })
  if (!rule || rule.staffId !== staff.id) return NextResponse.json({ error: "Not found" }, { status: 404 })
  await prisma.recurringSchedule.delete({ where: { id: params.id } })
  return NextResponse.json({ ok: true })
}
