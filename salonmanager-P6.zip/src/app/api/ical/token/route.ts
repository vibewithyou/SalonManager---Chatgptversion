import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow } from "@/lib/user"
import crypto from "crypto"

export async function GET() {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const staff = await prisma.staffProfile.findMany({ where: { userId }, select: { id: true, salonId: true } })
  const tokens = await prisma.icsToken.findMany({
    where: {
      OR: [
        { staffId: { in: staff.map(s => s.id) } },
        { salonId: { in: staff.map(s => s.salonId) }, type: "SALON" }
      ]
    },
    orderBy: { createdAt: "desc" }
  })
  return NextResponse.json(tokens)
}

export async function POST(req: Request) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const { type, salonId, staffId } = await req.json() as { type: "SALON"|"STAFF"; salonId?: string; staffId?: string }
  if (type === "SALON") {
    if (!salonId) return NextResponse.json({ error: "salonId required" }, { status: 400 })
  } else {
    if (!staffId) return NextResponse.json({ error: "staffId required" }, { status: 400 })
  }
  const token = crypto.randomBytes(24).toString("hex")
  const created = await prisma.icsToken.create({ data: { token, type, salonId, staffId, createdBy: userId } })
  return NextResponse.json(created, { status: 201 })
}

export async function DELETE(req: Request) {
  await getSessionOrThrow()
  const { token } = await req.json() as { token: string }
  await prisma.icsToken.delete({ where: { token } })
  return NextResponse.json({ ok: true })
}
