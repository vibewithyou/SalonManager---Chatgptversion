import { google } from "googleapis"
import { prisma } from "@/lib/prisma"

function getOAuth2Client() {
  const client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URL
  )
  return client
}

export function getAuthUrl() {
  const client = getOAuth2Client()
  const scopes = (process.env.GOOGLE_SCOPES || "https://www.googleapis.com/auth/calendar").split(",")
  return client.generateAuthUrl({ access_type: "offline", prompt: "consent", scope: scopes })
}

export async function exchangeCode(userId: string, code: string) {
  const client = getOAuth2Client()
  const { tokens } = await client.getToken(code)
  if (!tokens.refresh_token || !tokens.access_token) throw new Error("Missing tokens")
  await prisma.googleAccount.upsert({
    where: { userId },
    create: {
      userId,
      accessToken: tokens.access_token!,
      refreshToken: tokens.refresh_token!,
      expiryDate: BigInt(tokens.expiry_date || Date.now() + 3_600_000)
    },
    update: {
      accessToken: tokens.access_token!,
      refreshToken: tokens.refresh_token!,
      expiryDate: BigInt(tokens.expiry_date || Date.now() + 3_600_000)
    }
  })
}

export async function getAuthedCalendar(userId: string) {
  const ga = await prisma.googleAccount.findUnique({ where: { userId } })
  if (!ga) return null
  const client = getOAuth2Client()
  client.setCredentials({
    access_token: ga.accessToken,
    refresh_token: ga.refreshToken,
    expiry_date: Number(ga.expiryDate)
  })
  const cal = google.calendar({ version: "v3", auth: client })
  const calendarId = ga.calendarId || "primary"
  return { cal, calendarId }
}
