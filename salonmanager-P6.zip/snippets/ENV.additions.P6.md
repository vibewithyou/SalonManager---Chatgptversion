# Phase P6 — ENV additions
GOOGLE_CLIENT_ID="..."
GOOGLE_CLIENT_SECRET="..."
GOOGLE_REDIRECT_URL="https://your.app/api/integrations/google/callback"
GOOGLE_SCOPES="https://www.googleapis.com/auth/calendar"
