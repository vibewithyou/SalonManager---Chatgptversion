import { test, expect } from "@playwright/test"

test("cancellation blocked within policy window", async ({ page }) => {
  await page.goto("/login")
  await page.getByPlaceholder(/E-Mail/i).fill("customer@demo.tld")
  await page.getByPlaceholder(/Passwort/i).fill("Customer123!")
  await page.getByRole("button", { name: /Einloggen/i }).click()

  await page.goto("/me/bookings")
  const first = page.locator("[data-test=booking-item]").first()
  await first.waitFor()
  const id = await first.getAttribute("data-id")

  const resp = await page.request.post(`/api/bookings/${id}/cancel`)
  expect([200, 422]).toContain(resp.status())
})
