import { test, expect } from "@playwright/test"

test("staff cannot create confirmed overlap (409)", async ({ page, request }) => {
  await page.goto("/login")
  await page.getByPlaceholder(/E-Mail/i).fill("staff1@demo.tld")
  await page.getByPlaceholder(/Passwort/i).fill("Staff123!")
  await page.getByRole("button", { name: /Einloggen/i }).click()

  // Simulated PATCH to demonstrate guard expectations
  const resp = await request.patch(`/api/bookings/booking_fake`, { data: { status: "CONFIRMED" } })
  expect([404,409,403]).toContain(resp.status())
})
