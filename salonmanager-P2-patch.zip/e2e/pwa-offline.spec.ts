import { test, expect } from "@playwright/test"

test("offline: / and /me/bookings (read-only) render shell", async ({ context, page }) => {
  await page.goto("/")
  await context.setOffline(true)
  await page.goto("/")
  await expect(page.getByText(/SalonManager/i)).toBeVisible()
  await page.goto("/me/bookings")
  await expect(page.getByText(/Buchungen/i)).toBeVisible()
  await context.setOffline(false)
})
