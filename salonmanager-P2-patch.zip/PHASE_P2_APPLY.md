# PHASE P2 – Apply Guide

## 1) package.json
Add devDeps and scripts:
```jsonc
{
  "devDependencies": {
    "@axe-core/playwright": "^4.9.0",
    "@testing-library/jest-dom": "^6.6.3",
    "@testing-library/react": "^16.0.0",
    "jsdom": "^24.1.0"
  },
  "scripts": {
    "test:unit": "vitest run",
    "test:e2e": "playwright test",
    "test:a11y": "playwright test e2e/a11y.spec.ts",
    "test:all": "pnpm -s test:unit && pnpm -s test:e2e"
  }
}
```

## 2) Global A11y
In `src/app/globals.css` add:
```css
:focus-visible { outline: 2px solid #D4AF37; outline-offset: 2px; }
.sr-only { position:absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0,0,0,0); white-space:nowrap; border:0; }
```

In `src/app/layout.tsx` near `<body>`:
```tsx
<a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 bg-black text-gold px-3 py-2 rounded">Zum Inhalt springen</a>
<main id="main">{/* wrap your page content */}</main>
```

Add live region (if not present) in your Toast provider:
```tsx
<div aria-live="polite" aria-atomic="true" className="sr-only" id="toast-live-region" />
```

## 3) New components
- `src/components/Empty.tsx`
- `src/components/Skeleton.tsx`
- `src/components/Tabs.tsx` (keyboard-navigation)

## 4) Tests
- E2E: `e2e/a11y.spec.ts`, `e2e/pwa-offline.spec.ts`, `e2e/cancel-policy.spec.ts`, `e2e/booking-overlap.spec.ts`
- Unit: `src/lib/availability.edge.test.ts`, `src/lib/flags.test.ts`

Run:
```bash
pnpm -s test:all
```

## 5) Example usage
Skeletons:
```tsx
{!data && <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
  {Array.from({length:6}).map((_,i)=> <Skeleton key={i} className="h-24" />)}
</div>}
```

Empty states:
```tsx
{data && salons.length===0 && <Empty title="Keine Ergebnisse" hint="Passe deine Filter an." />}
```

Tabs:
```tsx
<Tabs tabs={[
  { id: "t1", label: "Übersicht", content: <Overview/> },
  { id: "t2", label: "Termine", content: <Appointments/> },
]} />
```
