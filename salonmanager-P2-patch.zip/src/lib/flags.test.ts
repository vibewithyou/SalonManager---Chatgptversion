import { describe, it, expect, vi } from "vitest"
import * as mod from "./flags"

describe("evalFlag rollout basics", () => {
  it("returns false when base flag is off", async () => {
    vi.spyOn(mod, "getFlag" as any).mockResolvedValue(false as any)
    // @ts-ignore
    mod.prisma = { flagRule: { findMany: async () => [] } }
    const v = await mod.evalFlag("ui.x", { userId: "u1" })
    expect(v).toBe(false)
  })
})
