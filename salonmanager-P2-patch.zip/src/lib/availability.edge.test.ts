import { describe, it, expect } from "vitest"
import { DateTime } from "luxon"

describe("DST edges Europe/Berlin", () => {
  it("spring forward skips hour", () => {
    const tz = "Europe/Berlin"
    const d = DateTime.fromISO("2025-03-30T02:15", { zone: tz })
    expect(d.hour).toBe(3)
  })
  it("fall back repeats hour distinct by offset", () => {
    const tz = "Europe/Berlin"
    const first = DateTime.fromISO("2025-10-26T02:30:00+02:00", { zone: tz })
    const second = DateTime.fromISO("2025-10-26T02:30:00+01:00", { zone: tz })
    expect(second.toMillis() - first.toMillis()).toBe(3600_000)
  })
})
