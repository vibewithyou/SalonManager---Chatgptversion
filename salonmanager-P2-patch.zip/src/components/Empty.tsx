export function Empty({ title = "Keine Daten", hint }: { title?: string; hint?: string }) {
  return (
    <div className="border border-border rounded p-6 text-center text-muted">
      <div className="font-medium text-base mb-1">{title}</div>
      {hint && <div className="text-sm">{hint}</div>}
    </div>
  )
}
