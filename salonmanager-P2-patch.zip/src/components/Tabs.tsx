"use client"
import { useId, useRef, useState } from "react"

export function Tabs({ tabs, initial = 0, onChange }: {
  tabs: { id: string; label: string; content: React.ReactNode }[]
  initial?: number
  onChange?: (idx: number) => void
}) {
  const [active, setActive] = useState(initial)
  const ref = useRef<Array<HTMLButtonElement|null>>([])
  const panelId = useId()
  return (
    <div>
      <div role="tablist" aria-label="Abschnitte" className="flex gap-2 border-b border-border">
        {tabs.map((t, i) => (
          <button
            key={t.id}
            id={t.id}
            ref={el => (ref.current[i] = el)}
            role="tab"
            aria-selected={active === i}
            aria-controls={`${panelId}-${i}`}
            tabIndex={active === i ? 0 : -1}
            className={`px-3 py-2 ${active===i ? "text-gold border-b-2 border-gold" : "text-muted"}`}
            onClick={() => { setActive(i); onChange?.(i) }}
            onKeyDown={(e) => {
              if (e.key === "ArrowRight") { e.preventDefault(); const n = (i+1)%tabs.length; setActive(n); ref.current[n]?.focus() }
              if (e.key === "ArrowLeft") { e.preventDefault(); const p = (i-1+tabs.length)%tabs.length; setActive(p); ref.current[p]?.focus() }
            }}
          >
            {t.label}
          </button>
        ))}
      </div>
      {tabs.map((t, i) => (
        <div key={t.id} role="tabpanel" id={`${panelId}-${i}`} aria-labelledby={t.id} hidden={active!==i} className="pt-3">
          {t.content}
        </div>
      ))}
    </div>
  )
}
