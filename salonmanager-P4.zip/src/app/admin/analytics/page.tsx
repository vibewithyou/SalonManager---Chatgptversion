import { auth } from "@/auth"
import { analyticsRange } from "@/lib/metrics"

function toISODate(d: Date) { return d.toISOString().slice(0,10) }

export default async function AdminAnalytics({ searchParams }: { searchParams: { from?: string; to?: string } }) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return <div className="card">Forbidden</div>

  const to = searchParams.to ? new Date(searchParams.to + "T23:59:59Z") : new Date()
  const from = searchParams.from ? new Date(searchParams.from + "T00:00:00Z") : new Date(Date.now() - 7*24*60*60*1000)

  const a = await analyticsRange(from, to)

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-gold">Analytics</h1>
      <form className="card flex items-end gap-3 w-max" method="get">
        <div>
          <label className="text-sm">Von</label>
          <input className="input" type="date" name="from" defaultValue={toISODate(from)} />
        </div>
        <div>
          <label className="text-sm">Bis</label>
          <input className="input" type="date" name="to" defaultValue={toISODate(to)} />
        </div>
        <button className="btn" type="submit">Anwenden</button>
      </form>
      <section className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <div className="card"><div className="text-sm text-muted">Anfragen</div><div className="text-2xl">{a.reqCount}</div></div>
        <div className="card"><div className="text-sm text-muted">Bestätigt</div><div className="text-2xl">{a.confCount}</div></div>
        <div className="card"><div className="text-sm text-muted">Conversion</div><div className="text-2xl">{(a.conversion*100).toFixed(1)}%</div></div>
        <div className="card"><div className="text-sm text-muted">Gebuchte Minuten</div><div className="text-2xl">{Math.round(a.minutesBooked)}</div></div>
        <div className="card"><div className="text-sm text-muted">Verfügbare Minuten</div><div className="text-2xl">{Math.round(a.minutesAvail)}</div></div>
        <div className="card"><div className="text-sm text-muted">Auslastung</div><div className="text-2xl">{(a.utilization*100).toFixed(1)}%</div></div>
      </section>
    </div>
  )
}
