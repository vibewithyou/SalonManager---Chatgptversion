import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { bookingCreateSchema } from "@/lib/validators"
import { requireUser } from "@/lib/auth-helpers"
import { sendMail } from "@/services/email"
import { bookingRequestTemplate } from "@/services/email-templates"

export async function POST(req: Request) {
  const session = await requireUser()
  const body = bookingCreateSchema.parse(await req.json())

  const svc = await prisma.service.findUnique({ where: { id: body.serviceId }, include: { salon: true } })
  if (!svc) return NextResponse.json({ error: "Service not found" }, { status: 404 })
  if (svc.salonId !== body.salonId) return NextResponse.json({ error: "Mismatch" }, { status: 400 })

  const end = new Date(new Date(body.start).getTime() + svc.durationMin * 60000)

  const created = await prisma.$transaction(async (tx) => {
    const newBooking = await tx.booking.create({
      data: {
        salonId: body.salonId,
        serviceId: body.serviceId,
        customerId: (session.user as any).id,
        start: body.start,
        end,
        note: body.note,
        imageUrl: body.imageUrl
      }
    })
    return newBooking
  })

  if (svc.salon.email) {
    const when = new Date(body.start).toLocaleString()
    await sendMail(svc.salon.email, "Neue Buchungsanfrage",
      bookingRequestTemplate(svc.salon.name, svc.name, when)
    )
  }
  return NextResponse.json(created, { status: 201 })
}
