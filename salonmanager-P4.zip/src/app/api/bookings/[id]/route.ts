import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { bookingPatchSchema } from "@/lib/validators"
import { getSessionOrThrow, getStaffProfileForUser, isOwnerOfSalon } from "@/lib/user"
import { sendMail } from "@/services/email"
import { bookingStatusTemplate } from "@/services/email-templates"

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const role = (session.user as any).role as "ADMIN"|"OWNER"|"STAFF"|"CUSTOMER"

  const booking = await prisma.booking.findUnique({
    where: { id: params.id },
    include: { salon: true, customer: true, service: true }
  })
  if (!booking) return NextResponse.json({ error: "Not found" }, { status: 404 })

  let allowed = false
  if (role === "ADMIN") allowed = true
  else if (role === "OWNER") allowed = await isOwnerOfSalon(userId, booking.salonId)
  else if (role === "STAFF") {
    const staff = await getStaffProfileForUser(userId)
    if (staff && staff.salonId === booking.salonId) allowed = !booking.staffId || booking.staffId === staff.id
  }
  if (!allowed) return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const data = bookingPatchSchema.parse(await req.json())

  // start/end: Ende neu berechnen, wenn nicht gesetzt
  let patch: any = { ...data }
  if (data.start && !data.end) {
    const svc = await prisma.service.findUnique({ where: { id: booking.serviceId } })
    if (svc) patch.end = new Date(data.start.getTime() + svc.durationMin * 60000)
  }

  try {
    const updated = await prisma.booking.update({ where: { id: params.id }, data: patch })
    if (data.status && booking.customer.email) {
      await sendMail(booking.customer.email, `Buchung ${data.status.toLowerCase()}`, bookingStatusTemplate(data.status))
    }
    return NextResponse.json(updated)
  } catch (e: any) {
    if (typeof e?.message === "string" && e.message.includes("booking_no_overlap_per_staff")) {
      return NextResponse.json({ error: "Overlap with another confirmed booking for this staff" }, { status: 409 })
    }
    return NextResponse.json({ error: "Update failed" }, { status: 400 })
  }
}
