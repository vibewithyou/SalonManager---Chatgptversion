import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { serviceSchema } from "@/lib/validators"
import { getSessionOrThrow, isOwnerOfSalon } from "@/lib/user"

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  if (!await isOwnerOfSalon(userId, params.id)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const body = await req.json()
  const data = serviceSchema.parse({ ...body, salonId: params.id })
  const created = await prisma.service.create({ data })
  return NextResponse.json(created, { status: 201 })
}
