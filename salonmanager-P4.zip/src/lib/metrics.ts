import { PrismaClient } from "@prisma/client"
const prisma = new PrismaClient()

export async function analyticsRange(from: Date, to: Date) {
  const [reqCount, confCount] = await Promise.all([
    prisma.booking.count({ where: { createdAt: { gte: from, lte: to } } }),
    prisma.booking.count({ where: { status: "CONFIRMED", createdAt: { gte: from, lte: to } } })
  ])
  const conversion = reqCount ? (confCount / reqCount) : 0

  const confirmed = await prisma.booking.findMany({
    where: { status: "CONFIRMED", start: { gte: from }, end: { lte: to } },
    select: { start: true, end: true, salonId: true }
  })
  const minutesBooked = confirmed.reduce((acc, b) => acc + Math.max(0, (b.end.getTime() - b.start.getTime()) / 60000), 0)

  const schedules = await prisma.schedule.findMany({
    where: { start: { lte: to }, end: { gte: from }, isAvailable: true },
    select: { start: true, end: true, staffId: true }
  })
  const minutesAvail = schedules.reduce((acc, s) => {
    const start = Math.max(s.start.getTime(), from.getTime())
    const end = Math.min(s.end.getTime(), to.getTime())
    return acc + Math.max(0, (end - start) / 60000)
  }, 0)

  const utilization = minutesAvail ? (minutesBooked / minutesAvail) : 0

  return { reqCount, confCount, conversion, minutesBooked, minutesAvail, utilization }
}
