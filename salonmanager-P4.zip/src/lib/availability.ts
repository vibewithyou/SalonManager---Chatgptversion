import { PrismaClient } from "@prisma/client"
import { DateTime, Interval } from "luxon"

const prisma = new PrismaClient()

// Parse "HH:MM" to minutes
const hm = (s: string) => {
  const [h, m] = s.split(":").map(Number)
  return h * 60 + m
}
export const _hm = hm

export function _overlap(a: {start: Date; end: Date}, b: {start: Date; end: Date}) {
  return !(a.end <= b.start || a.start >= b.end)
}

type Slot = { start: Date; end: Date; staffId: string }

/**
 * Liefert freie Slots in Salon-TZ unter Berücksichtigung:
 * - OpeningHours (lokale Zeiten)
 * - Staff-Schedules (UTC gespeichert)
 * - Bestätigte Buchungen (kein Overlap)
 * - Service-Puffer (bufferMin)
 */
export async function getAvailableSlots(opts: {
  salonId: string
  serviceId: string
  date: string // YYYY-MM-DD (lokales Datum des Salons)
}) {
  const { salonId, serviceId, date } = opts

  const [salon, service] = await Promise.all([
    prisma.salon.findUnique({ where: { id: salonId } }),
    prisma.service.findUnique({ where: { id: serviceId } })
  ])
  if (!salon || !service) return []

  const tz = salon.timezone || "Europe/Berlin"
  const durMin = service.durationMin
  const bufMin = service.bufferMin ?? 0
  const stepMin = durMin // Raster = Dauer

  // Tagesrahmen in TZ → UTC-Boundaries
  const dayStartTz = DateTime.fromISO(date, { zone: tz }).startOf("day")
  const dayEndTz = dayStartTz.endOf("day")
  const dayStartUtc = dayStartTz.toUTC()
  const dayEndUtc = dayEndTz.toUTC()

  // Öffnungszeiten des Wochentags
  const weekday = (dayStartTz.weekday % 7) // 1=Mo ... 7=So → 0..6 in DB
  const oh = await prisma.openingHour.findFirst({ where: { salonId, weekday: (weekday % 7) }, orderBy: { id: "asc" } })
  if (!oh || oh.isClosed) return []

  const openM = hm(oh.openTime)
  const closeM = hm(oh.closeTime)

  // Schedules des Tages
  const schedules = await prisma.schedule.findMany({
    where: {
      staff: { salonId },
      start: { lte: dayEndUtc.toJSDate() },
      end: { gte: dayStartUtc.toJSDate() },
      isAvailable: true
    },
    include: { staff: true }
  })
  if (schedules.length === 0) return []

  // Confirmed Bookings des Tages
  const confirmed = await prisma.booking.findMany({
    where: {
      salonId, status: "CONFIRMED",
      start: { lte: dayEndUtc.toJSDate() }, end: { gte: dayStartUtc.toJSDate() }
    },
    select: { start: true, end: true, staffId: true }
  })

  const slots: Slot[] = []

  for (const sch of schedules) {
    // Schedule in TZ projizieren
    const schStartTz = DateTime.fromJSDate(sch.start).setZone(tz)
    const schEndTz = DateTime.fromJSDate(sch.end).setZone(tz)
    const schInterval = Interval.fromDateTimes(schStartTz, schEndTz)

    // Öffnungsfenster des Tages in TZ
    const openStart = dayStartTz.plus({ minutes: openM })
    const openEnd = dayStartTz.plus({ minutes: closeM })
    const openInterval = Interval.fromDateTimes(openStart, openEnd)

    // Schnittmenge
    const work = schInterval.intersection(openInterval)
    if (!work) continue

    // Slot-Grid iterieren
    let cursor = work.start
    while (cursor.plus({ minutes: durMin + bufMin }).toMillis() <= work.end.toMillis()) {
      const startTz = cursor
      const endTz = cursor.plus({ minutes: durMin })
      const endWithBufferTz = endTz.plus({ minutes: bufMin })

      // Check Overlap mit confirmed (in UTC vergleichen)
      const startUtc = startTz.toUTC().toJSDate()
      const endUtc = endTz.toUTC().toJSDate()
      const rangeOk = confirmed.every(b =>
        b.staffId !== sch.staffId ||
        (endUtc <= b.start || startUtc >= b.end)
      )
      if (rangeOk) {
        slots.push({ start: startUtc, end: endUtc, staffId: sch.staffId })
      }
      cursor = cursor.plus({ minutes: stepMin })
    }
  }

  // Sortieren & zurück
  return slots.sort((a, b) => a.start.getTime() - b.start.getTime())
}
