-- Enable extension for GiST range ops
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- Prevent overlapping CONFIRMED bookings per staff (when staff assigned)
ALTER TABLE "Booking"
ADD CONSTRAINT booking_no_overlap_per_staff
EXCLUDE USING gist (
  "staffId" WITH =,
  tstzrange("start","end") WITH &&
)
WHERE ("staffId" IS NOT NULL AND status = 'CONFIRMED');
