# PHASE P4 — Booking-Engine Hardening, Retries, Analytics

This package includes **new / replaced files** and **patch notes** for partial edits.
Apply these alongside your existing repo.

## New / Replaced files (drop-in)
- `src/lib/availability.ts` (TZ/DST via Luxon, bufferMin, overlaps)
- `src/app/api/bookings/route.ts` (POST create booking with transaction and email)
- `src/app/api/bookings/[id]/route.ts` (PATCH with 409 on overlap)
- `src/app/api/salons/[id]/services/route.ts` (POST supports bufferMin)
- `src/lib/jobs.ts` (Redis delayed jobs + exponential backoff retries)
- `src/lib/metrics.ts` (admin analytics helper)
- `src/app/admin/analytics/page.tsx` (new analytics page)
- `prisma/migrations/20250816_booking_overlap_exclude/migration.sql` (DB exclusion constraint)

## Partial edits (apply manually)
- `package.json` → add dependency: `"luxon": "^3.5.0"`
- `prisma/schema.prisma` → add `timezone` to `Salon`, `bufferMin` to `Service`, and indices shown below
- `src/lib/validators.ts` → add `timezone` in `salonUpsertSchema` and `bufferMin` in `serviceSchema`
- `prisma/seed.ts` → set salon `timezone` and service `bufferMin` examples
- `src/app/owner/salons/[id]/services/page.tsx` → add input for `bufferMin` in form and pass to POST body
- `README.md` → add Booking-Engine & Queue/Retries sections

## Prisma schema excerpts
Update relevant models as below (merge carefully):

```prisma
model Salon {
  // ...
  timezone     String         @default("Europe/Berlin")
  @@index([isPublished, city])
  @@index([slug])
  @@index([createdAt])
  @@index([latitude, longitude])
}

model Service {
  // ...
  bufferMin   Int      @default(0)
  @@index([salonId, priceCents])
}

model Booking {
  // ...
  @@index([salonId, start, status])
  @@index([customerId, start])
  @@index([staffId, start])
}
```

## Validator snippets (`src/lib/validators.ts`)
```ts
export const salonUpsertSchema = z.object({
  // ...
  timezone: z.string().min(3).default("Europe/Berlin"),
  // ...
})

export const serviceSchema = z.object({
  // ...
  bufferMin: z.number().int().min(0).max(120).default(0),
  // ...
})
```

## Migration (optional but recommended)
Add the exclusion constraint to prevent overlapping **CONFIRMED** bookings per staff:
- file provided: `prisma/migrations/20250816_booking_overlap_exclude/migration.sql`

## After applying
- Run: `pnpm prisma:generate && pnpm prisma:migrate`
- Rebuild: `pnpm build`
- (If Redis worker cron used) Ensure `/api/jobs/worker` cron is enabled.

