import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"
import { setFlag } from "@/lib/flags"

export async function GET() {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const list = await prisma.featureFlag.findMany({ orderBy: { updatedAt: "desc" } })
  return NextResponse.json({ list })
}

export async function POST(req: Request) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const { key, enabled, note } = await req.json() as { key: string; enabled: boolean; note?: string }
  const row = await setFlag(key, enabled, note)
  return NextResponse.json(row)
}
