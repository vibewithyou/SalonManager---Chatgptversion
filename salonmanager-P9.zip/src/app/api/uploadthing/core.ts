import { createUploadthing, type FileRouter } from "uploadthing/next"
import { getSessionOrThrow } from "@/lib/user"
import { rateLimit } from "@/lib/rate"
import { imageSize } from "image-size"

const f = createUploadthing()

export const ourFileRouter = {
  imageUploader: f({ image: { maxFileSize: "10MB", maxFileCount: 10 } })
    .middleware(async ({ req }) => {
      const session = await getSessionOrThrow()
      const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local"
      if (!(await rateLimit(ip, "upload", 10, 60_000))) throw new Error("rate")
      return { userId: (session.user as any).id }
    })
    .onUploadComplete(async ({ file }) => {
      try {
        // Validate content by fetching the uploaded file and checking pixel limits
        const resp = await fetch(file.url)
        const buf = Buffer.from(await resp.arrayBuffer())
        const dim = imageSize(buf)
        if (!dim || !dim.width || !dim.height) throw new Error("image parse")
        if (dim.width * dim.height > 25_000_000) throw new Error("too many pixels") // ~5000x5000
      } catch (e) {
        console.warn("Upload validation failed:", e)
      }
      return { url: file.url }
    })
} satisfies FileRouter

export type OurFileRouter = typeof ourFileRouter
