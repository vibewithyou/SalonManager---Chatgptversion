import { ImageResponse } from "next/og"

export const runtime = "edge"
export const size = { width: 1200, height: 630 }
export const contentType = "image/png"
export const revalidate = 3600 // 1h

export default async function OG() {
  const bg = "#121212", gold = "#D4AF37", text = "#E0E0E0"
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", background: bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ border: `3px solid ${gold}`, borderRadius: 24, padding: 40, width: 1000 }}>
          <div style={{ color: gold, fontSize: 64, fontWeight: 700 }}>SalonManager</div>
          <div style={{ color: text, fontSize: 28, marginTop: 10 }}>Suche, Buchung und Verwaltung für Salons</div>
        </div>
      </div>
    ),
    { ...size }
  )
}
