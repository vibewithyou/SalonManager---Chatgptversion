"use client"

import useSWR from "swr"
import { useState } from "react"
const fetcher = (u: string) => fetch(u).then(r=>r.json())

export default function FlagsPage() {
  const { data, mutate } = useSWR("/api/admin/flags", fetcher)
  const [key, setKey] = useState("kill.bookings")
  const [note, setNote] = useState("")

  async function setFlag(key: string, enabled: boolean) {
    await fetch("/api/admin/flags", {
      method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify({ key, enabled, note })
    })
    mutate()
  }

  return (
    <div className="grid gap-4 max-w-2xl">
      <h1 className="text-2xl font-semibold text-gold">Feature Flags</h1>
      <div className="card grid gap-2">
        <div className="grid grid-cols-2 gap-2">
          <input className="input" placeholder="Flag-Key" value={key} onChange={e=>setKey(e.target.value)} />
          <input className="input" placeholder="Notiz (optional)" value={note} onChange={e=>setNote(e.target.value)} />
        </div>
        <div className="flex gap-2">
          <button className="btn" onClick={()=>setFlag(key, true)}>Aktivieren</button>
          <button className="btn" onClick={()=>setFlag(key, false)}>Deaktivieren</button>
        </div>
      </div>

      <div className="card">
        <h2 className="font-medium mb-2">Aktuelle Flags</h2>
        <ul className="grid gap-2">
          {(data?.list ?? []).map((f: any)=>(
            <li key={f.key} className="flex items-center justify-between text-sm border border-border rounded p-2">
              <span>{f.key} • <b className={f.enabled ? "text-gold" : "text-muted"}>{f.enabled ? "ON" : "OFF"}</b></span>
              <span className="text-muted">{f.note ?? ""}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
