export function assertSameOrigin(req: Request) {
  const origin = req.headers.get("origin")
  const host = req.headers.get("host")
  if (!origin || !host) return true // non-browser or curl
  try {
    const o = new URL(origin)
    if (o.hostname !== host.split(":")[0]) return false
    return true
  } catch {
    return false
  }
}
