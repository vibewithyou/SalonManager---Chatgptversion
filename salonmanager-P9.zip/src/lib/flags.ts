import { prisma } from "@/lib/prisma"
import { getRedis } from "./redis"

const MEM_CACHE = new Map<string, { v: boolean; ts: number }>()
const TTL = 30_000

export async function getFlag(key: string, fallback = false) {
  const now = Date.now()
  const m = MEM_CACHE.get(key)
  if (m && now - m.ts < TTL) return m.v

  const r = getRedis()
  if (r) {
    const rv = await r.get(`flag:${key}`)
    if (rv !== null) {
      const v = rv === "1"
      MEM_CACHE.set(key, { v, ts: now })
      return v
    }
  }
  const row = await prisma.featureFlag.findUnique({ where: { key } })
  const v = row?.enabled ?? fallback
  MEM_CACHE.set(key, { v, ts: now })
  if (r) await r.setex(`flag:${key}`, 60, v ? "1" : "0")
  return v
}

export async function setFlag(key: string, enabled: boolean, note?: string) {
  const row = await prisma.featureFlag.upsert({ where: { key }, create: { key, enabled, note }, update: { enabled, note } })
  const r = getRedis()
  if (r) await r.setex(`flag:${key}`, 60, enabled ? "1" : "0")
  MEM_CACHE.set(key, { v: enabled, ts: Date.now() })
  return row
}
