import { useState } from "react"

export type ErrorMap = Record<string, string>

export function normalizeZodIssuePath(path: (string|number)[]) {
  return path.join(".")
}

export function toErrorMap(zodError: any): ErrorMap {
  if (!zodError) return {}
  const out: ErrorMap = {}
  const issues = zodError.issues ?? []
  for (const i of issues) {
    const key = normalizeZodIssuePath(i.path ?? [])
    if (key && !out[key]) out[key] = i.message || "Ungültiger Wert"
  }
  return out
}

export function useFormErrors() {
  const [errors, setErrors] = useState<ErrorMap>({})
  function set(field: string, msg: string) { setErrors(prev => ({ ...prev, [field]: msg })) }
  function clear(field?: string) {
    if (!field) return setErrors({})
    setErrors(prev => { const c = { ...prev }; delete c[field]; return c })
  }
  return { errors, setErrors, setError: set, clear }
}
