"use client"

import { ErrorMap } from "./useFormErrors"
import clsx from "clsx"

export function Field({
  id, label, children, errors
}: { id: string; label: string; children: React.ReactNode; errors?: ErrorMap }) {
  const err = errors?.[id]
  const descId = err ? `${id}-error` : undefined
  return (
    <div className="grid gap-1">
      <label htmlFor={id} className="text-sm">{label}</label>
      {children}
      {err && <p id={descId} role="alert" className="text-xs text-red-400">{err}</p>}
    </div>
  )
}

export function inputProps(id: string, errors?: ErrorMap) {
  const err = errors?.[id]
  return {
    id,
    "aria-invalid": err ? true : undefined,
    "aria-describedby": err ? `${id}-error` : undefined,
    className: clsx("input", err && "ring-1 ring-red-500 focus:ring-red-500")
  }
}
