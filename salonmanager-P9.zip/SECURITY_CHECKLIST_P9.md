## Security Review Checklist

### Auth & Session
- [ ] E-Mail-Verifikation & 2FA aktiv.
- [ ] Cookies httpOnly, secure (prod), SameSite=Lax.
- [ ] Origin/Host-Check in Custom-POST-Routen (`lib/csrf.ts`).

### RBAC & Data Access
- [ ] Serverseitige Guards für alle Mutationen.
- [ ] Field-Whitelists gegen Mass Assignment.
- [ ] Audit-Logs für kritische Aktionen inkl. Impersonation.

### Inputs & Uploads
- [ ] Zod-Validation + Trimming, Inline-Fehler (A11y).
- [ ] Uploads: MIME/Größe/Pixel geprüft, Rate-Limits, Host-Whitelist.

### Headers & CSP
- [ ] CSP restriktiv; nosniff, frame-options, referrer-policy, permissions-policy.

### Bookings & Races
- [ ] DB-Exclusion Constraint, Transaktionen, 409 bei Konflikt.
- [ ] TZ/DST-Tests (Luxon), Bufferzeiten, Storno/No-Show Policies.

### Reliability
- [ ] Redis Rate-Limits; Queue mit Backoff; Health & Logs vorhanden.
- [ ] E-Mail-Zustellbarkeit + Webhook-Suppressions.

### Secrets & Deploy
- [ ] ENV in Secrets, keine Leaks.
- [ ] Sentry aktiv + Release Upload.
- [ ] Feature Flags & Kill-Switches funktionsfähig.
- [ ] OG-Images mit `revalidate` gecacht.
