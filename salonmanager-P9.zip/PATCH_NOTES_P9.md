# Phase P9 — Integration Notes

## package.json
Add dependency:
```json
{
  "dependencies": {
    "image-size": "^1.1.1"
  }
}
```

## Prisma
Add model:
```prisma
model FeatureFlag {
  key        String  @id
  enabled    Boolean @default(false)
  note       String?
  updatedAt  DateTime @updatedAt
  createdAt  DateTime @default(now())
}
```
Then run: `pnpm prisma:generate && pnpm prisma:migrate`

## New Files
- `src/components/forms/useFormErrors.ts`
- `src/components/forms/Field.tsx`
- `src/app/api/uploadthing/core.ts` (hardened upload checks)
- `src/app/opengraph-image.tsx` (with `revalidate`)
- `src/app/salon/[slug]/opengraph-image.tsx` (with `revalidate`)
- `src/lib/flags.ts`
- `src/app/admin/flags/page.tsx`
- `src/app/api/admin/flags/route.ts`
- `src/lib/csrf.ts`

## Guards
In critical POST routes add:
```ts
import { assertSameOrigin } from "@/lib/csrf"
if (!assertSameOrigin(req)) return NextResponse.json({ error: "Bad origin" }, { status: 400 })
```

## Kill-Switches
Example in bookings create:
```ts
import { getFlag } from "@/lib/flags"
if (await getFlag("kill.bookings", false)) {
  return NextResponse.json({ error: "Bookings temporarily disabled" }, { status: 503 })
}
```

## OG Revalidate
Both OG routes now export `export const revalidate = 3600`.

## UI
Add Admin menu links to `/admin/users` and `/admin/flags`.

## Upload Notes
- Accept only JPG/PNG/WebP up to 10MB.
- Additional server-side dimension check (~25MP cap).
- Rate limit uploads via Redis sliding-window.
