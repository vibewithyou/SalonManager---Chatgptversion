module.exports = {
  root: true,
  extends: ["next/core-web-vitals", "eslint:recommended"],
  rules: {
    "@next/next/no-img-element": "off"
  }
}
