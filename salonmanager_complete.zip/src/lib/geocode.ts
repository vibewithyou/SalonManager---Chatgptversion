export async function nominatimSearch(query: string) {
  const url = new URL("https://nominatim.openstreetmap.org/search")
  url.searchParams.set("format", "jsonv2")
  url.searchParams.set("limit", "5")
  url.searchParams.set("q", query)
  const res = await fetch(url.toString(), {
    headers: { "User-Agent": "SalonManager/1.0 (demo)" },
    cache: "no-store"
  })
  if (!res.ok) throw new Error("Geocoding failed")
  return res.json() as Promise<Array<{ lat: string; lon: string; display_name: string }>>
}
