import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"

async function createSlot(_: any, formData: FormData) {
  "use server"
  const session = await auth()
  if (!session?.user) throw new Error("UNAUTHORIZED")
  const userId = (session.user as any).id
  const staff = await prisma.staffProfile.findFirst({ where: { userId } })
  if (!staff) throw new Error("NO_STAFF")

  const start = new Date(String(formData.get("start")))
  const end = new Date(String(formData.get("end")))
  await prisma.schedule.create({ data: { staffId: staff.id, start, end, isAvailable: true } })
  revalidatePath("/staff/schedule")
}

export default async function StaffSchedulePage() {
  const session = await auth()
  if (!session?.user) return <div className="card">Bitte einloggen.</div>
  const userId = (session.user as any).id
  const staff = await prisma.staffProfile.findFirst({ where: { userId } })
  if (!staff) return <div className="card">Keine Staff-Zugehörigkeit.</div>

  const slots = await prisma.schedule.findMany({ where: { staffId: staff.id }, orderBy: { start: "desc" } })

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Verfügbarkeit</h1>
      <form action={createSlot} className="card grid gap-3 max-w-lg">
        <label className="text-sm">Start</label>
        <input className="input" type="datetime-local" name="start" required />
        <label className="text-sm">Ende</label>
        <input className="input" type="datetime-local" name="end" required />
        <button className="btn">Slot hinzufügen</button>
      </form>
      <ul className="grid gap-2">
        {slots.map(s=>(
          <li key={s.id} className="card text-sm flex items-center justify-between">
            <span>{new Date(s.start).toLocaleString()} — {new Date(s.end).toLocaleString()}</span>
            <span className="badge confirmed">{s.isAvailable ? "frei" : "gesperrt"}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
