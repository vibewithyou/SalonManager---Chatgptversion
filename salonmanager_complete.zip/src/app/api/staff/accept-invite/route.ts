import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { requireUser } from "@/lib/auth-helpers"

export async function POST(req: Request) {
  const session = await requireUser()
  const { token, displayName } = await req.json() as { token: string; displayName?: string }
  if (!token) return NextResponse.json({ error: "Missing token" }, { status: 400 })

  const invite = await prisma.media.findFirst({ where: { type: "INVITE", url: token } })
  if (!invite) return NextResponse.json({ error: "Invalid token" }, { status: 404 })

  await prisma.media.delete({ where: { id: invite.id } }) // one-time use
  const userId = (session.user as any).id
  const existed = await prisma.staffProfile.findFirst({ where: { userId, salonId: invite.salonId } })
  if (existed) return NextResponse.json(existed)

  const sp = await prisma.staffProfile.create({
    data: { userId, salonId: invite.salonId, displayName: displayName || (session.user?.name ?? "Mitarbeiter/in") }
  })
  return NextResponse.json(sp, { status: 201 })
}
