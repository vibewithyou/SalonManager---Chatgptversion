import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { salonUpsertSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function PATCH(_req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const salon = await prisma.salon.findUnique({ where: { id: params.id } })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  // Owner guard
  if ((session.user as any).role !== "ADMIN" && salon.ownerId !== (session.user as any).id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const data = salonUpsertSchema.partial().parse(await _req.json())
  const updated = await prisma.salon.update({
    where: { id: params.id },
    data: {
      ...data,
      // tags update (replace)
      ...(data.tags
        ? {
            tags: {
              deleteMany: {},
              create: data.tags.map(name => ({
                tag: { connectOrCreate: { where: { name }, create: { name } } }
              }))
            }
          }
        : {})
    }
  })
  return NextResponse.json(updated)
}
