"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"

type Service = { id: string; name: string; durationMin: number; priceCents: number }

export default function BookWizard({ params }: { params: { slug: string } }) {
  const sp = useSearchParams()
  const [salon, setSalon] = useState<any>(null)
  const [serviceId, setServiceId] = useState<string>("")
  const [date, setDate] = useState<string>("")
  const [slots, setSlots] = useState<any[]>([])
  const [note, setNote] = useState("")
  const [imageUrl, setImageUrl] = useState<string | undefined>(undefined)
  const [done, setDone] = useState<string | null>(null)

  useEffect(() => {
    fetch(`/api/salons/${params.slug}`).then(r=>r.json()).then(setSalon)
  }, [params.slug])

  useEffect(() => {
    if (salon?.id && serviceId && date) {
      fetch(`/api/salons/${salon.id}/availability?serviceId=${serviceId}&date=${date}`).then(r=>r.json()).then(setSlots)
    } else setSlots([])
  }, [salon, serviceId, date])

  async function submit(start: string) {
    const res = await fetch("/api/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ salonId: salon.id, serviceId, start, note, imageUrl }) })
    if (res.ok) setDone("Anfrage gesendet!")
    else setDone("Fehler bei der Anfrage.")
  }

  if (!salon) return <div className="card">Lade…</div>

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Buchung – {salon.name}</h1>

      <div className="card grid gap-3 max-w-xl">
        <label className="text-sm">Leistung</label>
        <select className="input" value={serviceId} onChange={e => setServiceId(e.target.value)}>
          <option value="">Bitte wählen…</option>
          {salon.services.map((s: Service)=>(
            <option key={s.id} value={s.id}>{s.name} — {(s.priceCents/100).toFixed(2)} € ({s.durationMin} min)</option>
          ))}
        </select>

        <label className="text-sm">Datum</label>
        <input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} />

        <label className="text-sm">Notiz</label>
        <textarea className="input" value={note} onChange={e=>setNote(e.target.value)} placeholder="Optional" />

        {/* Upload folgt in Step 3 (UploadThing) */}
      </div>

      <section className="card">
        <h2 className="mb-2 font-medium">Verfügbare Slots</h2>
        {slots.length === 0 ? (
          <p className="text-sm text-muted">Keine Slots – Leistung/Datum wählen.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {slots.map(s=>(
              <button key={String(s.start)} className="btn"
                onClick={()=>submit(s.start)}>
                {new Date(s.start).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </button>
            ))}
          </div>
        )}
      </section>

      {done && <div className="card">{done}</div>}
    </div>
  )
}
