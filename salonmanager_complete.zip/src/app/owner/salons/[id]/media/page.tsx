import { prisma } from "@/lib/prisma"
import { MediaUploader } from "@/components/MediaUploader"
import Image from "next/image"

export default async function MediaPage({ params }: { params: { id: string } }) {
  const salon = await prisma.salon.findUnique({ where: { id: params.id }, include: { media: true, name: true } as any })
  if (!salon) return <div className="card">Nicht gefunden</div>
  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-gold">Medien – {salon.name}</h1>
      <MediaUploader salonId={salon.id} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {salon.media
          .filter(m => m.type === "IMAGE" || m.type === "LOGO")
          .map(m => (
            <div key={m.id} className="relative overflow-hidden rounded border border-border">
              <Image src={m.url} alt={m.alt ?? ""} width={600} height={400} className="object-cover w-full h-40" />
            </div>
          ))}
      </div>
    </div>
  )
}
