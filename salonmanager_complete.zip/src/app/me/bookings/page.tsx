"use client"

import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then(r => r.json())

export default function MyBookingsPage() {
  const { data, mutate } = useSWR("/api/bookings?mine=1", fetcher)

  async function cancel(id: string) {
    await fetch(`/api/bookings/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "CANCELLED" }) })
    mutate()
  }

  if (!data) return <div className="card">Lade…</div>
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Meine Buchungen</h1>
      <ul className="grid gap-2">
        {data.map((b: any) => (
          <li key={b.id} className="card flex items-center justify-between text-sm">
            <div>
              <div>{new Date(b.start).toLocaleString()} — {b.service.name}</div>
              <div className="text-muted">{b.salon.name}</div>
            </div>
            <div className="flex items-center gap-3">
              <span className={`badge ${b.status.toLowerCase()}`}>{b.status}</span>
              {b.status === "PENDING" && (
                <button onClick={()=>cancel(b.id)} className="inline-flex items-center rounded px-3 py-1 border border-danger text-danger hover:bg-red-950">Stornieren</button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
