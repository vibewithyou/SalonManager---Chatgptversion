import "./globals.css"
import type { Metadata } from "next"
import Link from "next/link"
import { I18nProvider } from "@/i18n/I18nProvider"
import { ToastProvider } from "@/components/ToastProvider"

export const metadata: Metadata = {
  title: "SalonManager",
  description: "Suche, Buchungen & Verwaltung für Salons",
  themeColor: "#D4AF37",
  manifest: "/manifest.json"
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>
        <I18nProvider locale="de">
          <ToastProvider>
          <header className="border-b border-border">
            <nav className="container flex h-14 items-center justify-between">
              <Link href="/" className="font-semibold text-gold">SalonManager</Link>
              <div className="flex items-center gap-4">
                <Link href="/owner/salons" className="text-sm hover:text-gold">Owner</Link>
                <Link href="/staff/agenda" className="text-sm hover:text-gold">Staff</Link>
                <Link href="/me/bookings" className="text-sm hover:text-gold">Meine Buchungen</Link>
                <Link href="/login" className="btn">Login</Link>
              </div>
            </nav>
          </header>
          <main className="container py-6">{children}</main>
          <footer className="container py-10 text-sm text-muted">
            <div className="flex gap-4">
              <Link href="/impressum" className="hover:text-gold">Impressum</Link>
              <Link href="/datenschutz" className="hover:text-gold">Datenschutz</Link>
            </div>
          </footer>
                  </ToastProvider>
        </I18nProvider>
      </body>
    </html>
  )
}
