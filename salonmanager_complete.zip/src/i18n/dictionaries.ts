export const dict = {
  de: {
    common: {
      findSalon: "Finde deinen Salon",
      login: "Login",
      register: "Registrieren",
      myBookings: "Meine Buchungen",
      view: "Ansehen",
      save: "Speichern"
    },
    owner: {
      mySalons: "Meine Salons",
      bookings: "Buchungen",
      openingHours: "Öffnungszeiten"
    },
    booking: {
      confirm: "Bestätigen",
      decline: "Ablehnen",
      unassigned: "— keine Zuweisung —"
    }
  },
  en: {
    common: {
      findSalon: "Find your salon",
      login: "Login",
      register: "Register",
      myBookings: "My bookings",
      view: "View",
      save: "Save"
    },
    owner: {
      mySalons: "My salons",
      bookings: "Bookings",
      openingHours: "Opening hours"
    },
    booking: {
      confirm: "Confirm",
      decline: "Decline",
      unassigned: "— unassigned —"
    }
  }
}
export type Locale = keyof typeof dict
export type Namespaces = keyof typeof dict["de"]
export type Keys<N extends Namespaces> = keyof typeof dict["de"][N]
