"use client"

import { UploadButton } from "@uploadthing/react"
import type { OurFileRouter } from "@/app/api/uploadthing/core"

export function MediaUploader({ salonId }: { salonId: string }) {
  return (
    <div className="card">
      <h3 className="mb-2 font-medium">Bilder hochladen</h3>
      <UploadButton<OurFileRouter>
        endpoint="imageUploader"
        input={{ salonId }}
        appearance={{
          button: "btn",
          allowedContent: "text-sm text-muted mt-2"
        }}
        onClientUploadComplete={() => {
          // einfache Refresh-Strategie
          window.location.reload()
        }}
      />
      <p className="text-xs text-muted mt-2">JPG/PNG bis 10 MB. Automatischer Eintrag in Medien.</p>
    </div>
  )
}
