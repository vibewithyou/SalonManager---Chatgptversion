"use client"

import { createContext, useContext, useState, useCallback } from "react"

type Toast = { id: string; title?: string; message: string; type?: "info"|"success"|"error" }
const ToastCtx = createContext<{ notify: (t: Omit<Toast, "id">) => void }>({ notify: () => {} })

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])
  const notify = useCallback((t: Omit<Toast,"id">) => {
    const id = crypto.randomUUID()
    setToasts(prev => [...prev, { id, ...t }])
    setTimeout(() => setToasts(prev => prev.filter(x => x.id !== id)), 4000)
  }, [])

  return (
    <ToastCtx.Provider value={{ notify }}>
      {children}
      <div
        className="fixed bottom-4 right-4 z-50 flex flex-col gap-2"
        role="status" aria-live="polite" aria-atomic="true"
      >
        {toasts.map(t => (
          <div
            key={t.id}
            className={`rounded border p-3 max-w-sm bg-surface ${t.type==="error" ? "border-danger text-danger" : t.type==="success" ? "border-gold text-gold" : "border-border text-text"}`}
          >
            {t.title && <div className="font-medium mb-0.5">{t.title}</div>}
            <div className="text-sm">{t.message}</div>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

export function useToast() {
  return useContext(ToastCtx).notify
}
