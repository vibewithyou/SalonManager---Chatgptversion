import { test, expect } from "@playwright/test"

test("home → salon-page basic flow", async ({ page }) => {
  await page.goto("/")
  await expect(page.getByText("Finde deinen Salon")).toBeVisible()
  await page.getByRole("link", { name: /Zum Salon/i }).click()
  await expect(page).toHaveURL(/\/salon\/barbers-freiberg/)
  await expect(page.getByText("Leistungen")).toBeVisible()
})
