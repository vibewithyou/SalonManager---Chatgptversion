import { test, expect } from "@playwright/test"

test("owner can see bookings list", async ({ page }) => {
  await page.goto("/login")
  await page.getByPlaceholder("E-Mail").fill("owner@demo.tld")
  await page.getByPlaceholder("Passwort").fill("Owner123!")
  await page.getByRole("button", { name: /Einloggen/i }).click()
  await page.waitForURL("/")
  await page.goto("/owner/salons")
  await page.getByRole("link", { name: /Verwalten/ }).first().click()
  await page.getByRole("link", { name: /Buchungen/ }).click()
  await expect(page.getByText(/Buchungen/)).toBeVisible()
})
