import { test, expect } from "@playwright/test"

test("ICS feed requires token and works with token", async ({ page, request }) => {
  // Ohne Token → 401
  const resp401 = await request.get("/api/ical/salon/unknown")
  expect(resp401.status()).toBe(401)

  // Login als Owner
  await page.goto("/login")
  await page.getByPlaceholder(/E-Mail/i).fill("owner@demo.tld")
  await page.getByPlaceholder(/Passwort/i).fill("Owner123!")
  await page.getByRole("button", { name: /Einloggen/i }).click()
  await page.waitForURL("/")

  // Salon-ID via öffentliche Suche holen (Seed enthält barbers-freiberg)
  const list = await page.evaluate(async () => {
    const r = await fetch("/api/salons?page=1&pageSize=1&sort=new")
    return r.json()
  }) as any
  const salonId = list.items?.[0]?.id
  expect(salonId).toBeTruthy()

  // Token erzeugen
  const tokenResp = await page.evaluate(async (sid) => {
    const r = await fetch("/api/ical/token", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "SALON", salonId: sid })
    })
    return r.json()
  }, salonId)
  expect(tokenResp.token).toBeTruthy()

  // ICS abrufen
  const ics = await request.get(`/api/ical/salon/${salonId}?t=${tokenResp.token}`)
  expect(ics.status()).toBe(200)
  expect(ics.headers()["content-type"]).toMatch(/text\/calendar/)
  const body = await ics.text()
  expect(body).toContain("BEGIN:VCALENDAR")
})
