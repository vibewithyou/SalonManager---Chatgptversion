# Phase P7 — Apply Notes

These files are **added/replaced**. Apply the following small inline edits to existing files:

## 1) `src/app/layout.tsx`
- Add:
```tsx
import ImpersonationBanner from "@/components/ImpersonationBanner"
import { cookies } from "next/headers"
```
- Read cookie and render banner (inside `<I18nProvider>` but before main content):
```tsx
const cookieStore = cookies()
const isImpersonating = !!cookieStore.get("impersonate")?.value
{isImpersonating && <ImpersonationBanner />}
```

## 2) `next.config.js`
- Ensure CSP `connect-src` includes Google domains:
```
https://www.googleapis.com https://accounts.google.com
```

## 3) `package.json`
- Add devDependency: `"wait-on": "^7.0.1"`
- Add script: `"serve:prod": "pnpm start & npx wait-on http://localhost:3000"`

## 4) `.github/workflows/ci.yml`
- Add a **lighthouse** job (after `e2e`) using `treosh/lighthouse-ci-action@v10` and `lighthouse-budgets.json` as in the P7 patch text.

## 5) Admin UI
- (Optional) add an "Impersonate" button in your Admin user list to POST `/api/admin/impersonate/start { userId }`.
