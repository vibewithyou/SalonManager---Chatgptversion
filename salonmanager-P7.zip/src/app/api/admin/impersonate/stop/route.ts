import { NextResponse } from "next/server"
import { auth } from "@/auth"
import { audit } from "@/lib/audit"

export async function POST() {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const res = NextResponse.json({ ok: true })
  res.cookies.set("impersonate", "", { httpOnly: true, path: "/", maxAge: 0 })
  await audit({ userId: (session.user as any).id, action: "ADMIN_IMPERSONATE_STOP" })
  return res
}
