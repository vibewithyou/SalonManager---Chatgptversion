import { NextResponse } from "next/server"
import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"
import { audit } from "@/lib/audit"

export async function POST(req: Request) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const { userId } = await req.json() as { userId: string }
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { id: true, email: true } })
  if (!user) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const res = NextResponse.json({ ok: true })
  res.cookies.set("impersonate", user.id, { httpOnly: true, sameSite: "lax", path: "/" })
  await audit({ userId: (session.user as any).id, action: "ADMIN_IMPERSONATE_START", entity: `User:${user.id}`, meta: { email: user.email } })
  return res
}
