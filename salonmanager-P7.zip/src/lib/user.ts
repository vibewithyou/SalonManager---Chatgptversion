import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"
import { cookies } from "next/headers"

export async function getSessionOrThrow() {
  const session = await auth()
  if (!session?.user) throw new Error("UNAUTHORIZED")
  const baseRole = (session.user as any).role as string
  const baseId = (session.user as any).id as string
  const imp = cookies().get("impersonate")?.value
  if (imp && baseRole === "ADMIN") {
    const target = await prisma.user.findUnique({ where: { id: imp }, select: { id: true, role: true, email: true } })
    if (target) {
      ;(session.user as any).__impersonated = true
      ;(session.user as any).__impersonatorId = baseId
      ;(session.user as any).id = target.id
      ;(session.user as any).role = target.role
      ;(session.user as any).email = target.email
    }
  }
  return session
}

export async function getStaffProfileForUser(userId: string) {
  return prisma.staffProfile.findFirst({ where: { userId }, include: { salon: true } })
}

export async function isOwnerOfSalon(userId: string, salonId: string) {
  const salon = await prisma.salon.findUnique({ where: { id: salonId }, select: { ownerId: true } })
  return !!salon && salon.ownerId === userId
}
