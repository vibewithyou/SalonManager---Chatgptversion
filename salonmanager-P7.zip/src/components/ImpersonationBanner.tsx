"use client"

import { useState } from "react"

export default function ImpersonationBanner() {
  const [busy, setBusy] = useState(false)
  async function stop() {
    setBusy(true)
    await fetch("/api/admin/impersonate/stop", { method: "POST" })
    location.reload()
  }
  return (
    <div className="w-full bg-yellow-900/40 text-yellow-200 text-sm flex items-center justify-between px-4 py-2">
      <span>⚠️ Du agierst als anderer Nutzer. Einige Admin-Bereiche sind ggf. gesperrt.</span>
      <button className="underline hover:text-gold" onClick={stop} disabled={busy}>{busy ? "Beende…" : "Impersonation beenden"}</button>
    </div>
  )
}
