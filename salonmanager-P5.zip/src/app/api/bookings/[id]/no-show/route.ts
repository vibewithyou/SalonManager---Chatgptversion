import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, getStaffProfileForUser, isOwnerOfSalon } from "@/lib/user"

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const role = (session.user as any).role as "ADMIN"|"OWNER"|"STAFF"

  const booking = await prisma.booking.findUnique({
    where: { id: params.id },
    include: { salon: { include: { policy: true } }, customer: true }
  })
  if (!booking) return NextResponse.json({ error: "Not found" }, { status: 404 })
  let allowed = false
  if (role === "ADMIN") allowed = true
  if (role === "OWNER") allowed = await isOwnerOfSalon(userId, booking.salonId)
  if (role === "STAFF") {
    const me = await getStaffProfileForUser(userId)
    allowed = !!me && me.salonId === booking.salonId
  }
  if (!allowed) return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const updated = await prisma.$transaction(async (tx) => {
    const up = await tx.booking.update({ where: { id: booking.id }, data: { noShow: true, status: "DECLINED" } })
    await tx.user.update({ where: { id: booking.customerId }, data: { noShowCount: { increment: 1 } } })
    return up
  })
  return NextResponse.json(updated)
}
