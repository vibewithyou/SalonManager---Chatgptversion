import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow } from "@/lib/user"

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id

  const booking = await prisma.booking.findUnique({
    where: { id: params.id },
    include: { salon: { include: { policy: true } } }
  })
  if (!booking) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if (booking.customerId !== userId) return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  if (booking.status !== "PENDING" && booking.status !== "CONFIRMED")
    return NextResponse.json({ error: "Not cancellable" }, { status: 400 })

  const minH = booking.salon.policy?.cancellationMinHours ?? 2
  const now = new Date()
  const diffH = (booking.start.getTime() - now.getTime()) / 3_600_000
  if (diffH < minH) {
    return NextResponse.json({ error: `Cancellation window passed (${minH}h)` }, { status: 422 })
  }

  const updated = await prisma.booking.update({
    where: { id: booking.id },
    data: { status: "CANCELLED", cancelledAt: new Date() }
  })
  return NextResponse.json(updated)
}
