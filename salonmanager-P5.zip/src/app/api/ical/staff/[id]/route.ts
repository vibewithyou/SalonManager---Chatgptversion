import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { generateIcs } from "@/lib/ical"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const staff = await prisma.staffProfile.findUnique({ where: { id: params.id }, include: { salon: true, user: true } })
  if (!staff) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const list = await prisma.booking.findMany({
    where: { staffId: staff.id, status: "CONFIRMED" },
    include: { service: true },
    orderBy: { start: "asc" }
  })
  const events = list.map(b => ({
    uid: b.id,
    title: `${b.service.name} – ${staff.displayName}`,
    start: b.start,
    end: b.end,
    url: `${process.env.NEXTAUTH_URL}/staff/agenda`,
    location: `${staff.salon.address}, ${staff.salon.postalCode} ${staff.salon.city}`
  }))
  const ics = generateIcs(events)
  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `inline; filename="staff-${staff.displayName}.ics"`
    }
  })
}
