import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { generateIcs } from "@/lib/ical"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const salon = await prisma.salon.findUnique({ where: { id: params.id } })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  const list = await prisma.booking.findMany({
    where: { salonId: salon.id, status: "CONFIRMED" },
    include: { service: true },
    orderBy: { start: "asc" }
  })
  const events = list.map(b => ({
    uid: b.id,
    title: `${b.service.name} – ${salon.name}`,
    start: b.start,
    end: b.end,
    url: `${process.env.NEXTAUTH_URL}/owner/salons/${salon.id}`,
    location: `${salon.address}, ${salon.postalCode} ${salon.city}`
  }))
  const ics = generateIcs(events)
  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `inline; filename="salon-${salon.slug}.ics"`
    }
  })
}
