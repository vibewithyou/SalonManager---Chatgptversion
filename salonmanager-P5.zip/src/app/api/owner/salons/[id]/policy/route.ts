import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, isOwnerOfSalon } from "@/lib/user"
import { salonPolicySchema } from "@/lib/validators"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const ok = (session.user as any).role === "ADMIN" || await isOwnerOfSalon((session.user as any).id, params.id)
  if (!ok) return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const pol = await prisma.salonPolicy.findUnique({ where: { salonId: params.id } })
  return NextResponse.json(pol ?? { cancellationMinHours: 2, noShowStrikeWindowDays: 30, noShowMaxBeforeFlag: 3 })
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const ok = (session.user as any).role === "ADMIN" || await isOwnerOfSalon((session.user as any).id, params.id)
  if (!ok) return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const input = salonPolicySchema.parse(await req.json())
  const up = await prisma.salonPolicy.upsert({
    where: { salonId: params.id },
    update: input,
    create: { salonId: params.id, ...input }
  })
  return NextResponse.json(up)
}
