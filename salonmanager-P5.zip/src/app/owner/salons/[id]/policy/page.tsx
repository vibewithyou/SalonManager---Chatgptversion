"use client"

import { useEffect, useState } from "react"
import { useToast } from "@/components/ToastProvider"

export default function PolicyPage({ params }: { params: { id: string } }) {
  const [data, setData] = useState<any>(null)
  const notify = useToast()
  useEffect(()=>{ fetch(`/api/owner/salons/${params.id}/policy`).then(r=>r.json()).then(setData) },[params.id])

  async function save() {
    const res = await fetch(`/api/owner/salons/${params.id}/policy`, {
      method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify(data)
    })
    notify({ type: res.ok ? "success":"error", message: res.ok ? "Gespeichert":"Fehler" })
  }

  if (!data) return <div className="card">Lade…</div>
  return (
    <div className="grid gap-4 max-w-lg">
      <h1 className="text-2xl font-semibold text-gold">Buchungsrichtlinien</h1>
      <label className="text-sm">Stornierung bis (Std.)</label>
      <input className="input" type="number" value={data.cancellationMinHours} onChange={e=>setData({...data, cancellationMinHours: Number(e.target.value)})}/>
      <label className="text-sm">No-Show-Fenster (Tage)</label>
      <input className="input" type="number" value={data.noShowStrikeWindowDays} onChange={e=>setData({...data, noShowStrikeWindowDays: Number(e.target.value)})}/>
      <label className="text-sm">Max. No-Shows vor Flag</label>
      <input className="input" type="number" value={data.noShowMaxBeforeFlag} onChange={e=>setData({...data, noShowMaxBeforeFlag: Number(e.target.value)})}/>
      <button className="btn w-max" onClick={save}>Speichern</button>
    </div>
  )
}
