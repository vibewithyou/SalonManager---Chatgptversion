import { createEvents } from "ics"

export function generateIcs(events: Array<{
  uid: string
  title: string
  description?: string
  start: Date
  end: Date
  url?: string
  location?: string
}>) {
  const icsEvents = events.map(e => ({
    uid: e.uid,
    productId: "SalonManager",
    title: e.title,
    description: e.description || "",
    start: [e.start.getUTCFullYear(), e.start.getUTCMonth()+1, e.start.getUTCDate(), e.start.getUTCHours(), e.start.getUTCMinutes()],
    end: [e.end.getUTCFullYear(), e.end.getUTCMonth()+1, e.end.getUTCDate(), e.end.getUTCHours(), e.end.getUTCMinutes()],
    startInputType: "utc",
    endInputType: "utc",
    url: e.url,
    location: e.location,
    status: "CONFIRMED",
  }))

  const { error, value } = createEvents(icsEvents)
  if (error) throw error
  return value
}
