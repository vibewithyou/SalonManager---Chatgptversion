import { describe, it, expect } from "vitest"
import { DateTime } from "luxon"
import { _hm } from "./availability"

describe("DST helpers", () => {
  it("hm parses correctly", () => {
    expect(_hm("09:30")).toBe(9*60+30)
  })

  it("DST spring forward (Europe/Berlin) skips 02:00-02:59", () => {
    const tz = "Europe/Berlin"
    const d = DateTime.fromISO("2025-03-30T02:30:00", { zone: tz })
    expect(d.hour).toBe(3)
  })

  it("DST fall back repeats hour", () => {
    const tz = "Europe/Berlin"
    const first = DateTime.fromISO("2025-10-26T02:30:00+02:00", { zone: tz })
    const second = DateTime.fromISO("2025-10-26T02:30:00+01:00", { zone: tz })
    expect(second.toMillis() - first.toMillis()).toBe(3600_000)
  })
})
