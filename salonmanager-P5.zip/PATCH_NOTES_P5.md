# Phase P5 — DST-Tests, iCal-Feeds, No-Show/Cancel-Policies

This package contains **bolt.new-ready** files to drop into your repo, plus notes for lines you need to patch in-place.

## New / Replaced files (add these)
- `src/app/api/owner/salons/[id]/policy/route.ts`
- `src/app/owner/salons/[id]/policy/page.tsx`
- `src/app/api/bookings/[id]/cancel/route.ts`
- `src/app/api/bookings/[id]/no-show/route.ts`
- `src/lib/ical.ts`
- `src/app/api/ical/salon/[id]/route.ts`
- `src/app/api/ical/staff/[id]/route.ts`
- `src/lib/availability.dst.test.ts`

## Modify existing (apply manually)
- `prisma/schema.prisma`:
  - Add `SalonPolicy` model and relations
  - Add fields `cancelledAt` and `noShow` to `Booking`
  - Add field `noShowCount` to `User`
- `src/lib/validators.ts`:
  - Add `salonPolicySchema` from Phase P5
- `src/app/owner/salons/[id]/page.tsx`:
  - Add nav tab link to `/owner/salons/[id]/policy`
- `src/app/staff/agenda/page.tsx`:
  - Insert `<NoShowButton id={b.id} />` on each booking row as shown in the patch
- `src/lib/metrics.ts` and `src/app/admin/analytics/page.tsx`:
  - Extend analytics to include `noShows` and `noShowRate` and render two new cards

## Dependencies
Add to `package.json` dependencies:
```json
{ "ics": "^2.41.0" }
```

## Migrations
Run after updating schema:
```
pnpm prisma:generate && pnpm prisma:migrate
```
