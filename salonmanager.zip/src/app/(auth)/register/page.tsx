"use client"

import { useState } from "react"

export default function RegisterPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [ok, setOk] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setErr(null)
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, name })
    })
    if (res.ok) setOk(true)
    else setErr("Registrierung fehlgeschlagen")
  }

  return (
    <div className="mx-auto max-w-md card">
      <h1 className="mb-4 text-2xl font-semibold text-gold">Registrieren</h1>
      {ok ? (
        <p className="text-sm">Account erstellt. <a href="/login" className="underline hover:text-gold">Zum Login</a></p>
      ) : (
        <form onSubmit={onSubmit} className="grid gap-3">
          <input className="input" placeholder="Name (optional)" value={name} onChange={e=>setName(e.target.value)} />
          <input className="input" placeholder="E-Mail" type="email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" placeholder="Passwort (min. 6 Zeichen)" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          {err && <p className="text-danger text-sm">{err}</p>}
          <button className="btn">Account anlegen</button>
        </form>
      )}
    </div>
  )
}
