# SalonManager (Next.js 14, TS, App Router)

PWA-Webapp für Salons: Suche, Buchung, Owner/Staff-Backoffice. Dieses Repo enthält Setup, Auth, RBAC, Seed und Basis-Seiten.  
**Stack:** Next.js 14 • Tailwind • Prisma/Postgres • NextAuth (Credentials) • Leaflet • UploadThing • Resend • Zod • Vitest • Playwright • next-pwa

## Schnellstart

1. `cp .env.example .env` und Variablen setzen
2. `pnpm i` (oder `npm i`/`yarn`)
3. `pnpm prisma:generate && pnpm prisma:migrate`
4. `pnpm db:seed`
5. `pnpm dev` → http://localhost:3000

**Demo-Logins:**  
- admin@demo.tld / Admin123!  
- owner@demo.tld / Owner123!  
- staff1@demo.tld / Staff123!  
- customer@demo.tld / Customer123!

## Nächste Schritte (in folgenden Teilen)
- REST-APIs (Suche, Verfügbarkeit, Buchung, CRUD)
- Owner/Staff/Me-Screens
- Uploads (UploadThing) & Medien
- Leaflet-Karte
- PWA-Offline-Shell
- Tests (Vitest/Playwright)
- CI/CD (GitHub Actions)
