import { PrismaClient } from "@prisma/client"
const prisma = new PrismaClient()

// Parse "HH:MM" into minutes since 00:00
const hm = (s: string) => {
  const [h, m] = s.split(":").map(Number)
  return h * 60 + m
}

export async function getAvailableSlots(opts: {
  salonId: string
  serviceId: string
  date: string // YYYY-MM-DD
}) {
  const { salonId, serviceId, date } = opts
  const service = await prisma.service.findUnique({ where: { id: serviceId } })
  if (!service) return []

  // Opening hours of that weekday
  const d = new Date(date + "T00:00:00")
  const weekday = (d.getDay() + 6) % 7
  const oh = await prisma.openingHour.findFirst({ where: { salonId, weekday } })
  if (!oh || oh.isClosed) return []

  const openM = hm(oh.openTime)
  const closeM = hm(oh.closeTime)

  // Staff availability windows overlapping that day
  const dayStart = new Date(d)
  const dayEnd = new Date(d)
  dayEnd.setHours(23, 59, 59, 999)

  const schedules = await prisma.schedule.findMany({
    where: { staff: { salonId }, start: { lte: dayEnd }, end: { gte: dayStart }, isAvailable: true },
    include: { staff: true }
  })

  if (schedules.length === 0) return []

  // Existing confirmed bookings that day
  const confirmed = await prisma.booking.findMany({
    where: { salonId, status: "CONFIRMED", start: { lte: dayEnd }, end: { gte: dayStart } },
    select: { start: true, end: true, staffId: true }
  })

  // Create time grid in service.durationMin steps inside opening hours
  const dur = service.durationMin
  const slots: { start: Date; end: Date; staffId: string }[] = []

  for (const sch of schedules) {
    // clamp schedule to opening hours window
    const schStartM = Math.max(
      (sch.start.getHours() * 60 + sch.start.getMinutes()),
      openM
    )
    const schEndM = Math.min(
      (sch.end.getHours() * 60 + sch.end.getMinutes()),
      closeM
    )
    for (let t = schStartM; t + dur <= schEndM; t += dur) {
      const start = new Date(d)
      start.setHours(0, t, 0, 0)
      const end = new Date(start.getTime() + dur * 60000)

      // overlap with confirmed?
      const overlap = confirmed.some(b =>
        b.staffId === sch.staffId &&
        !(end <= b.start || start >= b.end)
      )
      if (!overlap) {
        slots.push({ start, end, staffId: sch.staffId })
      }
    }
  }

  // Optionally: unique by start time across staff
  return slots.sort((a, b) => a.start.getTime() - b.start.getTime())
}
