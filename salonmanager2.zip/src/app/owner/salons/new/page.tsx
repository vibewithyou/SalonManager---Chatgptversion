import { redirect } from "next/navigation"
import { prisma } from "@/lib/prisma"
import { salonUpsertSchema } from "@/lib/validators"
import { auth } from "@/auth"

export const dynamic = "force-dynamic"

async function createSalon(formData: FormData) {
  "use server"
  const session = await auth()
  if (!session?.user) throw new Error("UNAUTHORIZED")
  const body = {
    name: String(formData.get("name") || ""),
    slug: String(formData.get("slug") || ""),
    address: String(formData.get("address") || ""),
    city: String(formData.get("city") || ""),
    postalCode: String(formData.get("postalCode") || ""),
    country: String(formData.get("country") || "DE"),
    latitude: Number(formData.get("latitude") || "0"),
    longitude: Number(formData.get("longitude") || "0"),
    description: String(formData.get("description") || "")
  }
  const data = salonUpsertSchema.parse(body)
  const created = await prisma.salon.create({ data: { ...data, ownerId: (session.user as any).id } })
  redirect(`/owner/salons/${created.id}`)
}

export default function NewSalonPage() {
  return (
    <form action={createSalon} className="card grid gap-3 max-w-2xl">
      <h1 className="text-2xl font-semibold text-gold">Salon anlegen</h1>
      <input className="input" name="name" placeholder="Name" required />
      <input className="input" name="slug" placeholder="slug (kebab-case)" required />
      <input className="input" name="address" placeholder="Adresse" required />
      <div className="grid grid-cols-3 gap-3">
        <input className="input" name="city" placeholder="Stadt" required />
        <input className="input" name="postalCode" placeholder="PLZ" required />
        <input className="input" name="country" placeholder="Land" defaultValue="DE" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <input className="input" name="latitude" placeholder="Latitude" type="number" step="any" required />
        <input className="input" name="longitude" placeholder="Longitude" type="number" step="any" required />
      </div>
      <textarea className="input" name="description" placeholder="Beschreibung" />
      <button className="btn">Erstellen</button>
    </form>
  )
}
