import Link from "next/link"

export default function HomePage() {
  // Später: echte Filters + Leaflet-Map + Ergebnisliste
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <section className="md:col-span-2 card">
        <h1 className="mb-4 text-2xl font-semibold text-gold">Finde deinen Salon</h1>
        <form className="grid gap-3 md:grid-cols-3">
          <input className="input" placeholder="Stadt" name="city" />
          <input className="input" placeholder="Tags (Komma)" name="tags" />
          <input className="input" placeholder="Preis bis (€)" name="priceMax" type="number" />
          <button className="btn md:col-span-3">Suchen</button>
        </form>
      </section>
      <aside className="card">
        <h2 className="mb-2 font-medium">Demo</h2>
        <p className="text-sm text-muted mb-3">
          Seed erstellt einen Demo-Salon „BARBERs Freiberg“.
        </p>
        <Link href="/salon/barbers-freiberg" className="underline hover:text-gold">Zum Salon</Link>
      </aside>
      <section className="md:col-span-3 card">
        <div className="h-[420px] w-full rounded border border-border bg-[#0f0f0f] grid place-items-center">
          <span className="text-muted">Karte (Leaflet) – folgt</span>
        </div>
      </section>
    </div>
  )
}
