import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { searchParamsSchema, salonUpsertSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function GET(req: Request) {
  const url = new URL(req.url)
  const parsed = searchParamsSchema.parse(Object.fromEntries(url.searchParams.entries()))
  const where: any = { isPublished: true }

  if (parsed.city) where.city = { contains: parsed.city, mode: "insensitive" }
  if (parsed.query) {
    where.OR = [
      { name: { contains: parsed.query, mode: "insensitive" } },
      { description: { contains: parsed.query, mode: "insensitive" } }
    ]
  }
  if (parsed.tags) {
    const tagArr = parsed.tags.split(",").map(s => s.trim()).filter(Boolean)
    if (tagArr.length) {
      where.tags = { some: { tag: { name: { in: tagArr } } } }
    }
  }

  const salons = await prisma.salon.findMany({
    where,
    select: {
      id: true, name: true, slug: true, city: true, address: true, latitude: true, longitude: true,
      services: { select: { priceCents: true } },
      media: { where: { type: "LOGO" }, select: { url: true }, take: 1 }
    },
    orderBy: { createdAt: "desc" }
  })

  return NextResponse.json(salons)
}

export async function POST(req: Request) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const body = await req.json()
  const data = salonUpsertSchema.parse(body)

  const created = await prisma.salon.create({
    data: {
      ...data,
      ownerId: (session.user as any).id,
      tags: data.tags && data.tags.length
        ? { create: data.tags.map(name => ({ tag: { connectOrCreate: { where: { name }, create: { name } } } })) }
        : undefined
    }
  })
  return NextResponse.json(created, { status: 201 })
}
