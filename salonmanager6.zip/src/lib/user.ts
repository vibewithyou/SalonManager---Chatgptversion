import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"

export async function getSessionOrThrow() {
  const session = await auth()
  if (!session?.user) throw new Error("UNAUTHORIZED")
  return session
}

export async function getStaffProfileForUser(userId: string) {
  return prisma.staffProfile.findFirst({ where: { userId }, include: { salon: true } })
}

export async function isOwnerOfSalon(userId: string, salonId: string) {
  const salon = await prisma.salon.findUnique({ where: { id: salonId }, select: { ownerId: true } })
  return !!salon && salon.ownerId === userId
}
