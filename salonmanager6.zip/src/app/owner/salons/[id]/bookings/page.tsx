"use client"

import useSWR from "swr"
import { useState } from "react"

const fetcher = (u: string) => fetch(u).then(r=>r.json())

export default function OwnerBookings({ params }: { params: { id: string } }) {
  const { data, mutate } = useSWR(`/api/owner/salons/${params.id}/bookings`, fetcher)
  const [saving, setSaving] = useState<string | null>(null)

  async function update(id: string, body: any) {
    setSaving(id)
    await fetch(`/api/bookings/${id}`, { method: "PATCH", headers: { "Content-Type":"application/json" }, body: JSON.stringify(body) })
    setSaving(null)
    mutate()
  }

  if (!data) return <div className="card">Lade…</div>

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Buchungen</h1>
      <ul className="grid gap-2">
        {data.list.map((b: any) => (
          <li key={b.id} className="card text-sm flex items-center justify-between gap-3">
            <div>
              <div className="font-medium">{new Date(b.start).toLocaleString()} — {b.service.name}</div>
              <div className="text-muted">{b.customer.email}</div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`badge ${b.status.toLowerCase()}`}>{b.status}</span>
              <select
                className="input w-40"
                value={b.staffId ?? ""}
                onChange={e => update(b.id, { staffId: e.target.value || null })}
              >
                <option value="">— keine Zuweisung —</option>
                {data.staff.map((s: any)=>(
                  <option key={s.id} value={s.id}>{s.displayName}</option>
                ))}
              </select>
              <button disabled={saving===b.id} className="btn" onClick={()=>update(b.id, { status: "CONFIRMED" })}>Bestätigen</button>
              <button disabled={saving===b.id} className="inline-flex items-center rounded px-3 py-1 border border-danger text-danger hover:bg-red-950"
                onClick={()=>update(b.id, { status: "DECLINED" })}
              >Ablehnen</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
