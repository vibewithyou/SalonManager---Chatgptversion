"use client"

import dynamic from "next/dynamic"
import { useEffect, useState } from "react"
import L from "leaflet"
import { nominatimSearch } from "@/lib/geocode"

const MapContainer = dynamic(() => import("react-leaflet").then(m => m.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import("react-leaflet").then(m => m.TileLayer), { ssr: false })
const Marker = dynamic(() => import("react-leaflet").then(m => m.Marker), { ssr: false })

const icon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41]
})

export function MapPicker({
  lat, lng, onChange
}: { lat: number; lng: number; onChange: (lat: number, lng: number) => void }) {
  const [pos, setPos] = useState<[number, number]>([lat || 51.0, lng || 10.0])
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<any[]>([])

  useEffect(() => { setPos([lat, lng]) }, [lat, lng])

  async function search() {
    if (!query.trim()) return
    const res = await nominatimSearch(query.trim())
    setResults(res)
    if (res[0]) {
      const nlat = parseFloat(res[0].lat), nlon = parseFloat(res[0].lon)
      setPos([nlat, nlon])
      onChange(nlat, nlon)
    }
  }

  function onMapClick(e: any) {
    const { lat, lng } = e.latlng
    setPos([lat, lng])
    onChange(lat, lng)
  }

  return (
    <div className="grid gap-2">
      <div className="flex gap-2">
        <input className="input" placeholder="Adresse/Stadt" value={query} onChange={e=>setQuery(e.target.value)} />
        <button type="button" className="btn" onClick={search}>Suchen</button>
      </div>
      {results.length > 0 && (
        <ul className="text-xs text-muted">
          {results.map((r,i)=>(<li key={i}>{r.display_name}</li>))}
        </ul>
      )}
      <div className="h-72 rounded border border-border overflow-hidden">
        <MapContainer center={pos as any} zoom={13} style={{ height: "100%", width: "100%" }} onclick={onMapClick as any}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OSM contributors' />
          <Marker position={pos as any} icon={icon} />
        </MapContainer>
      </div>
    </div>
  )
}
