import { test, expect } from "@playwright/test"

test("booking wizard basic", async ({ page }) => {
  await page.goto("/salon/barbers-freiberg/book")
  await page.getByLabel(/Leistung/i).selectOption({ index: 1 })
  const today = new Date(); const ymd = today.toISOString().slice(0,10)
  await page.getByLabel(/Datum/i).fill(ymd)
  await page.getByRole("button", { name: /Suchen|Lade|Verfügbare|^\d{2}:\d{2}$/ }).first().waitFor()
  // Slot Buttons haben Uhrzeit – wählen den ersten, wenn vorhanden
  const slots = page.locator("button:has-text(':')")
  const count = await slots.count()
  if (count > 0) {
    await slots.first().click()
    await expect(page.getByText(/Anfrage gesendet|Fehler/)).toBeVisible()
  } else {
    test.skip(true, "Keine Slots (abhängig von Seed/Uhrzeit)")
  }
})
