import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: ["class"],
  content: ["./src/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "#121212",
        surface: "#181818",
        border: "#2A2A2A",
        muted: "#A3A3A3",
        gold: { DEFAULT: "#D4AF37", hover: "#C19A2E" },
        text: "#E0E0E0",
        danger: "#ef4444"
      },
      borderRadius: { DEFAULT: "12px" }
    }
  },
  plugins: [require("tailwindcss-animate")]
}
export default config
