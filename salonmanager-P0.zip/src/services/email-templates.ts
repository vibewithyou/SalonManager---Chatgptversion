export function baseTemplate(title: string, bodyHtml: string) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="color-scheme" content="dark">
  <style>body{background:#121212;color:#E0E0E0;font-family:Inter,Segoe UI,Arial,sans-serif}
  .card{margin:0 auto;max-width:560px;padding:24px;background:#181818;border:1px solid #2A2A2A;border-radius:12px}
  .btn{display:inline-block;background:#D4AF37;color:#000;padding:10px 16px;border-radius:8px;text-decoration:none}
  .muted{color:#A3A3A3;font-size:12px}</style></head>
  <body><div class="card">
    <h2 style="color:#D4AF37;margin:0 0 12px 0">${title}</h2>
    ${bodyHtml}
    <p class="muted" style="margin-top:24px">SalonManager • Automatische Benachrichtigung</p>
  </div></body></html>`
}

export function bookingRequestTemplate(salon: string, service: string, dateStr: string) {
  return baseTemplate("Neue Buchungsanfrage",
  `<p>Es gibt eine neue Anfrage für <b>${service}</b> am <b>${dateStr}</b>.</p>`)
}

export function bookingStatusTemplate(status: string) {
  return baseTemplate("Aktualisierung deiner Buchung",
  `<p>Dein Buchungsstatus wurde auf <b>${status}</b> geändert.</p>`)
}

export function staffInviteTemplate(salon: string, link: string) {
  return baseTemplate("Einladung zum Salon",
  `<p>Du wurdest zu <b>${salon}</b> eingeladen.</p><p><a class="btn" href="${link}">Einladung annehmen</a></p>`)
}
