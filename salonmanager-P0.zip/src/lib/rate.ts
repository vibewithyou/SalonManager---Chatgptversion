type Bucket = { ts: number; hits: number }
const store = new Map<string, Bucket>()
export function rateLimit(ip: string, key: string, max = 20, windowMs = 60_000) {
  const now = Date.now()
  const k = `${ip}:${key}`
  const b = store.get(k)
  if (!b || now - b.ts > windowMs) { store.set(k, { ts: now, hits: 1 }); return true }
  // Sliding window approximation
  const elapsed = now - b.ts
  const ratio = Math.max(0, 1 - elapsed / windowMs)
  const effective = Math.floor(b.hits * ratio) + 1
  if (effective > max) return false
  store.set(k, { ts: now, hits: effective })
  return true
}
