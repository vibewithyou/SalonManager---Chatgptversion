import { z } from "zod"

export const passwordPolicy = z.string()
  .min(8, "mindestens 8 Zeichen")
  .regex(/[A-Z]/, "mindestens 1 Großbuchstabe")
  .regex(/[a-z]/, "mindestens 1 Kleinbuchstabe")
  .regex(/[0-9]/, "mindestens 1 Ziffer")
  .regex(/[^A-Za-z0-9]/, "mindestens 1 Sonderzeichen")

export const trimString = (s: unknown) => (typeof s === "string" ? s.trim() : s)
export const trimObject = <T extends Record<string, any>>(obj: T) =>
  Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, trimString(v)])) as T


export const salonUpsertSchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/),
  description: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  website: z.string().url().optional(),
  address: z.string().min(3),
  city: z.string().min(2),
  postalCode: z.string().min(3),
  country: z.string().min(2),
  latitude: z.number(),
  longitude: z.number(),
  isPublished: z.boolean().optional().default(false),
  tags: z.array(z.string()).optional()
})

export const serviceSchema = z.object({
  salonId: z.string().cuid(),
  name: z.string().min(2),
  description: z.string().optional(),
  durationMin: z.number().int().min(5).max(8 * 60),
  priceCents: z.number().int().min(0),
  isActive: z.boolean().optional().default(true)
})

export const servicePatchSchema = serviceSchema.partial().extend({
  id: z.string().cuid().optional()
})

export const openingHourSchema = z.object({
  salonId: z.string().cuid(),
  weekday: z.number().int().min(0).max(6),
  openTime: z.string().regex(/^\d{2}:\d{2}$/),
  closeTime: z.string().regex(/^\d{2}:\d{2}$/),
  isClosed: z.boolean().optional().default(false)
})

export const scheduleSchema = z.object({
  staffId: z.string().cuid(),
  start: z.string().or(z.date()).transform(v => new Date(v)),
  end: z.string().or(z.date()).transform(v => new Date(v)),
  isAvailable: z.boolean().default(true)
})

export const bookingCreateSchema = z.object({
  salonId: z.string().cuid(),
  serviceId: z.string().cuid(),
  start: z.string().or(z.date()).transform(v => new Date(v)),
  note: z.string().optional(),
  imageUrl: z.string().url().optional()
})

export const bookingPatchSchema = z.object({
  status: z.enum(["PENDING", "CONFIRMED", "DECLINED", "CANCELLED"]).optional(),
  staffId: z.string().cuid().nullable().optional(),
  start: z.string().or(z.date()).transform(v => new Date(v)).optional(),
  end: z.string().or(z.date()).transform(v => new Date(v)).optional()
})

export const searchParamsSchema = z.object({
  query: z.string().optional(),
  city: z.string().optional(),
  tags: z.string().optional(), // comma-separated
  priceMin: z.string().optional(),
  priceMax: z.string().optional(),
  availableFrom: z.string().optional(),
  availableTo: z.string().optional()
})
