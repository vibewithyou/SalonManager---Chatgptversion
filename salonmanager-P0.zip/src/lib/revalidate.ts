import { revalidateTag } from "next/cache"
export function revalidate(tag: string) {
  // Wrapper für konsistente Verwendung
  try { revalidateTag(tag) } catch {}
}
