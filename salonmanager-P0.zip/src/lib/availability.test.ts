import { describe, it, expect } from "vitest"
import { _hm, _overlap } from "./availability"

describe("availability helpers", () => {
  it("parses HH:MM to minutes", () => {
    expect(_hm("00:00")).toBe(0)
    expect(_hm("09:30")).toBe(9 * 60 + 30)
    expect(_hm("18:00")).toBe(18 * 60)
  })
  it("detects overlap correctly", () => {
    const a = { start: new Date("2025-01-01T10:00:00"), end: new Date("2025-01-01T10:30:00") }
    const b = { start: new Date("2025-01-01T10:15:00"), end: new Date("2025-01-01T10:45:00") }
    const c = { start: new Date("2025-01-01T10:30:00"), end: new Date("2025-01-01T11:00:00") }
    expect(_overlap(a, b)).toBe(true)
    expect(_overlap(a, c)).toBe(false)
  })
})
