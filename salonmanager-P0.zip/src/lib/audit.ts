import { prisma } from "@/lib/prisma"

export async function audit(opts: {
  userId?: string | null
  action: string
  entity?: string
  meta?: any
  ip?: string | null
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: opts.userId ?? null,
        action: opts.action,
        entity: opts.entity,
        meta: opts.meta ?? {},
        ip: opts.ip ?? undefined
      }
    })
  } catch {}
}
