import { Role } from "@prisma/client"

export type RoleName = keyof typeof Role

export function hasRole(userRole: Role, allowed: Role[]): boolean {
  return allowed.includes(userRole)
}

export const Guards = {
  CUSTOMER: [Role.CUSTOMER, Role.ADMIN],
  STAFF: [Role.STAFF, Role.ADMIN],
  OWNER: [Role.OWNER, Role.ADMIN],
  ADMIN: [Role.ADMIN]
}
