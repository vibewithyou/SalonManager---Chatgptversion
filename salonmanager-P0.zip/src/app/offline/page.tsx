export default function Offline() {
  return (
    <div className="card">
      <h1 className="text-2xl font-semibold text-gold">Offline</h1>
      <p className="text-sm text-muted mt-2">Du bist offline. Einige Bereiche sind im PWA-Cache verfügbar.</p>
      <ul className="mt-3 text-sm list-disc pl-5">
        <li>Home</li>
        <li>Salonprofil (zuletzt besuchte)</li>
        <li>Meine Buchungen (read-only, zuletzt geladen)</li>
      </ul>
    </div>
  )
}
