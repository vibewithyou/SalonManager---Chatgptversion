"use client"

import { useState } from "react"
import { signIn } from "next-auth/react"
import { useRouter, useSearchParams } from "next/navigation"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [totp, setTotp] = useState("")
  const [err, setErr] = useState<string | null>(null)
  const router = useRouter()
  const params = useSearchParams()
  const callbackUrl = params.get("callbackUrl") ?? "/"

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setErr(null)
    const res = await signIn("credentials", { email, password, totp, redirect: false, callbackUrl })
    if (res?.ok) router.push(callbackUrl)
    else setErr("Login fehlgeschlagen")
  }

  return (
    <div className="card max-w-sm mx-auto">
      <h1 className="mb-4 text-2xl font-semibold text-gold">Login</h1>
      <form onSubmit={onSubmit} className="grid gap-3">
        <input className="input" placeholder="E-Mail" type="email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" placeholder="Passwort" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <input className="input" placeholder="2FA Code (falls aktiviert)" value={totp} onChange={e=>setTotp(e.target.value)} />
        {err && <p className="text-danger text-sm">{err}</p>}
        <button className="btn" type="submit">Einloggen</button>
      </form>
      <p className="mt-4 text-sm text-muted">
        Neu hier? <a className="underline hover:text-gold" href="/register">Account erstellen</a>
      </p>
    </div>
  )
}
