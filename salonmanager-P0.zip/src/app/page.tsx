"use client"

import useSWR from "swr"
import Link from "next/link"
import { SalonsMap } from "@/components/Map"

const fetcher = (url: string) => fetch(url).then(r => r.json())

export default function HomePage() {
  const { data } = useSWR("/api/salons", fetcher)

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <section className="md:col-span-2 card">
        <h1 className="mb-4 text-2xl font-semibold text-gold">Finde deinen Salon</h1>
        <form className="grid gap-3 md:grid-cols-3">
          <input className="input" placeholder="Stadt" name="city" />
          <input className="input" placeholder="Tags (Komma)" name="tags" />
          <input className="input" placeholder="Preis bis (€)" name="priceMax" type="number" />
          <button className="btn md:col-span-3">Suchen</button>
        </form>
      </section>
      <aside className="card">
        <h2 className="mb-2 font-medium">Demo</h2>
        <p className="text-sm text-muted mb-3">Seed erstellt einen Demo-Salon „BARBERs Freiberg“.</p>
        <Link href="/salon/barbers-freiberg" className="underline hover:text-gold">Zum Salon</Link>
      </aside>

      <section className="md:col-span-2 card">
        {data ? <SalonsMap salons={data} /> : <div className="h-[420px] grid place-items-center text-muted">Lade Karte…</div>}
      </section>

      <section className="card">
        <h2 className="mb-2 font-medium">Ergebnisse</h2>
        <ul className="grid gap-2">
          {data?.map((s: any) => (
            <li key={s.id} className="flex items-center justify-between border border-border rounded p-3">
              <div>
                <div className="font-medium">{s.name}</div>
                <div className="text-sm text-muted">{s.city} • {s.address}</div>
              </div>
              <Link href={`/salon/${s.slug}`} className="btn">Ansehen</Link>
            </li>
          )) ?? <li className="text-sm text-muted">Keine Ergebnisse</li>}
        </ul>
      </section>
    </div>
  )
}
