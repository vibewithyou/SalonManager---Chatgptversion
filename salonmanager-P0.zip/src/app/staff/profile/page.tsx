"use client"

import { useState } from "react"
import { useToast } from "@/components/ToastProvider"

export default function ProfilePage() {
  const [qr, setQr] = useState<string | null>(null)
  const [code, setCode] = useState("")
  const notify = useToast()

  async function start() {
    const res = await fetch("/api/2fa/setup", { method: "POST" })
    const j = await res.json()
    setQr(j.svg)
  }
  async function enable() {
    const res = await fetch("/api/2fa/enable", { method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify({ code }) })
    notify({ type: res.ok ? "success" : "error", message: res.ok ? "2FA aktiviert" : "Code ungültig" })
  }

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Profil</h1>
      <div className="card grid gap-3 max-w-lg">
        <h2 className="font-medium">2FA (TOTP)</h2>
        <button className="btn w-max" onClick={start}>Einrichtung starten</button>
        {qr && <div className="border border-border rounded p-3" dangerouslySetInnerHTML={{ __html: qr }} />}
        <input className="input max-w-xs" placeholder="6-stelliger Code" value={code} onChange={e=>setCode(e.target.value)} />
        <button className="btn w-max" onClick={enable}>2FA aktivieren</button>
      </div>
    </div>
  )
}
