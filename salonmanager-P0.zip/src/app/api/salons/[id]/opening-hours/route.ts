import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { openingHourSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const list = await prisma.openingHour.findMany({ where: { salonId: params.id }, orderBy: { weekday: "asc" } })
  return NextResponse.json(list)
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)
  const salon = await prisma.salon.findUnique({ where: { id: params.id } })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && salon.ownerId !== (session.user as any).id)
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const body = await req.json()
  const data = openingHourSchema.parse({ ...body, salonId: params.id })
  const created = await prisma.openingHour.create({ data })
  return NextResponse.json(created, { status: 201 })
}
