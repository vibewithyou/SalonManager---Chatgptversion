import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { salonUpsertSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function PATCH(_req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const salon = await prisma.salon.findUnique({ where: { id: params.id } })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  // Owner guard
  if ((session.user as any).role !== "ADMIN" && salon.ownerId !== (session.user as any).id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const data = salonUpsertSchema.partial().parse(await _req.json())

  // Whitelist: nur bestimmte Felder änderbar je Rolle
  const role = (session.user as any).role as string
  const allowedKeysOwner = new Set([
    "name","slug","description","phone","email","website",
    "address","city","postalCode","country","latitude","longitude","isPublished","tags"
  ])
  const allowedKeysStaff = new Set<string>([]) // Staff darf hier nichts
  const allowed = role === "ADMIN" ? null : role === "OWNER" ? allowedKeysOwner : allowedKeysStaff
  let filtered: any = data
  if (allowed) {
    filtered = Object.fromEntries(Object.entries(data).filter(([k]) => allowed.has(k)))
  }

  const updated = await prisma.salon.update({
    where: { id: params.id },
    data: {
      ...filtered,
      // tags update (replace)
      ...(filtered.tags
        ? {
            tags: {
              deleteMany: {},
              create: filtered.tags.map((name: string) => ({
                tag: { connectOrCreate: { where: { name }, create: { name } } }
              }))
            }
          }
        : {})
    }
  })
  return NextResponse.json(updated)
}
