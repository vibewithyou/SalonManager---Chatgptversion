import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"
import { randomBytes } from "crypto"
import { sendMail } from "@/services/email"
import { rateLimit } from "@/lib/rate"
import { audit } from "@/lib/audit"

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local"
  if (!rateLimit(ip, "staff-invite", 5, 60_000)) return NextResponse.json({ error: "Too many requests" }, { status: 429 })
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const { email, displayName } = await req.json() as { email: string; displayName?: string }
  if (!email) return NextResponse.json({ error: "email required" }, { status: 400 })

  const salon = await prisma.salon.findUnique({ where: { id: params.id } })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && salon.ownerId !== (session.user as any).id)
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const token = randomBytes(24).toString("hex")
  await prisma.media.create({
    // simple token store using Media (to avoid extra model) — could be Invite model in future
    data: { salonId: salon.id, type: "INVITE", url: token, alt: email }
  })

  const link = `${process.env.NEXTAUTH_URL}/staff/accept-invite?token=${token}`
  await sendMail(email, "Einladung zum Salon", `
    <h3 style="color:#D4AF37">Einladung</h3>
    <p>Du wurdest zu <b>${salon.name}</b> eingeladen.</p>
    <p><a href="${link}" style="color:#D4AF37">Einladung annehmen</a></p>
  `)

  await audit({ userId: (session.user as any).id, action: "STAFF_INVITE", entity: `Salon:${params.id}`, meta: { email } })
  return NextResponse.json({ ok: true })
}
