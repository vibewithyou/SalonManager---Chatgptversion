import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, isOwnerOfSalon } from "@/lib/user"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const role = (session.user as any).role as string

  if (role !== "ADMIN" && !(await isOwnerOfSalon(userId, params.id))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const salon = await prisma.salon.findUnique({
    where: { id: params.id },
    select: {
      id: true, name: true, slug: true, description: true,
      phone: true, email: true, website: true,
      address: true, city: true, postalCode: true, country: true,
      latitude: true, longitude: true, isPublished: true
    }
  })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  return NextResponse.json(salon)
}
