import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, isOwnerOfSalon } from "@/lib/user"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const role = (session.user as any).role

  if (role !== "ADMIN" && !(await isOwnerOfSalon(userId, params.id))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const [list, staff] = await Promise.all([
    prisma.booking.findMany({
      where: { salonId: params.id },
      include: { service: true, customer: true },
      orderBy: { start: "desc" }
    }),
    prisma.staffProfile.findMany({ where: { salonId: params.id }, select: { id: true, displayName: true } })
  ])
  return NextResponse.json({ list, staff })
}
