import { rateLimit } from "@/lib/rate"
import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local"
  if (!rateLimit(ip, "verify", 5, 60_000)) return NextResponse.json({ error: "Too many requests" }, { status: 429 })
  const { token, email } = await req.json() as { token: string; email: string }
  if (!token || !email) return NextResponse.json({ error: "Missing" }, { status: 400 })

  const vt = await prisma.verificationToken.findFirst({ where: { token, identifier: email } })
  if (!vt || vt.expires < new Date()) return NextResponse.json({ error: "Invalid token" }, { status: 400 })

  await prisma.user.update({ where: { email }, data: { emailVerified: new Date() } })
  await prisma.verificationToken.delete({ where: { token } })
  return NextResponse.json({ ok: true })
}
