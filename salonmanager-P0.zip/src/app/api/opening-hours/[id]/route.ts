import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { openingHourSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const oh = await prisma.openingHour.findUnique({ where: { id: params.id }, include: { salon: true } })
  if (!oh) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && oh.salon.ownerId !== (session.user as any).id)
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const body = await req.json()
  const parsed = openingHourSchema.partial().parse(body)
  const updated = await prisma.openingHour.update({ where: { id: params.id }, data: parsed })
  return NextResponse.json(updated)
}
