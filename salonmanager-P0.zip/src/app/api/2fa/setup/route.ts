import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import speakeasy from "speakeasy"
import QRCode from "qrcode"
import { prisma } from "@/lib/prisma"

export async function POST() {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id

  const secret = speakeasy.generateSecret({ length: 20, name: `SalonManager (${session.user?.email})` })
  const otpauth = secret.otpauth_url!
  const svg = await QRCode.toString(otpauth, { type: "svg" })

  await prisma.user.update({ where: { id: userId }, data: { totpSecret: secret.base32 } })
  return NextResponse.json({ svg, base32: secret.base32 })
}
