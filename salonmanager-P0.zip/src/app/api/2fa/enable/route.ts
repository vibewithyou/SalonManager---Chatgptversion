import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import speakeasy from "speakeasy"
import { prisma } from "@/lib/prisma"

export async function POST(req: Request) {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const { code } = await req.json() as { code: string }
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.totpSecret) return NextResponse.json({ error: "No secret" }, { status: 400 })

  const ok = speakeasy.totp.verify({ secret: user.totpSecret, encoding: "base32", token: code, window: 1 })
  if (!ok) return NextResponse.json({ error: "Invalid code" }, { status: 400 })

  await prisma.user.update({ where: { id: userId }, data: { totpEnabled: true } })
  return NextResponse.json({ ok: true })
}
