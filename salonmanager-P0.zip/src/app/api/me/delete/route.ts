import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import { prisma } from "@/lib/prisma"
import { audit } from "@/lib/audit"

export async function POST() {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id

  await audit({ userId, action: "ACCOUNT_DELETE_REQUEST", entity: `User:${userId}` })
  await prisma.user.update({
    where: { id: userId },
    data: { email: `deleted+${userId}@example.tld`, name: null, hashedPassword: "!", totpEnabled: false, totpSecret: null }
  })
  return NextResponse.json({ ok: true })
}
