import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import { prisma } from "@/lib/prisma"

export async function GET() {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id
  const [user, bookings, staffProfiles] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId }, select: { id:true, email:true, name:true, role:true, createdAt:true } }),
    prisma.booking.findMany({ where: { customerId: userId } }),
    prisma.staffProfile.findMany({ where: { userId } })
  ])
  return NextResponse.json({ user, bookings, staffProfiles })
}
