import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { z } from "zod"
import bcrypt from "bcryptjs"
import crypto from "crypto"
import { sendMail } from "@/services/email"
import { baseTemplate } from "@/services/email-templates"
import { trimObject, passwordPolicy } from "@/lib/validators"

const schema = z.object({
  email: z.string().email(),
  password: passwordPolicy,
  name: z.string().optional()
})

export async function POST(req: Request) {
  const body = trimObject(await req.json())
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.format() }, { status: 400 })
  const { email, password, name } = parsed.data

  const exists = await prisma.user.findUnique({ where: { email } })
  if (exists) return NextResponse.json({ error: "Exists" }, { status: 409 })

  const hashedPassword = await bcrypt.hash(password, 12)
  const user = await prisma.user.create({ data: { email, hashedPassword, name } })

  // E-Mail-Verifikation: Token ausstellen
  const token = crypto.randomBytes(32).toString("hex")
  const expires = new Date(Date.now() + 1000 * 60 * 60 * 24) // 24h
  await prisma.verificationToken.create({
    data: { identifier: email, token, expires }
  })
  const link = `${process.env.NEXTAUTH_URL}/verify-email?token=${token}&email=${encodeURIComponent(email)}`
  await sendMail(email, "E-Mail bestätigen",
    baseTemplate("E-Mail bestätigen", `<p>Bitte bestätige deine E-Mail.</p><p><a class="btn" href="${link}">Jetzt bestätigen</a></p>`, "E-Mail bestätigen"))

  return NextResponse.json({ ok: true, verifySent: true })
}
