"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"

export default function VerifyEmailPage() {
  const sp = useSearchParams()
  const router = useRouter()
  const [msg, setMsg] = useState("Bestätige…")

  useEffect(() => {
    const token = sp.get("token"); const email = sp.get("email")
    if (!token || !email) { setMsg("Ungültiger Link"); return }
    fetch("/api/auth/verify", {
      method: "POST",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ token, email })
    }).then(async r=>{
      setMsg(r.ok ? "E-Mail bestätigt. Du kannst dich jetzt einloggen." : "Token ungültig/abgelaufen.")
      if (r.ok) setTimeout(()=>router.push("/login"), 1500)
    })
  }, [sp, router])

  return <div className="card">{msg}</div>
}
