/** @type {import('next').NextConfig} */
const withPWA = require('next-pwa')({
  dest: 'public',
  disable: process.env.NODE_ENV === 'development',
  register: true,
  skipWaiting: true,
  fallbacks: { document: '/offline' },
  runtimeCaching: [
    {
      urlPattern: /^https:\/\/{0,1}.*\.(?:png|jpg|jpeg|svg|gif|webp)$/,
      handler: 'CacheFirst',
      options: { cacheName: 'images', expiration: { maxEntries: 100, maxAgeSeconds: 60 * 60 * 24 * 30 } }
    },
    {
      urlPattern: /^https:\/\/{0,1}.*\/api\/salons.*$/,
      handler: 'NetworkFirst',
      options: { cacheName: 'api-salons', networkTimeoutSeconds: 3 }
    },
    {
      urlPattern: /^https:\/\/{0,1}.*\/salon\/.*$/,
      handler: 'NetworkFirst',
      options: { cacheName: 'pages-salon', networkTimeoutSeconds: 3 }
    }
  ]
})

module.exports = withPWA({
  reactStrictMode: true,
  experimental: { typedRoutes: true },
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "utfs.io" },
      { protocol: "https", hostname: "uploadthing.com" },
      { protocol: "https", hostname: "images.unsplash.com" }
    ]
  },
  async headers() {
    const csp = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.vercel.app",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https://utfs.io https://uploadthing.com https://images.unsplash.com",
      "connect-src 'self' https://nominatim.openstreetmap.org https://*.uploadthing.com",
      "frame-ancestors 'self'",
      "base-uri 'self'",
      "form-action 'self'"
    ].join("; ")
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "Content-Security-Policy", value: csp },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Permissions-Policy", value: "geolocation=(), microphone=(), camera=()" }
        ]
      }
    ]
  }
})
