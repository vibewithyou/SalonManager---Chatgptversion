# SalonManager (Next.js 14, TS, App Router)

PWA-Webapp für Salons: Suche, Buchung, Owner/Staff-Backoffice. Dieses Repo enthält Setup, Auth, RBAC, Seed und Basis-Seiten.  
**Stack:** Next.js 14 • Tailwind • Prisma/Postgres • NextAuth (Credentials) • Leaflet • UploadThing • Resend • Zod • Vitest • Playwright • next-pwa

## Schnellstart

1. `cp .env.example .env` und Variablen setzen
2. `pnpm i` (oder `npm i`/`yarn`)
3. `pnpm prisma:generate && pnpm prisma:migrate`
4. `pnpm db:seed`
5. `pnpm dev` → http://localhost:3000

**Demo-Logins:**  
- admin@demo.tld / Admin123!  
- owner@demo.tld / Owner123!  
- staff1@demo.tld / Staff123!  
- customer@demo.tld / Customer123!

## Nächste Schritte (in folgenden Teilen)
- REST-APIs (Suche, Verfügbarkeit, Buchung, CRUD)
- Owner/Staff/Me-Screens
- Uploads (UploadThing) & Medien
- Leaflet-Karte
- PWA-Offline-Shell
- Tests (Vitest/Playwright)
- CI/CD (GitHub Actions)

## Uploads
- UploadThing ist integriert. Setze `UPLOADTHING_APP_ID` und `UPLOADTHING_SECRET`.
- Medien werden automatisch im `onUploadComplete` in Prisma gespeichert.

## PWA
- `next-pwa` aktiviert, Offline-Fallback `/offline`.
- Statisches Caching für Bilder; NetworkFirst für Salon-API und -Seiten.

## Tests
- `pnpm test` (Vitest Unit)
- `pnpm e2e` (Playwright Smokes) – benötigt laufenden Server (`pnpm build && pnpm start`).

## CI
- GitHub Actions führen Lint, Unit-Tests und Build aus. E2E kannst du in separatem Job mit Postgres-Service ergänzen.

## Rollen & Rechte
- **ADMIN**: alles
- **OWNER**: nur eigene Salons (CRUD, Öffnungszeiten, Medien, Buchungen inkl. Zuweisung)
- **STAFF**: eigene Agenda, Schedule-CRUD; darf Buchungen im eigenen Salon bestätigen/ablehnen, wenn (zugewiesen oder unzugewiesen)
- **CUSTOMER**: eigene Buchungen (lesen/stornieren)

## Owner-Tools
- `/owner/salons/[id]/hours` – Wochenraster für Öffnungszeiten
- `/owner/salons/[id]/bookings` – Statuswechsel & Staff-Zuweisung


## Sicherheit
- **Passwort-Policy:** min 8, Groß/Klein/Ziffer/Sonderzeichen.
- **E-Mail-Verifikation:** Registrierung sendet Bestätigungslink (24h gültig).
- **2FA (TOTP):** Setup unter Profil; Login verlangt Code, wenn aktiviert.
- **Audit-Logs:** kritische Aktionen werden protokolliert.
- **Rate-Limits:** leichtgewichtig per IP/Route; für Prod Redis/KV empfohlen.
- **CSP & Header:** restriktive Defaults; Domains bei Bedarf erweitern.
- **DSGVO:** `/api/me/export` (Datenauszug), `/api/me/delete` (Soft-Delete).


## Sicherheit
- **Passwort-Policy:** min 8, Groß/Klein/Ziffer/Sonderzeichen.
- **E-Mail-Verifikation:** Registrierung sendet Bestätigungslink (24h gültig).
- **2FA (TOTP):** Setup unter Profil; Login verlangt Code, wenn aktiviert.
- **Audit-Logs:** kritische Aktionen werden protokolliert.
- **Rate-Limits:** leichtgewichtig per IP/Route; für Prod Redis/KV empfohlen.
- **CSP & Header:** restriktive Defaults; Domains bei Bedarf erweitern.
- **DSGVO:** `/api/me/export` (Datenauszug), `/api/me/delete` (Soft-Delete).
