import { NextResponse } from "next/server"
import { retentionSweep } from "@/lib/retention"

export async function POST(req: Request) {
  const auth = req.headers.get("authorization") || ""
  if (auth !== `Bearer ${process.env.JOBS_SECRET}`) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const res = await retentionSweep()
  return NextResponse.json(res)
}
