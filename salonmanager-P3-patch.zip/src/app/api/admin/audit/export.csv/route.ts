import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"

export async function GET(req: Request) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const url = new URL(req.url)
  const from = url.searchParams.get("from")
  const to = url.searchParams.get("to")
  const userId = url.searchParams.get("userId") || undefined
  const action = url.searchParams.get("action") || undefined

  const where: any = {}
  if (from || to) where.createdAt = { gte: from ? new Date(from) : undefined, lte: to ? new Date(to) : undefined }
  if (userId) where.userId = userId
  if (action) where.action = action

  const items = await prisma.auditLog.findMany({ where, orderBy: { createdAt: "desc" }, take: 5000 })
  const header = ["createdAt","userId","action","entity","meta","prevHash","hash"]
  const lines = [header.join(",")].concat(items.map(i => [
    i.createdAt.toISOString(),
    i.userId ?? "",
    i.action,
    i.entity ?? "",
    JSON.stringify(i.meta ?? {}).replace(/"/g,'""'),
    i.prevHash ?? "",
    i.hash
  ].map(v => `"${String(v)}"`).join(",")))
  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="audit.csv"`
    }
  })
}
