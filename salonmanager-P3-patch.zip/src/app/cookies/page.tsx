export const metadata = { title: "Cookies" }

export default function Cookies() {
  return (
    <div className="prose prose-invert max-w-3xl">
      <h1 className="text-gold">Cookies</h1>
      <p>Wir setzen ausschließlich technisch notwendige Cookies ein:</p>
      <table>
        <thead><tr><th>Name</th><th>Zweck</th><th>Speicherdauer</th></tr></thead>
        <tbody>
          <tr><td>next-auth.session-token / __Secure-next-auth.session-token</td><td>Sitzung/Anmeldung</td><td>Sitzungsdauer / max. 30 Tage</td></tr>
          <tr><td>locale</td><td>Sprachauswahl</td><td>1 Jahr</td></tr>
          <tr><td>rw</td><td>Read-after-Write-Konsistenzhinweis</td><td>5 Sekunden</td></tr>
          <tr><td>consent</td><td>Ihre Cookie-Auswahl (nur notwendig)</td><td>1 Jahr</td></tr>
          <tr><td>impersonate</td><td>Admin-Impersonation (nur Admin)</td><td>Sitzung</td></tr>
        </tbody>
      </table>
      <p>Keine Analytics-/Tracking-Cookies aktiv.</p>
    </div>
  )
}
