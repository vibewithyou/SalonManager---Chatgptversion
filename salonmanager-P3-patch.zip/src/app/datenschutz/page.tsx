import Link from "next/link"
import { env } from "@/lib/env"

export const metadata = { title: "Datenschutzerklärung" }

export default function Datenschutz() {
  return (
    <div className="prose prose-invert max-w-3xl">
      <h1 className="text-gold">Datenschutzerklärung</h1>
      <p>Verantwortlicher: {env.LEGAL_COMPANY_NAME ?? "Betreiber"} ({env.LEGAL_EMAIL}).</p>
      <h2>Verarbeitete Daten</h2>
      <ul>
        <li>Account-Daten (E-Mail, Passwort-Hash, Rolle)</li>
        <li>Salon-Daten (Stammdaten, Medien, Öffnungszeiten)</li>
        <li>Buchungen (Zeiten, Status, Notizen/Uploads)</li>
        <li>Protokolle (Audit-Log, E-Mail-Ereignisse)</li>
      </ul>
      <h2>Zwecke & Rechtsgrundlagen</h2>
      <ul>
        <li>Vertragserfüllung (Art. 6 Abs. 1 lit. b DSGVO): Kontoführung, Buchungen</li>
        <li>Berechtigtes Interesse (Art. 6 Abs. 1 lit. f DSGVO): Sicherheit, Betrugsprävention, Logging</li>
        <li>Einwilligung (Art. 6 Abs. 1 lit. a DSGVO): (nur für optionale Dienste – aktuell keine)</li>
      </ul>
      <h2>Empfänger / Drittanbieter</h2>
      <ul>
        <li>E-Mail: Resend/SMTP</li>
        <li>Datei-Upload/CDN: UploadThing</li>
        <li>Karten/Geodaten: OpenStreetMap (Tiles, Nominatim) – siehe <Link href="/legal/third-parties">Drittdienste</Link></li>
        <li>(optional) Google Calendar Sync, Stripe Billing</li>
      </ul>
      <h2>Speicherdauer</h2>
      <p>Audit-Logs: standardmäßig {String(process.env.RETENTION_AUDIT_DAYS ?? 365)} Tage. Gelöschte Konten werden nach {String(process.env.RETENTION_SOFT_DELETE_DAYS ?? 30)} Tagen endgültig entfernt (sofern keine gesetzlichen Aufbewahrungspflichten entgegenstehen).</p>
      <h2>Betroffenenrechte</h2>
      <p>Auskunft/Export: <code>/api/me/export</code>; Löschanfrage: <code>/api/me/delete</code>. Weitere Rechte: Berichtigung, Einschränkung, Widerspruch, Beschwerde bei der Aufsichtsbehörde.</p>
      <h2>Cookies</h2>
      <p>Wir verwenden nur technisch notwendige Cookies (Session, Sprache, Konsistenzhinweis). Details unter <Link href="/cookies">Cookies</Link>. Kein Tracking.</p>
    </div>
  )
}
