export const metadata = { title: "Drittdienste & Lizenzen" }

export default function ThirdParties() {
  return (
    <div className="prose prose-invert max-w-3xl">
      <h1 className="text-gold">Drittdienste & Lizenzen</h1>
      <h2>OpenStreetMap</h2>
      <p>Kartendaten © OpenStreetMap-Mitwirkende (<a href="https://www.openstreetmap.org/copyright">Lizenz & Urheberrechte</a>). Nominatim gemäß Nutzungsbedingungen (<a href="https://operations.osmfoundation.org/policies/nominatim/">Policy</a>).</p>
      <h2>Datei-Uploads</h2>
      <p>UploadThing (CDN/Storage) – siehe Anbieter-AGB/Datenschutz.</p>
      <h2>E-Mail-Versand</h2>
      <p>Resend/SMTP – siehe Anbieter-AGB/Datenschutz.</p>
      <h2>Optionale Integrationen</h2>
      <p>Google Calendar, Stripe – nur wenn aktiviert.</p>
    </div>
  )
}
