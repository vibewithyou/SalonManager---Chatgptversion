import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"
import Link from "next/link"

export default async function AuditPage({ searchParams }: { searchParams: { userId?: string; action?: string } }) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return <div className="card">Forbidden</div>
  const where: any = {}
  if (searchParams.userId) where.userId = searchParams.userId
  if (searchParams.action) where.action = searchParams.action
  const items = await prisma.auditLog.findMany({ where, orderBy: { createdAt: "desc" }, take: 200 })

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Audit Log</h1>
      <div className="flex items-center gap-2">
        <form className="flex gap-2" method="get">
          <input className="input" name="userId" placeholder="User ID" defaultValue={searchParams.userId ?? ""} />
          <input className="input" name="action" placeholder="Action" defaultValue={searchParams.action ?? ""} />
          <button className="btn" type="submit">Filtern</button>
        </form>
        <Link className="underline hover:text-gold" href="/api/admin/audit/export.csv">CSV Export</Link>
      </div>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-muted"><tr><th>Zeit</th><th>User</th><th>Action</th><th>Entity</th><th>Hash</th></tr></thead>
          <tbody>
            {items.map(i=>(
              <tr key={i.id} className="border-t border-border">
                <td>{i.createdAt.toISOString()}</td>
                <td>{i.userId ?? "—"}</td>
                <td>{i.action}</td>
                <td>{i.entity ?? "—"}</td>
                <td className="text-[10px]">{i.hash.slice(0,12)}…</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
