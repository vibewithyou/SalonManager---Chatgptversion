import { env } from "@/lib/env"

export const metadata = { title: "Impressum" }

export default function Impressum() {
  const c = env
  return (
    <div className="prose prose-invert max-w-3xl">
      <h1 className="text-gold">Impressum</h1>
      <p><strong>{c.LEGAL_COMPANY_NAME ?? "Unternehmen"}</strong><br/>
        {c.LEGAL_STREET}<br/>{c.LEGAL_ZIP} {c.LEGAL_CITY}<br/>{c.LEGAL_COUNTRY}</p>
      <p>E-Mail: {c.LEGAL_EMAIL} • Tel: {c.LEGAL_PHONE}</p>
      {c.LEGAL_VAT_ID && <p>USt-IdNr.: {c.LEGAL_VAT_ID}</p>}
      {c.LEGAL_TRADE_REGISTER && <p>Handelsregister: {c.LEGAL_TRADE_REGISTER}</p>}
      <h2>Haftung für Inhalte</h2>
      <p>Die Inhalte dieser Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte übernehmen wir keine Gewähr.</p>
      <h2>Urheberrecht</h2>
      <p>Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht.</p>
    </div>
  )
}
