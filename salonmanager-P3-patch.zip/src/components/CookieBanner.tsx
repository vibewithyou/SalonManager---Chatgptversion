"use client"
import { useEffect, useState } from "react"

export default function CookieBanner() {
  const [show, setShow] = useState(false)
  useEffect(() => {
    const c = document.cookie.split("; ").find(x => x.startsWith("consent="))
    if (!c) setShow(true)
  }, [])
  if (!show) return null
  return (
    <div className="fixed bottom-4 inset-x-4 z-50 bg-[#181818] border border-border rounded p-4 shadow-lg">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <p className="text-sm text-muted">Wir verwenden ausschließlich technisch notwendige Cookies (z. B. für Login & Sprache). Keine Analytics/Tracking. </p>
        <div className="flex gap-2">
          <a className="underline hover:text-gold text-sm" href="/cookies">Mehr erfahren</a>
          <button className="btn" onClick={() => {
            document.cookie = `consent=${encodeURIComponent(JSON.stringify({ necessary: true }))}; Max-Age=${365*24*60*60}; Path=/; SameSite=Lax`
            setShow(false)
          }}>OK</button>
        </div>
      </div>
    </div>
  )
}
