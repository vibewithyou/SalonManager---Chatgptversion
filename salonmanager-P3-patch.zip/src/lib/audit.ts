import crypto from "crypto"
import { prisma } from "@/lib/prisma"

export async function audit(entry: {
  userId?: string
  action: string
  entity?: string
  meta?: Record<string, any>
}) {
  const last = await prisma.auditLog.findFirst({ orderBy: { createdAt: "desc" }, select: { hash: true } })
  const prev = last?.hash ?? ""
  const payload = JSON.stringify({ ...entry, prev })
  const hash = crypto.createHash("sha256").update(payload).digest("hex")
  return prisma.auditLog.create({
    data: { ...entry, prevHash: prev || null, hash }
  })
}
