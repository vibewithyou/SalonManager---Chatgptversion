import { prisma } from "@/lib/prisma"
import { env } from "@/lib/env"

const DAYS = (n: number) => n * 24 * 60 * 60 * 1000

export async function retentionSweep() {
  const now = Date.now()
  const auditDays = env.RETENTION_AUDIT_DAYS ?? 365
  const softDeleteDays = env.RETENTION_SOFT_DELETE_DAYS ?? 30

  // 1) Alte Audit-Logs löschen
  const auditBefore = new Date(now - DAYS(auditDays))
  const r1 = await prisma.auditLog.deleteMany({ where: { createdAt: { lt: auditBefore } } })

  // 2) Hard-Delete von Nutzern, die soft-deleted sind & keine kritischen Referenzen haben
  const users = await prisma.user.findMany({
    where: { deletedAt: { not: null }, updatedAt: { lt: new Date(now - DAYS(softDeleteDays)) } },
    select: { id: true }
  })
  let deletedUsers = 0
  for (const u of users) {
    const [bookAsCust, staffCount, salonCount] = await Promise.all([
      prisma.booking.count({ where: { customerId: u.id } }),
      prisma.staffProfile.count({ where: { userId: u.id } }),
      prisma.salon.count({ where: { ownerId: u.id } })
    ])
    if (bookAsCust === 0 && staffCount === 0 && salonCount === 0) {
      await prisma.user.delete({ where: { id: u.id } })
      deletedUsers++
    }
  }
  return { auditDeleted: r1.count, usersDeleted: deletedUsers }
}
