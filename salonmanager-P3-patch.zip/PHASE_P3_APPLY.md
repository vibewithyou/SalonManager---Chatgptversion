# Phase P3 — Daten & Recht (Apply Guide)

Diese Patch-ZIP enthält **neue Dateien** und eine Anleitung, wie du bestehende Dateien erweiterst.
Danach bitte einmal: `pnpm prisma:generate && pnpm prisma:migrate` und ggf. Deploy.

## 1) ENV ergänzen
In `.env.example` (und produktiven Secrets) diese Variablen hinzufügen:

```bash
# Legal imprint
LEGAL_COMPANY_NAME="SalonManager GmbH"
LEGAL_STREET="Musterstraße 1"
LEGAL_ZIP="12345"
LEGAL_CITY="Berlin"
LEGAL_COUNTRY="Deutschland"
LEGAL_EMAIL="hello@example.com"
LEGAL_PHONE="+49 30 1234567"
LEGAL_VAT_ID="DE123456789"
LEGAL_TRADE_REGISTER="Amtsgericht Berlin, HRB 123456"

# Data retention
RETENTION_AUDIT_DAYS=365
RETENTION_SOFT_DELETE_DAYS=30
```

## 2) Prisma Schema ergänzen
In `prisma/schema.prisma` **untere Blöcke hinzufügen** (oder entsprechend mergen):

```prisma
model AuditLog {
  id        String   @id @default(cuid())
  userId    String?
  action    String
  entity    String?
  meta      Json?
  prevHash  String?
  hash      String
  createdAt DateTime  @default(now())

  @@index([userId, createdAt])
  @@index([action, createdAt])
}

model User {
  // ...
  deletedAt DateTime?
}
```

> Danach: `pnpm prisma:generate && pnpm prisma:migrate`

## 3) `src/lib/env.ts` erweitern
**Eingangs-Schema** um die Keys ergänzen **(sowohl Schema als auch parse-Aufruf)**:

```ts
  LEGAL_COMPANY_NAME: z.string().optional(),
  LEGAL_STREET: z.string().optional(),
  LEGAL_ZIP: z.string().optional(),
  LEGAL_CITY: z.string().optional(),
  LEGAL_COUNTRY: z.string().optional(),
  LEGAL_EMAIL: z.string().optional(),
  LEGAL_PHONE: z.string().optional(),
  LEGAL_VAT_ID: z.string().optional(),
  LEGAL_TRADE_REGISTER: z.string().optional(),
  RETENTION_AUDIT_DAYS: z.coerce.number().optional(),
  RETENTION_SOFT_DELETE_DAYS: z.coerce.number().optional()
```

und unten in `envSchema.parse({...})`:

```ts
  LEGAL_COMPANY_NAME: process.env.LEGAL_COMPANY_NAME,
  LEGAL_STREET: process.env.LEGAL_STREET,
  LEGAL_ZIP: process.env.LEGAL_ZIP,
  LEGAL_CITY: process.env.LEGAL_CITY,
  LEGAL_COUNTRY: process.env.LEGAL_COUNTRY,
  LEGAL_EMAIL: process.env.LEGAL_EMAIL,
  LEGAL_PHONE: process.env.LEGAL_PHONE,
  LEGAL_VAT_ID: process.env.LEGAL_VAT_ID,
  LEGAL_TRADE_REGISTER: process.env.LEGAL_TRADE_REGISTER,
  RETENTION_AUDIT_DAYS: process.env.RETENTION_AUDIT_DAYS,
  RETENTION_SOFT_DELETE_DAYS: process.env.RETENTION_SOFT_DELETE_DAYS
```

## 4) Neue Dateien kopieren
Alle Dateien in dieser ZIP unter `src/` sind **neu** und können 1:1 in dein Repo gelegt werden:

- `src/lib/audit.ts`
- `src/lib/retention.ts`
- `src/app/api/admin/audit/export.csv/route.ts`
- `src/app/admin/audit/page.tsx`
- `src/app/api/jobs/retention/route.ts`
- Recht-Seiten:
  - `src/app/impressum/page.tsx`
  - `src/app/datenschutz/page.tsx`
  - `src/app/cookies/page.tsx`
  - `src/app/legal/third-parties/page.tsx`
- `src/components/CookieBanner.tsx`

## 5) Cookie-Banner & Footer verlinken
In `src/app/layout.tsx` **importieren und rendern**:

```tsx
import CookieBanner from "@/components/CookieBanner"

// ... im Body/Provider-Bereich:
<CookieBanner />
```

Und im Footer (oder Navigation) Links ergänzen:

```tsx
<footer className="container py-8 text-sm text-muted flex flex-wrap gap-4">
  <a className="underline hover:text-gold" href="/impressum">Impressum</a>
  <a className="underline hover:text-gold" href="/datenschutz">Datenschutz</a>
  <a className="underline hover:text-gold" href="/cookies">Cookies</a>
  <a className="underline hover:text-gold" href="/legal/third-parties">Drittdienste</a>
</footer>
```

## 6) DSAR-Export erweitern
In `src/app/api/me/export/route.ts` **vor dem `return`** diese Felder zusätzlich laden und im JSON zurückgeben:

```ts
  const [icsTokens, googleAccount, emailEvents] = await Promise.all([
    prisma.icsToken.findMany({ where: { OR: [{ createdBy: userId }, { staff: { userId } }] } }),
    prisma.googleAccount.findUnique({ where: { userId } }),
    prisma.emailEvent.findMany({ where: { to: { contains: user?.email ?? "" } }, take: 500 })
  ])

// ... im Response-Objekt hinzufügen:
  icsTokens, googleAccount, emailEvents
```

## 7) Retention Cron
Cron-Job-Endpoint ist in dieser ZIP (`/api/jobs/retention`). In deiner Worker-/Cron-Pipeline regelmäßig aufrufen:

```bash
curl -X POST -H "Authorization: Bearer $JOBS_SECRET" https://<deine-app>/api/jobs/retention
```

## 8) Admin-Menü: Audit
Einen Link nach `/admin/audit` aufnehmen, optional auch einen Link auf den CSV-Export `/api/admin/audit/export.csv`.

---

### Abschluss
- ENV setzen, Schema migrieren, Dateien kopieren
- App neu starten/deployen
- Optional: Rechts-Texte an eure tatsächlichen Angaben anpassen

