# Phase P8 — Patch Notes

This bundle contains **new/replace** files. Apply snippets below for inline edits.

## Added files
- `src/app/not-found.tsx` — global 404 page
- `src/app/error.tsx` — global error boundary (App Router)
- `src/app/admin/users/page.tsx` — Admin user list with impersonation button
- `src/lib/image.ts` — shimmer-based `blurDataURL` helpers
- `src/app/owner/error.tsx` — optional Owner-segment error page

## Inline edits you should apply in your repo

### 1) Salon detail guard
In `src/app/salon/[slug]/page.tsx` ensure missing or unpublished salons trigger 404:

```tsx
import { notFound } from "next/navigation"
// ...
if (!salon || !salon.isPublished) return notFound()
```

### 2) Progressive images (examples)
Use `shimmerDataURL` as placeholder with `next/image`:

```tsx
import { shimmerDataURL } from "@/lib/image"
// ...
<Image
  src={salon.media.find(m=>m.type==="LOGO")?.url ?? "/icon-192.png"}
  alt={salon.name}
  width={64} height={64}
  placeholder="blur" blurDataURL={shimmerDataURL(64,64)}
/>
```

### 3) Sentry sourcemaps in Next config
Enable prod source maps (keeps your existing config wrap):

```js
// next.config.js
module.exports = withBundleAnalyzer(withPWA({
  // ...existing...
  productionBrowserSourceMaps: true,
}))
```

### 4) CI: Sentry release upload step
Append this step after build in `.github/workflows/ci.yml`:

```yml
- name: Sentry Release (upload sourcemaps)
  if: env.SENTRY_AUTH_TOKEN != ''
  uses: getsentry/action-release@v1
  env:
    SENTRY_AUTH_TOKEN: ${{ secrets.SENTRY_AUTH_TOKEN }}
    SENTRY_ORG: ${{ secrets.SENTRY_ORG }}
    SENTRY_PROJECT: ${{ secrets.SENTRY_PROJECT }}
  with:
    environment: production
    sourcemaps: "./.next/static/chunks"
    version: ${{ github.sha }}
```

### 5) .env.example
Add Sentry release envs:

```
SENTRY_AUTH_TOKEN="..."
SENTRY_ORG="your-org"
SENTRY_PROJECT="salonmanager"
SENTRY_ENV="production"
```

### 6) Admin menu
Add a link to `/admin/users` in your Admin navigation.
