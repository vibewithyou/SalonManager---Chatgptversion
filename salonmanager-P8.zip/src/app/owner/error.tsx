"use client"
export default function OwnerError({ reset }: { reset: () => void }) {
  return (
    <div className="card">
      <h2 className="text-gold font-semibold">Fehler im Owner-Bereich</h2>
      <p className="text-sm text-muted mt-1">Bitte versuche es erneut oder lade die Seite neu.</p>
      <div className="mt-3 flex gap-2">
        <button className="btn" onClick={() => reset()}>Erneut versuchen</button>
        <a className="underline hover:text-gold" href="/owner/salons">Zur Übersicht</a>
      </div>
    </div>
  )
}
