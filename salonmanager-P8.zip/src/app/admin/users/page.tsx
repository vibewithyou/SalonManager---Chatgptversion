import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"

export const dynamic = "force-dynamic"

async function listUsers(search?: string, page = 1, pageSize = 20) {
  const where = search
    ? { OR: [{ email: { contains: search, mode: "insensitive" } }, { name: { contains: search, mode: "insensitive" } }] }
    : {}
  const [total, items] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: pageSize,
      skip: (page - 1) * pageSize,
      select: { id: true, email: true, name: true, role: true, createdAt: true, noShowCount: true }
    })
  ])
  return { total, items, page, pageSize }
}

export default async function AdminUsers({ searchParams }: { searchParams: { q?: string; page?: string } }) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return <div className="card">Forbidden</div>

  const q = searchParams.q ?? ""
  const page = Number(searchParams.page ?? "1") || 1
  const data = await listUsers(q, page)

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-gold">Users</h1>
      <form className="flex gap-2 items-end" method="get">
        <div className="grid gap-1">
          <label className="text-sm">Suche</label>
          <input className="input" name="q" defaultValue={q} placeholder="E-Mail oder Name" />
        </div>
        <button className="btn" type="submit">Suchen</button>
      </form>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-muted">
            <tr>
              <th className="text-left">E-Mail</th>
              <th className="text-left">Name</th>
              <th>Rolle</th>
              <th>No-Shows</th>
              <th>Erstellt</th>
              <th>Aktionen</th>
            </tr>
          </thead>
          <tbody>
            {data.items.map(u => (
              <tr key={u.id} className="border-t border-border">
                <td>{u.email}</td>
                <td>{u.name ?? "—"}</td>
                <td className="text-center">{u.role}</td>
                <td className="text-center">{u.noShowCount}</td>
                <td>{u.createdAt.toLocaleString()}</td>
                <td className="text-center">
                  <form action="/api/admin/impersonate/start" method="post"
                        onSubmit={e => {
                          e.preventDefault()
                          fetch("/api/admin/impersonate/start", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ userId: u.id })
                          }).then(() => location.href = "/")
                        }}>
                    <button className="underline hover:text-gold" type="submit">Impersonieren</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex items-center justify-between mt-3">
          <a className={`btn ${page<=1?"pointer-events-none opacity-50":""}`} href={`?q=${encodeURIComponent(q)}&page=${page-1}`}>Zurück</a>
          <span className="text-sm text-muted">Seite {page} – {data.total} Nutzer</span>
          <a className={`btn ${page*data.pageSize>=data.total?"pointer-events-none opacity-50":""}`} href={`?q=${encodeURIComponent(q)}&page=${page+1}`}>Weiter</a>
        </div>
      </div>
    </div>
  )
}
