"use client"

import { useEffect } from "react"

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Optional: an Sentry melden (runtime; bei Sentry-Init wird global abgefangen)
    // console.error(error)
  }, [error])

  return (
    <html>
      <body>
        <div className="container mx-auto p-6">
          <div className="card max-w-xl mx-auto text-center">
            <h1 className="text-3xl font-semibold text-gold">Unerwarteter Fehler</h1>
            <p className="text-muted mt-2">Etwas ist schief gelaufen. Bitte versuche es erneut.</p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <button className="btn" onClick={() => reset()}>Nochmals versuchen</button>
              <a className="underline hover:text-gold" href="/">Startseite</a>
            </div>
            {error?.digest && <p className="text-xs text-muted mt-3">Fehler-ID: {error.digest}</p>}
          </div>
        </div>
      </body>
    </html>
  )
}
