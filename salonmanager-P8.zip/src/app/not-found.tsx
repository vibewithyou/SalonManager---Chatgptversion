export default function NotFound() {
  return (
    <div className="container mx-auto p-6">
      <div className="card max-w-xl mx-auto text-center">
        <h1 className="text-3xl font-semibold text-gold">Seite nicht gefunden</h1>
        <p className="text-muted mt-2">Die angeforderte Seite existiert nicht oder wurde verschoben.</p>
        <a className="btn mt-4" href="/">Zur Startseite</a>
      </div>
    </div>
  )
}
