"use client"

import { UploadButton } from "@uploadthing/react"
import type { OurFileRouter } from "@/app/api/uploadthing/core"
import imageCompression from "browser-image-compression"
import { useState } from "react"

export function MediaUploader({ salonId }: { salonId: string }) {
  const [busy, setBusy] = useState(false)

  return (
    <div className="card">
      <h3 className="mb-2 font-medium">Bilder hochladen</h3>
      <UploadButton<OurFileRouter>
        endpoint="imageUploader"
        input={{ salonId }}
        appearance={{ button: "btn", allowedContent: "text-sm text-muted mt-2" }}
        content={{ button({ isUploading }) { return isUploading ? "Lädt…" : "Dateien wählen" } }}
        onBeforeUploadBegin={async (files) => {
          setBusy(true)
          const out: File[] = []
          for (const f of files) {
            try {
              const compressed = await imageCompression(f, { maxSizeMB: 1, maxWidthOrHeight: 1280, useWebWorker: true, initialQuality: 0.8 })
              out.push(new File([compressed], f.name, { type: compressed.type }))
            } catch { out.push(f) }
          }
          setBusy(false)
          return out
        }}
        onClientUploadComplete={() => window.location.reload()}
      />
      {busy && <p className="text-xs text-muted mt-2">Komprimiere…</p>}
      <p className="text-xs text-muted mt-2">JPG/PNG bis 10 MB. Bilder werden vor dem Upload leicht komprimiert.</p>
    </div>
  )
}
