"use client"

import dynamic from "next/dynamic"
import { useEffect, useMemo, useState } from "react"
import L from "leaflet"

const MapContainer = dynamic(() => import("react-leaflet").then(m => m.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import("react-leaflet").then(m => m.TileLayer), { ssr: false })
const Marker = dynamic(() => import("react-leaflet").then(m => m.Marker), { ssr: false })
const Popup = dynamic(() => import("react-leaflet").then(m => m.Popup), { ssr: false })
const MarkerClusterGroup = dynamic(() => import("react-leaflet-cluster").then(m => m.default), { ssr: false })

const goldIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  shadowSize: [41, 41],
  className: "leaflet-gold"
})

export function SalonsMap({ salons, cluster = false }: {
  salons: { name: string; slug: string; latitude: number; longitude: number }[]
  cluster?: boolean
}) {
  const [center, setCenter] = useState<[number, number]>([51.0, 10.0])
  useEffect(() => { if (salons.length) setCenter([salons[0].latitude, salons[0].longitude]) }, [salons])

  const markers = useMemo(() => salons.filter(s => Number.isFinite(s.latitude) && Number.isFinite(s.longitude)), [salons])

  return (
    <div className="h-[420px] w-full rounded border border-border overflow-hidden">
      <MapContainer center={center} zoom={12} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; <a href="https://openstreetmap.org">OSM</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {cluster ? (
          <MarkerClusterGroup chunkedLoading>
            {markers.map((s) => (
              <Marker key={s.slug} position={[s.latitude, s.longitude]} icon={goldIcon}>
                <Popup><a className="text-gold underline" href={`/salon/${s.slug}`}>{s.name}</a></Popup>
              </Marker>
            ))}
          </MarkerClusterGroup>
        ) : (
          markers.map((s) => (
            <Marker key={s.slug} position={[s.latitude, s.longitude]} icon={goldIcon}>
              <Popup><a className="text-gold underline" href={`/salon/${s.slug}`}>{s.name}</a></Popup>
            </Marker>
          ))
        )}
      </MapContainer>
    </div>
  )
}
