import { prisma } from "@/lib/prisma"
import { MediaUploader } from "@/components/MediaUploader"
import Image from "next/image"

async function getSalon(id: string) {
  return prisma.salon.findUnique({ where: { id }, include: { media: true } })
}

export default async function MediaPage({ params }: { params: { id: string } }) {
  const salon = await getSalon(params.id)
  if (!salon) return <div className="card">Nicht gefunden</div>
  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-gold">Medien – {salon.name}</h1>
      <MediaUploader salonId={salon.id} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {salon.media.map(m => (
          <figure key={m.id} className="relative overflow-hidden rounded border border-border">
            <Image src={m.url} alt={m.alt ?? ""} width={600} height={400} className="object-cover w-full h-40" />
            <figcaption className="absolute inset-x-0 bottom-0 bg-black/50 p-2 text-xs flex items-center justify-between">
              <span>{m.type === "LOGO" ? "LOGO" : "Bild"}</span>
              <span className="flex gap-2">
                {m.type !== "LOGO" && (
                  <form action={`/api/media/${m.id}`} method="post" onSubmit={e=>{e.preventDefault(); fetch(e.currentTarget.action,{method:"PATCH",headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'LOGO'})}).then(()=>location.reload())}}>
                    <button className="underline hover:text-gold" type="submit">Als Logo</button>
                  </form>
                )}
                <form action={`/api/media/${m.id}`} method="post" onSubmit={e=>{e.preventDefault(); if(confirm("Bild löschen?")) fetch(e.currentTarget.action,{method:"DELETE"}).then(()=>location.reload())}}>
                  <button className="underline hover:text-gold" type="submit">Löschen</button>
                </form>
              </span>
            </figcaption>
          </figure>
        ))}
      </div>
    </div>
  )
}
