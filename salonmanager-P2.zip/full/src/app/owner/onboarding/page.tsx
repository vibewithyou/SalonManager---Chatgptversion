"use client"

import { useState } from "react"
import { MapPicker } from "@/components/MapPicker"
import { useToast } from "@/components/ToastProvider"

type ServiceInput = { name: string; durationMin: number; priceEuro: number }

export default function Onboarding() {
  const [step, setStep] = useState(1)
  const [salonId, setSalonId] = useState<string | null>(null)
  const [data, setData] = useState<any>({
    name: "", slug: "", address: "", city: "", postalCode: "", country: "DE",
    latitude: 51, longitude: 10, description: ""
  })
  const [services, setServices] = useState<ServiceInput[]>([])
  const [hours, setHours] = useState(Array.from({length:7}, (_,i)=>({ weekday: i, openTime: "09:00", closeTime: "18:00", isClosed: i>=6 })))
  const notify = useToast()

  function set<K extends string>(k: K, v: any) { setData((d:any)=>({ ...d, [k]: v })) }

  async function createSalon() {
    const res = await fetch("/api/salons", { method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify(data) })
    if (!res.ok) { notify({ type:"error", message:"Salon konnte nicht erstellt werden" }); return }
    const j = await res.json()
    setSalonId(j.id); setStep(2)
  }

  async function saveServices() {
    if (!salonId) return
    for (const s of services) {
      await fetch(`/api/salons/${salonId}/services`, {
        method: "POST", headers: { "Content-Type":"application/json" },
        body: JSON.stringify({ salonId, name: s.name, durationMin: s.durationMin, priceCents: Math.round(s.priceEuro*100) })
      })
    }
    setStep(4)
  }

  async function saveHours() {
    if (!salonId) return
    for (const h of hours) {
      await fetch(`/api/salons/${salonId}/opening-hours`, {
        method: "POST", headers: { "Content-Type":"application/json" },
        body: JSON.stringify({ ...h, salonId })
      })
    }
    setStep(5)
  }

  function addService() {
    setServices(prev => [...prev, { name: "", durationMin: 30, priceEuro: 25 }])
  }

  return (
    <div className="grid gap-6 max-w-3xl">
      <h1 className="text-2xl font-semibold text-gold">Onboarding – neuen Salon anlegen</h1>

      {step === 1 && (
        <div className="card grid gap-3">
          <h2 className="font-medium">1) Stammdaten</h2>
          <input className="input" placeholder="Name" value={data.name} onChange={e=>set("name", e.target.value)} />
          <input className="input" placeholder="Slug (kebab-case)" value={data.slug} onChange={e=>set("slug", e.target.value)} />
          <input className="input" placeholder="Adresse" value={data.address} onChange={e=>set("address", e.target.value)} />
          <div className="grid grid-cols-3 gap-3">
            <input className="input" placeholder="Stadt" value={data.city} onChange={e=>set("city", e.target.value)} />
            <input className="input" placeholder="PLZ" value={data.postalCode} onChange={e=>set("postalCode", e.target.value)} />
            <input className="input" placeholder="Land" value={data.country} onChange={e=>set("country", e.target.value)} />
          </div>
          <button className="btn w-max" onClick={createSalon}>Weiter</button>
        </div>
      )}

      {step === 2 && salonId && (
        <div className="card grid gap-3">
          <h2 className="font-medium">2) Standort wählen</h2>
          <MapPicker lat={data.latitude} lng={data.longitude} onChange={(la,lo)=>{ set("latitude", la); set("longitude", lo) }} />
          <div className="flex gap-2">
            <button className="btn" onClick={()=>setStep(3)}>Weiter</button>
            <button className="inline-flex items-center rounded px-3 py-1 border border-border hover:text-gold" onClick={()=>setStep(1)}>Zurück</button>
          </div>
        </div>
      )}

      {step === 3 && salonId && (
        <div className="card grid gap-3">
          <h2 className="font-medium">3) Leistungen</h2>
          <div className="grid gap-2">
            {services.map((s, idx)=>(
              <div key={idx} className="grid grid-cols-3 gap-2">
                <input className="input" placeholder="Name" value={s.name} onChange={e=>setServices(v=>v.map((x,i)=>i===idx?{...x,name:e.target.value}:x))} />
                <input className="input" type="number" placeholder="Dauer (Min.)" value={s.durationMin} onChange={e=>setServices(v=>v.map((x,i)=>i===idx?{...x,durationMin:Number(e.target.value)}:x))} />
                <input className="input" type="number" step="0.01" placeholder="Preis (€)" value={s.priceEuro} onChange={e=>setServices(v=>v.map((x,i)=>i===idx?{...x,priceEuro:Number(e.target.value)}:x))} />
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <button className="btn" onClick={addService} type="button">Leistung hinzufügen</button>
            <button className="btn" onClick={saveServices} disabled={services.length===0}>Weiter</button>
          </div>
        </div>
      )}

      {step === 4 && salonId && (
        <div className="card grid gap-3">
          <h2 className="font-medium">4) Öffnungszeiten</h2>
          <div className="grid gap-2">
            {hours.map((h,idx)=>(
              <div key={idx} className="grid grid-cols-5 gap-2 items-center">
                <div className="text-sm">{["Mo","Di","Mi","Do","Fr","Sa","So"][h.weekday]}</div>
                <input className="input" type="time" value={h.openTime} onChange={e=>setHours(v=>v.map((x,i)=>i===idx?{...x,openTime:e.target.value}:x))} />
                <input className="input" type="time" value={h.closeTime} onChange={e=>setHours(v=>v.map((x,i)=>i===idx?{...x,closeTime:e.target.value}:x))} />
                <label className="text-sm flex items-center gap-2">
                  <input type="checkbox" checked={h.isClosed} onChange={e=>setHours(v=>v.map((x,i)=>i===idx?{...x,isClosed:e.target.checked}:x))} />
                  geschlossen
                </label>
                <div />
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <button className="btn" onClick={saveHours}>Weiter</button>
          </div>
        </div>
      )}

      {step === 5 && salonId && (
        <div className="card grid gap-3">
          <h2 className="font-medium">5) Medien & Veröffentlichen</h2>
          <p className="text-sm text-muted">Lade ein Logo & einige Bilder hoch. Danach kannst du deinen Salon veröffentlichen.</p>
          <a className="btn w-max" href={`/owner/salons/${salonId}/media`}>Medien verwalten</a>
          <a className="underline hover:text-gold w-max" href={`/owner/salons/${salonId}`}>Zum Dashboard</a>
        </div>
      )}
    </div>
  )
}
