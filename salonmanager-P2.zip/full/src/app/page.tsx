"use client"

import { useMemo, useState } from "react"
import useSWR from "swr"
import Link from "next/link"
import { SalonsMap } from "@/components/Map"

const fetcher = (url: string) => fetch(url).then(r => r.json())

export default function HomePage() {
  const [page, setPage] = useState(1)
  const [sort, setSort] = useState<"new"|"priceAsc"|"priceDesc">("new")
  const pageSize = 12
  const { data } = useSWR(`/api/salons?page=${page}&pageSize=${pageSize}&sort=${sort}`, fetcher)

  const salons = data?.items ?? []
  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1

  const mapSalons = useMemo(()=>salons.map((s:any)=>({
    name: s.name, slug: s.slug, latitude: s.latitude, longitude: s.longitude
  })), [salons])

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <section className="md:col-span-2 card">
        <h1 className="mb-4 text-2xl font-semibold text-gold">Finde deinen Salon</h1>
        <div className="grid gap-3 md:grid-cols-3">
          <select className="input" value={sort} onChange={e=>setSort(e.target.value as any)}>
            <option value="new">Neueste</option>
            <option value="priceAsc">Preis ↑</option>
            <option value="priceDesc">Preis ↓</option>
          </select>
          <div className="md:col-span-2 text-sm text-muted self-center">Sortierung & Pagination wirken auf Liste & Karte.</div>
        </div>
      </section>

      <aside className="card">
        <h2 className="mb-2 font-medium">Demo</h2>
        <p className="text-sm text-muted mb-3">Seed enthält „BARBERs Freiberg“.</p>
        <Link href="/salon/barbers-freiberg" className="underline hover:text-gold">Zum Salon</Link>
      </aside>

      <section className="md:col-span-3 card">
        {data ? <SalonsMap salons={mapSalons} cluster /> : <div className="h-[420px] grid place-items-center text-muted">Lade Karte…</div>}
      </section>

      <section className="md:col-span-3 card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-medium">Ergebnisse</h2>
          <div className="flex items-center gap-2 text-sm">
            <button className="btn" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Zurück</button>
            <span>Seite {page} / {totalPages}</span>
            <button className="btn" disabled={page>=totalPages} onClick={()=>setPage(p=>p+1)}>Weiter</button>
          </div>
        </div>
        <ul className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
          {salons.map((s: any) => (
            <li key={s.id} className="border border-border rounded p-3 flex items-center justify-between">
              <div>
                <div className="font-medium">{s.name}</div>
                <div className="text-sm text-muted">{s.city} • {s.address}</div>
                {s.services?.[0] && <div className="text-sm text-gold mt-1">ab {(s.services[0].priceCents/100).toFixed(2)} €</div>}
              </div>
              <Link href={`/salon/${s.slug}`} className="btn">Ansehen</Link>
            </li>
          ))}
          {salons.length === 0 && <li className="text-sm text-muted">Keine Ergebnisse</li>}
        </ul>
      </section>
    </div>
  )
}
