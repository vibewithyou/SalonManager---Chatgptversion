import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getSessionOrThrow, isOwnerOfSalon } from "@/lib/user"

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const media = await prisma.media.findUnique({ where: { id: params.id } })
  if (!media) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && !(await isOwnerOfSalon((session.user as any).id, media.salonId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  await prisma.media.delete({ where: { id: params.id } })
  return NextResponse.json({ ok: true })
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getSessionOrThrow()
  const body = await req.json() as { type?: "LOGO"|"IMAGE" }
  const media = await prisma.media.findUnique({ where: { id: params.id } })
  if (!media) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && !(await isOwnerOfSalon((session.user as any).id, media.salonId))) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  if (body.type === "LOGO") {
    await prisma.$transaction([
      prisma.media.updateMany({ where: { salonId: media.salonId, type: "LOGO" }, data: { type: "IMAGE" } }),
      prisma.media.update({ where: { id: params.id }, data: { type: "LOGO" } })
    ])
    return NextResponse.json({ ok: true })
  }
  return NextResponse.json({ ok: false }, { status: 400 })
}
