import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { searchParamsSchema, listParamsSchema } from "@/lib/validators"

export async function GET(req: Request) {
  const url = new URL(req.url)
  const base = searchParamsSchema.parse(Object.fromEntries(url.searchParams.entries()))
  const list = listParamsSchema.parse(Object.fromEntries(url.searchParams.entries()))
  const where: any = { isPublished: true }

  if (base.city) where.city = { contains: base.city, mode: "insensitive" }
  if (base.query) {
    where.OR = [
      { name: { contains: base.query, mode: "insensitive" } },
      { description: { contains: base.query, mode: "insensitive" } }
    ]
  }
  if (base.tags) {
    const tagArr = base.tags.split(",").map(s => s.trim()).filter(Boolean)
    if (tagArr.length) where.tags = { some: { tag: { name: { in: tagArr } } } }
  }

  // Sortierlogik
  let orderBy: any = { createdAt: "desc" }
  if (list.sort === "priceAsc") {
    orderBy = { services: { _min: { priceCents: "asc" } } }
  } else if (list.sort === "priceDesc") {
    orderBy = { services: { _max: { priceCents: "desc" } } }
  }

  const [total, items] = await Promise.all([
    prisma.salon.count({ where }),
    prisma.salon.findMany({
      where,
      take: list.pageSize,
      skip: (list.page - 1) * list.pageSize,
      orderBy,
      select: {
        id: true, name: true, slug: true, city: true, address: true, latitude: true, longitude: true,
        services: { select: { priceCents: true }, orderBy: { priceCents: "asc" }, take: 1 },
        media: { where: { type: "LOGO" }, select: { url: true }, take: 1 }
      }
    })
  ])

  return NextResponse.json({
    total, page: list.page, pageSize: list.pageSize, items
  })
}

export const dynamic = "force-dynamic"
export const revalidate = 0
export const fetchCache = "default-no-store"
