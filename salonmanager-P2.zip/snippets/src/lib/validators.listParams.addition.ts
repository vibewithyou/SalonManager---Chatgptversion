import { z } from "zod"

export const listParamsSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(12),
  sort: z.enum(["new","priceAsc","priceDesc"]).default("new")
})
