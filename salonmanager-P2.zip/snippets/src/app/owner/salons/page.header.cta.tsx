<div className="flex items-center justify-between">
  <h1 className="text-2xl font-semibold text-gold">Meine Salons</h1>
  <div className="flex gap-2">
    <a href="/owner/onboarding" className="btn">Onboarding starten</a>
    <a href="/owner/salons/new" className="inline-flex items-center rounded px-3 py-2 border border-border hover:text-gold">Nur Salon anlegen</a>
  </div>
</div>
