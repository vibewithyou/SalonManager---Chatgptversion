## Produkt & UX
- **Onboarding-Wizard** unter `/owner/onboarding` führt durch Anlage (Stammdaten → Standort → Leistungen → Öffnungszeiten → Medien/Veröffentlichen).
- **Suche**: Pagination & Sortierung (`/api/salons?page=&pageSize=&sort=`).
- **Karte**: Marker-Cluster in der Ergebnisansicht.
- **Medien**: Upload mit leichter Client-Kompression, Logo markieren, Löschen.
