# Phase P2 Patch Notes

## Install
```bash
pnpm add react-leaflet-cluster browser-image-compression
```

## Files replaced (drop-in)
- `src/app/api/salons/route.ts`
- `src/app/page.tsx`
- `src/components/Map.tsx`
- `src/app/api/media/[id]/route.ts`
- `src/components/MediaUploader.tsx`
- `src/app/owner/salons/[id]/media/page.tsx`
- `src/app/owner/onboarding/page.tsx`

## Snippets to merge
- Add to `src/lib/validators.ts`:
  - `snippets/src/lib/validators.listParams.addition.ts`
- Add to `src/app/globals.css` (cluster styles):
  - `snippets/src/app/globals.css.cluster.css`
- Update header section in `src/app/owner/salons/page.tsx`:
  - `snippets/src/app/owner/salons/page.header.cta.tsx`
- README additions:
  - `snippets/README.p2.additions.md`
- package.json deps:
  - `snippets/package.json.additions.p2.json`

## Notes
- After mutations (create salon/service/opening hours), enqueue revalidation job if you use tag-based ISR:
  ```ts
  import { enqueue } from "@/lib/jobs"
  await enqueue({ t: "revalidate", tag: "salons" })
  ```
- Ensure Leaflet CSS is included globally (already in earlier steps).
