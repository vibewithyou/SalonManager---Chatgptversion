import { test, expect } from "@playwright/test"

test("customer cannot access owner area", async ({ page }) => {
  await page.goto("/login")
  await page.getByPlaceholder(/E-Mail/i).fill("customer@demo.tld")
  await page.getByPlaceholder(/Passwort/i).fill("Customer123!")
  await page.getByRole("button", { name: /Einloggen/i }).click()
  await page.goto("/owner/salons")
  await expect(page).toHaveURL(/\/(login|$)/)
})

test("staff cannot edit other salon", async ({ page }) => {
  await page.goto("/login")
  await page.getByPlaceholder(/E-Mail/i).fill("staff1@demo.tld")
  await page.getByPlaceholder(/Passwort/i).fill("Staff123!")
  await page.getByRole("button", { name: /Einloggen/i }).click()
  const resp = await page.request.patch("/api/salons/sln_fake", { data: { name: "HACK" } })
  expect([401,403,404]).toContain(resp.status())
})
