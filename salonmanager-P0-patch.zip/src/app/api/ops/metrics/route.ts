import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getRedis } from "@/lib/redis"

export async function GET() {
  const r = getRedis()
  const [queued, delayed] = r
    ? await Promise.all([
        r.llen("queue:jobs"),
        r.zcard("queue:jobs:delayed")
      ])
    : [null, null]

  const [users, salons, bookingsPending, bookingsConfirmed] = await Promise.all([
    prisma.user.count(),
    prisma.salon.count(),
    prisma.booking.count({ where: { status: "PENDING" } }),
    prisma.booking.count({ where: { status: "CONFIRMED" } })
  ])

  return NextResponse.json({
    time: new Date().toISOString(),
    queue: { main: queued, delayed },
    counts: { users, salons, bookingsPending, bookingsConfirmed }
  })
}
