import { NextResponse } from "next/server"
import { log } from "@/lib/logger"

export async function POST(req: Request) {
  const body = await req.json().catch(()=>null)
  log("csp.report", { report: body })
  return NextResponse.json({ ok: true })
}
