import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import { prisma } from "@/lib/prisma"
import { audit } from "@/lib/audit"
import { enqueue } from "@/lib/jobs"

export async function POST() {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id

  // Medien-URLs sammeln (Owner)
  const media = await prisma.media.findMany({ where: { salon: { ownerId: userId } }, select: { url: true } })
  for (const m of media) {
    await enqueue({ t: "mediaPurge", url: m.url })
  }

  await audit({ userId, action: "ACCOUNT_DELETE_REQUEST", entity: `User:${userId}`, meta: { mediaCount: media.length } })
  // Soft-Delete: persönlich identifizierbar entfernen
  await prisma.user.update({
    where: { id: userId },
    data: {
      email: `deleted+${userId}@example.tld`,
      name: null,
      hashedPassword: "!",
      stripeCustomerId: null
    }
  })
  return NextResponse.json({ ok: true, mediaQueued: media.length })
}
