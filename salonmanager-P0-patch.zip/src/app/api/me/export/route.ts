import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import { prisma } from "@/lib/prisma"

export async function GET() {
  const session = await getSessionOrThrow()
  const userId = (session.user as any).id

  const [user, staffProfiles, salonsOwned] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId } }),
    prisma.staffProfile.findMany({ where: { userId } }),
    prisma.salon.findMany({ where: { ownerId: userId } })
  ])

  const [bookingsAsCustomer, bookingsAsStaff, servicesOwned, openingHoursOwned, mediaOwned, tagsOwned] = await Promise.all([
    prisma.booking.findMany({ where: { customerId: userId } }),
    prisma.booking.findMany({ where: { staff: { userId } } }),
    prisma.service.findMany({ where: { salon: { ownerId: userId } } }),
    prisma.openingHour.findMany({ where: { salon: { ownerId: userId } } }),
    prisma.media.findMany({ where: { salon: { ownerId: userId } } }),
    prisma.tagOnSalon.findMany({ where: { salon: { ownerId: userId } } })
  ])

  return NextResponse.json({
    user, staffProfiles, salonsOwned,
    bookingsAsCustomer, bookingsAsStaff,
    servicesOwned, openingHoursOwned, mediaOwned, tagsOwned
  })
}
