import { env } from "./env"

const SECRET_KEYS = Object.entries(env)
  .filter(([k, v]) => typeof v === "string" && v && k.toUpperCase().includes("SECRET"))
  .map(([, v]) => String(v))

function redact(value: any) {
  const s = typeof value === "string" ? value : JSON.stringify(value)
  if (!s) return value
  let out = s
  for (const secret of SECRET_KEYS) {
    if (secret) {
      const esc = secret.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
      out = out.replace(new RegExp(esc, "g"), "***REDACTED***")
    }
  }
  try { return JSON.parse(out) } catch { return out }
}

export function log(event: string, meta: Record<string, any> = {}) {
  const payload = { ts: new Date().toISOString(), event, ...meta }
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(JSON.parse(redact(payload as any))))
}
