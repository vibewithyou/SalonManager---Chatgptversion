import { z } from "zod"

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  NEXTAUTH_URL: z.string().url(),
  NEXTAUTH_SECRET: z.string().min(16),

  DATABASE_URL: z.string().url(),
  DATABASE_READ_URL: z.string().url().optional(),

  RESEND_API_KEY: z.string().optional(),
  REDIS_URL: z.string().optional(),

  UPLOADTHING_SECRET: z.string().optional(),
  UPLOADTHING_APP_ID: z.string().optional(),
  // optionaler Delete-Key für Purge-Job (nur wenn Upload-Anbieter das unterstützt)
  UPLOADTHING_DELETE_KEY: z.string().optional(),

  SENTRY_DSN: z.string().optional(),
  SENTRY_ENV: z.string().optional(),

  JOBS_SECRET: z.string().min(16),

  // Stripe optional (nur falls Billing live geht)
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  STRIPE_PRICE_MONTHLY: z.string().optional(),
  STRIPE_TRIAL_DAYS: z.string().optional()
})

export const env = envSchema.parse({
  NODE_ENV: process.env.NODE_ENV,
  NEXTAUTH_URL: process.env.NEXTAUTH_URL,
  NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,

  DATABASE_URL: process.env.DATABASE_URL,
  DATABASE_READ_URL: process.env.DATABASE_READ_URL,

  RESEND_API_KEY: process.env.RESEND_API_KEY,
  REDIS_URL: process.env.REDIS_URL,

  UPLOADTHING_SECRET: process.env.UPLOADTHING_SECRET,
  UPLOADTHING_APP_ID: process.env.UPLOADTHING_APP_ID,
  UPLOADTHING_DELETE_KEY: process.env.UPLOADTHING_DELETE_KEY,

  SENTRY_DSN: process.env.SENTRY_DSN,
  SENTRY_ENV: process.env.SENTRY_ENV,

  JOBS_SECRET: process.env.JOBS_SECRET,

  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY,
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET,
  STRIPE_PRICE_MONTHLY: process.env.STRIPE_PRICE_MONTHLY,
  STRIPE_TRIAL_DAYS: process.env.STRIPE_TRIAL_DAYS
})
