#!/usr/bin/env bash
set -euo pipefail
TS=$(date +"%Y%m%d-%H%M%S")
OUT="backup-$TS.sql.gz"
echo "Dumping to $OUT ..."
pg_dump --no-owner --format=custom "$DATABASE_URL" | gzip > "$OUT"
echo "Done: $OUT"
