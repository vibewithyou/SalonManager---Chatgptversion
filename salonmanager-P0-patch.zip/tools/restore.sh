#!/usr/bin/env bash
set -euo pipefail
if [ -z "${1:-}" ]; then echo "Usage: restore.sh <dump.sql.gz>"; exit 1; fi
FILE="$1"
TMP="restore-$RANDOM.dump"
gunzip -c "$FILE" > "$TMP"
pg_restore --clean --no-owner --dbname "$DATABASE_URL" "$TMP"
rm -f "$TMP"
echo "Restore complete."
