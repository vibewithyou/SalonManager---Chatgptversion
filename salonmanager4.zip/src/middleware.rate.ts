const buckets = new Map<string, { ts: number; count: number }>()
export function rateLimit(ip: string, key: string, max = 20, windowMs = 60_000) {
  const k = `${ip}:${key}`
  const now = Date.now()
  const b = buckets.get(k)
  if (!b || now - b.ts > windowMs) {
    buckets.set(k, { ts: now, count: 1 })
    return true
  }
  if (b.count >= max) return false
  b.count++
  return true
}
