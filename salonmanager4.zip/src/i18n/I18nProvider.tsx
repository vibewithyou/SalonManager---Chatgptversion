"use client"

import { createContext, useContext } from "react"
import { dict, type Locale, type Namespaces, type Keys } from "./dictionaries"

const I18nCtx = createContext<{ t: <N extends Namespaces>(ns: N, k: Keys<N>) => string }>({
  t: (_ns, k) => String(k)
})

export function I18nProvider({ locale = "de", children }: { locale?: Locale; children: React.ReactNode }) {
  const d = dict[locale]
  return (
    <I18nCtx.Provider value={{ t: (ns, k) => (d as any)[ns]?.[k] ?? String(k) }}>
      {children}
    </I18nCtx.Provider>
  )
}

export function useT() { return useContext(I18nCtx).t }
