import { prisma } from "@/lib/prisma"
import type { Metadata } from "next"
import Image from "next/image"

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const salon = await prisma.salon.findUnique({ where: { slug: params.slug } })
  if (!salon) return {}
  const title = `${salon.name} – SalonManager`
  const desc = salon.description ?? `${salon.address}, ${salon.city}`
  return {
    title,
    description: desc,
    openGraph: {
      title,
      description: desc,
      type: "website",
      url: `/salon/${params.slug}`
    }
  }
}

export default async function SalonPage({ params }: { params: { slug: string } }) {
  const salon = await prisma.salon.findUnique({
    where: { slug: params.slug },
    include: { services: true, media: true }
  })
  if (!salon || !salon.isPublished) return <div className="card">Salon nicht gefunden</div>

  return (
    <div className="grid gap-6">
      <header className="card flex items-center gap-4">
        <div className="h-16 w-16 rounded-full border-2 border-gold overflow-hidden">
          <Image src={salon.media.find(m=>m.type==="LOGO")?.url ?? "/icon-192.png"} alt={salon.name} width={64} height={64}/>
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-gold">{salon.name}</h1>
          <p className="text-sm text-muted">{salon.city} • {salon.address}</p>
        </div>
      </header>

      <section className="card">
        <h2 className="mb-2 font-medium">Leistungen</h2>
        <ul className="grid gap-2">
          {salon.services.map(s => (
            <li key={s.id} className="flex items-center justify-between border border-border rounded p-3">
              <span>{s.name}</span>
              <span className="text-gold">{(s.priceCents/100).toFixed(2)} € • {s.durationMin} min</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card">
        <h2 className="mb-2 font-medium">Empfehlungen (bald)</h2>
        <p className="text-sm text-muted">KI-Dummy: Empfehlungen folgen.</p>
      </section>
    </div>
  )
}
