import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"

const weekdays = ["Mo","Di","Mi","Do","Fr","Sa","So"]

async function saveHour(_: any, formData: FormData) {
  "use server"
  const salonId = String(formData.get("salonId"))
  const weekday = Number(formData.get("weekday"))
  const openTime = String(formData.get("openTime"))
  const closeTime = String(formData.get("closeTime"))
  const isClosed = formData.get("isClosed") === "on"

  const existing = await prisma.openingHour.findFirst({ where: { salonId, weekday } })
  if (existing) {
    await prisma.openingHour.update({ where: { id: existing.id }, data: { openTime, closeTime, isClosed } })
  } else {
    await prisma.openingHour.create({ data: { salonId, weekday, openTime, closeTime, isClosed } })
  }
  revalidatePath(`/owner/salons/${salonId}/hours`)
}

export default async function HoursPage({ params }: { params: { id: string } }) {
  const hours = await prisma.openingHour.findMany({ where: { salonId: params.id } })
  const map = new Map(hours.map(h => [h.weekday, h]))

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Öffnungszeiten</h1>
      <div className="grid gap-3 max-w-2xl">
        {weekdays.map((lbl, idx) => {
          const h = map.get(idx) || { openTime: "09:00", closeTime: "18:00", isClosed: false }
          return (
            <form key={idx} action={saveHour} className="card grid grid-cols-5 gap-3 items-center">
              <input type="hidden" name="salonId" value={params.id} />
              <input type="hidden" name="weekday" value={idx} />
              <div className="font-medium">{lbl}</div>
              <input className="input" type="time" name="openTime" defaultValue={h.openTime} />
              <input className="input" type="time" name="closeTime" defaultValue={h.closeTime} />
              <label className="text-sm flex items-center gap-2">
                <input type="checkbox" name="isClosed" defaultChecked={h.isClosed} />
                geschlossen
              </label>
              <button className="btn">Speichern</button>
            </form>
          )
        })}
      </div>
    </div>
  )
}
