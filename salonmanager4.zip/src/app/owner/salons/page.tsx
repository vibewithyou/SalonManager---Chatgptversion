import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"
import Link from "next/link"

export default async function OwnerSalonsPage() {
  const session = await auth()
  if (!session?.user) return <div className="card">Bitte einloggen.</div>
  const meId = (session.user as any).id
  const salons = await prisma.salon.findMany({ where: { ownerId: meId }, orderBy: { updatedAt: "desc" } })

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gold">Meine Salons</h1>
        <Link href="/owner/salons/new" className="btn">Salon anlegen</Link>
      </div>
      <ul className="grid gap-3">
        {salons.map(s => (
          <li key={s.id} className="card flex items-center justify-between">
            <div>
              <div className="font-medium">{s.name}</div>
              <div className="text-sm text-muted">{s.city} • {s.address}</div>
            </div>
            <Link className="underline hover:text-gold" href={`/owner/salons/${s.id}`}>Verwalten</Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
