import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"

export default async function StaffAgenda() {
  const session = await auth()
  if (!session?.user) return <div className="card">Bitte einloggen.</div>
  const userId = (session.user as any).id
  const profile = await prisma.staffProfile.findFirst({ where: { userId }, include: { salon: true } })
  if (!profile) return <div className="card">Keine Staff-Zugehörigkeit. Bitte Einladung annehmen.</div>

  const bookings = await prisma.booking.findMany({
    where: { staffId: profile.id },
    include: { service: true, customer: true },
    orderBy: { start: "asc" }
  })

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-semibold text-gold">Agenda – {profile.displayName}</h1>
      <ul className="grid gap-2">
        {bookings.map(b=>(
          <li key={b.id} className="card flex items-center justify-between text-sm">
            <span>{new Date(b.start).toLocaleString()} — {b.service.name} für {b.customer.email}</span>
            <span className={`badge ${b.status.toLowerCase()}`}>{b.status}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
