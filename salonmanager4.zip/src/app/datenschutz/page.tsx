export default function Datenschutz() {
  return (
    <div className="prose prose-invert">
      <h1 className="text-gold">Datenschutz</h1>
      <p>Demo-Inhalt. Ersetze durch deine Datenschutzerklärung.</p>
    </div>
  )
}
