import { hasStripe } from "@/services/stripe"

export default function Pricing() {
  const enabled = hasStripe()
  return (
    <div className="card">
      <h1 className="text-2xl font-semibold text-gold">Preise</h1>
      <p className="text-sm text-muted mt-2">
        {enabled ? "Stripe aktiviert – Checkout folgt." : "Zahlungen sind im ersten Release deaktiviert."}
      </p>
    </div>
  )
}
