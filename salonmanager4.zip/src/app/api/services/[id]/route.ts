import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { servicePatchSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const svc = await prisma.service.findUnique({ where: { id: params.id }, include: { salon: true } })
  if (!svc) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && svc.salon.ownerId !== (session.user as any).id)
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const data = servicePatchSchema.parse(await req.json())
  const updated = await prisma.service.update({ where: { id: params.id }, data })
  return NextResponse.json(updated)
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const svc = await prisma.service.findUnique({ where: { id: params.id }, include: { salon: true } })
  if (!svc) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && svc.salon.ownerId !== (session.user as any).id)
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  await prisma.service.delete({ where: { id: params.id } })
  return NextResponse.json({ ok: true })
}
