/** @type {import('next').NextConfig} */
const withPWA = require('next-pwa')({
  dest: 'public',
  disable: process.env.NODE_ENV === 'development',
  register: true,
  skipWaiting: true,
  fallbacks: { document: '/offline' },
  runtimeCaching: [
    {
      urlPattern: /^https:\/\/{0,1}.*\.(?:png|jpg|jpeg|svg|gif|webp)$/,
      handler: 'CacheFirst',
      options: { cacheName: 'images', expiration: { maxEntries: 100, maxAgeSeconds: 60 * 60 * 24 * 30 } }
    },
    {
      urlPattern: /^https:\/\/{0,1}.*\/api\/salons.*$/,
      handler: 'NetworkFirst',
      options: { cacheName: 'api-salons', networkTimeoutSeconds: 3 }
    },
    {
      urlPattern: /^https:\/\/{0,1}.*\/salon\/.*$/,
      handler: 'NetworkFirst',
      options: { cacheName: 'pages-salon', networkTimeoutSeconds: 3 }
    }
  ]
})

module.exports = withPWA({
  reactStrictMode: true,
  experimental: { typedRoutes: true }
})
