# Phase P3 — Performance, SEO, Admin, i18n (bolt.new-tauglich)

Diese Lieferung enthält **neue/ersetzte Dateien** plus kurze Hinweise für Teil-Patches (Prisma-Indizes & package.json).
Wende die Dateien 1:1 an; die Teil-Patches fügst du manuell in bestehende Dateien ein.

## Teil-Patches (manuell einfügen)

### 1) `package.json` – Analyzer Script
```json
{
  "devDependencies": { "@next/bundle-analyzer": "^14.2.5" },
  "scripts": { "analyze": "ANALYZE=true next build" }
}
```

### 2) `prisma/schema.prisma` – DB-Indizes
```prisma
model Salon {
  // ...
  @@index([isPublished, city])
  @@index([slug])
  @@index([createdAt])
  @@index([latitude, longitude])
}
model Service {
  // ...
  @@index([salonId, priceCents])
}
model OpeningHour {
  // ...
  @@index([salonId, weekday])
}
model Booking {
  // ...
  @@index([salonId, start, status])
  @@index([customerId, start])
  @@index([staffId, start])
}
```
> Danach `pnpm prisma:migrate`.

### 3) ISR/Tags – nach Mutationen
Nach `POST/PATCH` in Salon-/Service-/OpeningHours-/Media-Routen:
```ts
import { enqueue } from "@/lib/jobs"
await enqueue({ t: "revalidate", tag: "salons" })
await enqueue({ t: "revalidate", tag: `salon:${salon.slug}` })
```
Und **öffentliche Fetches** mit `next:{ tags:["salons"] }` bzw. `next:{ tags:[\`salon:${slug}\`] }` versehen.

---

## Neue/ersetzte Dateien (liegen in diesem Zip)

- `next.config.js` (mit PWA + Bundle Analyzer + Security Header + Images)
- `src/app/sitemap.ts`
- `src/app/robots.ts`
- `src/app/admin/dashboard/page.tsx`
- `src/app/api/admin/export/bookings.csv/route.ts`
- `src/i18n/format.ts`
- `src/app/api/locale/route.ts`
- `src/components/LanguageSwitcher.tsx`
- `src/app/salon/[slug]/page.tsx` (mit JSON-LD Injection)
