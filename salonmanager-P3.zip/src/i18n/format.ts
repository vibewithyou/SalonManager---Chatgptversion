export function fmtCurrency(valueCents: number, locale = "de", currency = "EUR") {
  return new Intl.NumberFormat(locale, { style: "currency", currency }).format(valueCents / 100)
}
export function fmtDateTime(d: Date | string, locale = "de") {
  const date = typeof d === "string" ? new Date(d) : d
  return new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short" }).format(date)
}
