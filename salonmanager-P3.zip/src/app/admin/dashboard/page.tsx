import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"

export default async function AdminDashboard() {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return <div className="card">Forbidden</div>

  const [salonCount, userCount, bookingCount, pendingBookings] = await Promise.all([
    prisma.salon.count(),
    prisma.user.count(),
    prisma.booking.count(),
    prisma.booking.count({ where: { status: "PENDING" } })
  ])

  const recent = await prisma.booking.findMany({
    take: 10,
    orderBy: { createdAt: "desc" },
    include: { salon: true, service: true, customer: true }
  })

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-gold">Admin Dashboard</h1>
      <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card"><div className="text-sm text-muted">Salons</div><div className="text-2xl">{salonCount}</div></div>
        <div className="card"><div className="text-sm text-muted">Users</div><div className="text-2xl">{userCount}</div></div>
        <div className="card"><div className="text-sm text-muted">Bookings</div><div className="text-2xl">{bookingCount}</div></div>
        <div className="card"><div className="text-sm text-muted">Pending</div><div className="text-2xl">{pendingBookings}</div></div>
      </section>

      <section className="card">
        <div className="flex items-center justify-between">
          <h2 className="font-medium">Neueste Buchungen</h2>
          <a className="btn" href="/api/admin/export/bookings.csv">CSV Export</a>
        </div>
        <table className="w-full text-sm mt-3">
          <thead className="text-muted">
            <tr>
              <th className="text-left">Zeit</th>
              <th className="text-left">Salon</th>
              <th className="text-left">Service</th>
              <th className="text-left">Kunde</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {recent.map(b => (
              <tr key={b.id} className="border-t border-border">
                <td>{new Date(b.start).toLocaleString()}</td>
                <td>{b.salon.name}</td>
                <td>{b.service.name}</td>
                <td>{b.customer.email}</td>
                <td><span className={`badge ${b.status.toLowerCase()}`}>{b.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  )
}
