import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const { locale } = await req.json() as { locale: "de" | "en" }
  if (!["de","en"].includes(locale)) return NextResponse.json({ error: "Invalid" }, { status: 400 })
  const res = NextResponse.json({ ok: true })
  res.cookies.set("locale", locale, { path: "/", maxAge: 60*60*24*365 })
  return res
}
