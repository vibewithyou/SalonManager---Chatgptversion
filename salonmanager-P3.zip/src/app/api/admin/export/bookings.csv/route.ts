import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"

export async function GET() {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const rows = await prisma.booking.findMany({
    include: { salon: true, service: true, customer: true },
    orderBy: { start: "desc" }
  })
  const header = ["id","salon","service","customer","start","end","status","createdAt"]
  const lines = [header.join(",")].concat(
    rows.map(b => [
      b.id,
      `"${b.salon.name.replace(/"/g,'""')}"`,
      `"${b.service.name.replace(/"/g,'""')}"`,
      `"${(b.customer.email||"").replace(/"/g,'""')}"`,
      b.start.toISOString(),
      b.end.toISOString(),
      b.status,
      b.createdAt.toISOString()
    ].join(","))
  )
  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="bookings.csv"`
    }
  })
}
