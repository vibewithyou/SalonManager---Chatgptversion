import { prisma } from "@/lib/prisma"

export default async function sitemap() {
  const base = process.env.NEXTAUTH_URL || "http://localhost:3000"
  const salons = await prisma.salon.findMany({
    where: { isPublished: true },
    select: { slug: true, updatedAt: true }
  })
  return [
    { url: `${base}/`, lastModified: new Date() },
    ...salons.map(s => ({ url: `${base}/salon/${s.slug}`, lastModified: s.updatedAt }))
  ]
}
