import { prisma } from "@/lib/prisma"
import type { Metadata } from "next"
import Image from "next/image"

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const salon = await prisma.salon.findUnique({ where: { slug: params.slug } })
  if (!salon) return {}
  const title = `${salon.name} – SalonManager`
  const desc = salon.description ?? `${salon.address}, ${salon.city}`
  return {
    title,
    description: desc,
    openGraph: {
      title,
      description: desc,
      type: "website",
      url: `/salon/${params.slug}`
    }
  }
}

export default async function SalonPage({ params }: { params: { slug: string } }) {
  const salon = await prisma.salon.findUnique({
    where: { slug: params.slug },
    include: { services: true, media: true, openingHours: true }
  })
  if (!salon || !salon.isPublished) return <div className="card">Salon nicht gefunden</div>

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "HairSalon",
    name: salon.name,
    address: {
      "@type": "PostalAddress",
      streetAddress: salon.address,
      addressLocality: salon.city,
      postalCode: salon.postalCode,
      addressCountry: salon.country
    },
    url: `/salon/${params.slug}`,
    geo: { "@type": "GeoCoordinates", latitude: salon.latitude, longitude: salon.longitude },
    openingHoursSpecification: salon.openingHours.map(h => ({
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][(h.weekday+1)%7],
      opens: h.isClosed ? undefined : h.openTime,
      closes: h.isClosed ? undefined : h.closeTime
    })).filter(Boolean)
  }

  return (
    <div className="grid gap-6">
      <header className="card flex items-center gap-4">
        <div className="h-16 w-16 rounded-full border-2 border-gold overflow-hidden">
          <Image
            src={salon.media.find(m=>m.type==="LOGO")?.url ?? "/icon-192.png"}
            alt={salon.name}
            width={64} height={64}
          />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-gold">{salon.name}</h1>
          <p className="text-sm text-muted">{salon.city} • {salon.address}</p>
        </div>
      </header>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <section className="card">
        <h2 className="font-medium mb-2">Leistungen</h2>
        <ul className="grid gap-2">
          {salon.services.map(s => (
            <li key={s.id} className="flex items-center justify-between border border-border rounded p-2">
              <div>{s.name}</div>
              <div className="text-gold">{(s.priceCents/100).toFixed(2)} € • {s.durationMin} min</div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
