"use client"

export function LanguageSwitcher() {
  async function setLocale(l: "de"|"en") {
    await fetch("/api/locale", {
      method: "POST",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ locale: l })
    })
    location.reload()
  }
  return (
    <div className="flex items-center gap-2 text-sm">
      <button className="underline hover:text-gold" onClick={()=>setLocale("de")}>DE</button>
      <span className="text-muted">/</span>
      <button className="underline hover:text-gold" onClick={()=>setLocale("en")}>EN</button>
    </div>
  )
}
