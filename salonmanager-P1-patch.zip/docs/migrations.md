# Zero-Downtime Migrations (ZDM) – Leitfaden

## Grundprinzipien
1) **Additiv deployen**: Spalten/Tabellen hinzufügen, Code kann alte + neue Pfade verarbeiten (Double-Write/Read).
2) **Backfill**: Daten in Batches füllen (Job/Script), ohne lange Locks.
3) **Switch**: Code beginnt neue Spalte zu nutzen (Feature-Flag).
4) **Clean-up**: Alte Spalte erst entfernen, wenn nicht mehr genutzt.

## Beispiel: neue Spalte `Service.bufferMin`
- Phase A: Spalte adden (NULL/Default); Code toleriert NULL.
- Phase B: Backfill: `UPDATE "Service" SET "bufferMin" = 0 WHERE "bufferMin" IS NULL;`
- Phase C: App erzwingt `bufferMin` in Validation.
- Phase D: Constraint `NOT NULL` hinzufügen.

## Backfill-Script (Batch)
```sql
-- 5k Zeilen pro Batch
UPDATE "Booking" SET "note" = COALESCE("note",'') WHERE "note" IS NULL LIMIT 5000;
```

## Rollbacks
* Niemals `DROP` im selben Deployment wie Code-Abhängigkeit.
* Enum-Änderungen: neuen Wert hinzufügen → Code nutzen → alten später entfernen.

## Prüfliste
* [ ] Reihenfolge der Migrations geprüft
* [ ] Backfill-Job vorbereitet (idempotent)
* [ ] Feature-Flag/Toggle für neuen Codepfad
* [ ] Monitoring auf Errors/Slow Queries
