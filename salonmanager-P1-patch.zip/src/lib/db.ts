import { PrismaClient } from "@prisma/client"
import { shouldReadPrimary } from "./consistency"

// Write client (primary)
export const prismaW = new PrismaClient()

// Read client (replica optional)
export const prismaR = process.env.DATABASE_READ_URL
  ? new PrismaClient({ datasources: { db: { url: process.env.DATABASE_READ_URL } } })
  : prismaW

// Helper: choose client by intent
export function db(readonly = false) {
  if (!readonly) return prismaW
  if (shouldReadPrimary()) return prismaW // Read-after-write hint
  return prismaR
}
