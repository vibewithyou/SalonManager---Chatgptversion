import { getRedis } from "./redis"
import { prisma } from "@/lib/prisma"

type JobBase = { attempt?: number; maxAttempts?: number }
export type Job =
  | (JobBase & { t: "email"; to: string; subject: string; html: string })
  | (JobBase & { t: "revalidate"; tag: string })
  | (JobBase & { t: "gcalSync"; bookingId: string })
  | (JobBase & { t: "mediaPurge"; url: string })

const Q_MAIN = "queue:jobs"
const Q_DELAY = "queue:jobs:delayed"
const Q_DLQ = "queue:jobs:dlq"

function nowMs() { return Date.now() }
function backoffMs(attempt: number) { return Math.min(5 * 60_000, 5_000 * Math.pow(2, attempt - 1)) }

export async function enqueue(job: Job, delayMs = 0) {
  const r = getRedis()
  if (!r) throw new Error("Redis not configured")
  const withMeta = { ...job, attempt: job.attempt ?? 0, maxAttempts: job.maxAttempts ?? 5 }
  if (delayMs > 0) await r.zadd(Q_DELAY, String(nowMs() + delayMs), JSON.stringify(withMeta))
  else await r.rpush(Q_MAIN, JSON.stringify(withMeta))
}

export async function promoteDelayed() {
  const r = getRedis(); if (!r) return 0
  const now = nowMs()
  const jobs = await r.zrangebyscore(Q_DELAY, 0, now, "LIMIT", 0, 100)
  if (jobs.length === 0) return 0
  const multi = r.multi()
  for (const j of jobs) { multi.rpush(Q_MAIN, j); multi.zrem(Q_DELAY, j) }
  await multi.exec()
  return jobs.length
}

export async function processOne(handler?: Partial<{
  email: (j: Extract<Job, {t:"email"}>) => Promise<void>,
  revalidate: (j: Extract<Job, {t:"revalidate"}>) => Promise<void>,
  gcalSync: (j: Extract<Job, {t:"gcalSync"}>) => Promise<void>,
  mediaPurge: (j: Extract<Job, {t:"mediaPurge"}>) => Promise<void>
}>) {
  const r = getRedis(); if (!r) return 0
  const data = await r.lpop(Q_MAIN); if (!data) return 0
  const job: Job = JSON.parse(data)
  try {
    if (job.t === "email") {
      const sup = await prisma.emailSuppression.findUnique({ where: { email: job.to } })
      if (!sup) await handler?.email?.(job)
      await prisma.emailEvent.create({ data: { to: job.to, subject: job.subject, status: "sent" } })
    } else if (job.t === "revalidate") {
      await handler?.revalidate?.(job)
    } else if (job.t === "gcalSync") {
      await handler?.gcalSync?.(job)
    } else if (job.t === "mediaPurge") {
      await handler?.mediaPurge?.(job)
    }
  } catch (e: any) {
    const attempt = (job.attempt ?? 0) + 1
    if (attempt <= (job.maxAttempts ?? 5)) {
      await enqueue({ ...job, attempt }, backoffMs(attempt))
    } else {
      // push to DLQ
      await r.rpush(Q_DLQ, JSON.stringify({ job, error: String(e?.message ?? e), failedAt: new Date().toISOString() }))
      if (job.t === "email") {
        await prisma.emailEvent.create({ data: { to: job.to, subject: job.subject, status: "error", error: String(e?.message ?? e) } })
      }
    }
  }
  return 1
}

export async function processBatch(n = 25, handler?: Parameters<typeof processOne>[0]) {
  let done = 0
  await promoteDelayed()
  for (let i = 0; i < n; i++) {
    const r = await processOne(handler); if (!r) break; done += r
  }
  return done
}
