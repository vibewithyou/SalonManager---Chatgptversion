// Edge-compatible rate limit using Upstash REST API (usable from middleware)
const REST_URL = process.env.UPSTASH_REDIS_REST_URL as string | undefined
const REST_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN as string | undefined

export async function edgeRateLimit(bucket: string, ip: string, limit = 100, windowSec = 60) {
  if (!REST_URL || !REST_TOKEN) return true
  const key = `edge:${bucket}:${ip}`
  const res = await fetch(`${REST_URL}/pipeline`, {
    method: "POST",
    headers: { Authorization: `Bearer ${REST_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({ commands: [["INCR", key], ["EXPIRE", key, String(windowSec), "NX"]] })
  })
  const arr = await res.json().catch(()=>null) as any[]
  const count = Array.isArray(arr) && arr[0]?.result ? Number(arr[0].result) : 1
  return count <= limit
}
