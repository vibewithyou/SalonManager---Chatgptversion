import { getRedis } from "@/lib/redis"
import { NextResponse } from "next/server"

// Stores and replays identical responses for the same Idempotency-Key + scope.
// Default TTL: 10 minutes.
export async function withIdempotency(
  req: Request,
  scope: string,
  handler: () => Promise<NextResponse>,
  ttlSec = 600
): Promise<NextResponse> {
  const keyHeader = req.headers.get("Idempotency-Key") || req.headers.get("X-Idempotency-Key")
  if (!keyHeader) return handler()
  const r = getRedis()
  if (!r) return handler()

  const redisKey = `idem:${scope}:${hash(keyHeader)}`
  const cached = await r.get(redisKey)
  if (cached) {
    const parsed = JSON.parse(cached) as { status: number; body: any; headers?: Record<string, string> }
    const resp = new NextResponse(JSON.stringify(parsed.body), {
      status: parsed.status,
      headers: { "Content-Type": "application/json", "Idempotency-Replay": "true", ...(parsed.headers || {}) }
    })
    resp.headers.set("Idempotency-Key", keyHeader)
    return resp
  }

  // Reserve Slot (prevent thundering herd)
  const ok = await r.set(redisKey + ":lock", "1", "PX", ttlSec * 1000, "NX")
  if (!ok) {
    // already in progress — short sleep then try to read cached result
    await sleep(200)
    const again = await r.get(redisKey)
    if (again) {
      const parsed = JSON.parse(again) as { status: number; body: any }
      const resp = new NextResponse(JSON.stringify(parsed.body), {
        status: parsed.status,
        headers: { "Content-Type": "application/json", "Idempotency-Replay": "true" }
      })
      resp.headers.set("Idempotency-Key", keyHeader)
      return resp
    }
  }

  const res = await handler()

  // Only cache small JSON responses
  const status = res.status
  let body: any = null
  try { body = await res.clone().json() } catch { body = null }
  const headers: Record<string, string> = {}
  const out = JSON.stringify({ status, body, headers })
  await r.set(redisKey, out, "EX", ttlSec)
  await r.del(redisKey + ":lock")

  res.headers.set("Idempotency-Key", keyHeader)
  return res
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }
function hash(s: string) {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h.toString(16)
}
