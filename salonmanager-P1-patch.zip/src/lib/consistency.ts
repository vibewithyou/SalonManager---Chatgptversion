import { cookies } from "next/headers"

// Set a short-lived hint cookie to force reads from primary after a write.
export function setReadPrimaryHint(seconds = 5) {
  try {
    const c = cookies()
    c.set("rw", "primary", { path: "/", maxAge: seconds, httpOnly: false, sameSite: "lax" })
  } catch {}
}

export function shouldReadPrimary(): boolean {
  try {
    const c = cookies()
    return c.get("rw")?.value === "primary"
  } catch { return false }
}
