import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getRedis } from "@/lib/redis"

export async function GET() {
  const r = getRedis()
  let queued: number | null = null, delayed: number | null = null, dlq: number | null = null, idemKeys: number | null = null
  if (r) {
    ;[queued, delayed, dlq] = await Promise.all([
      r.llen("queue:jobs"),
      r.zcard("queue:jobs:delayed"),
      r.llen("queue:jobs:dlq"),
    ])
    try {
      // Approximation; for a precise count of idem:* keys you'd need KEYS which is expensive.
      idemKeys = await r.dbsize() as unknown as number
    } catch {}
  }

  const [users, salons, bookingsPending, bookingsConfirmed] = await Promise.all([
    prisma.user.count(),
    prisma.salon.count(),
    prisma.booking.count({ where: { status: "PENDING" } }),
    prisma.booking.count({ where: { status: "CONFIRMED" } })
  ])

  return NextResponse.json({
    time: new Date().toISOString(),
    queue: { main: queued, delayed, dlq },
    idem: { approxKeys: idemKeys },
    counts: { users, salons, bookingsPending, bookingsConfirmed }
  })
}
