import { NextResponse } from "next/server"
import { prismaR } from "@/lib/db"

export async function GET() {
  try {
    // On primary this will return null; on a replica returns seconds of delay
    const row = await prismaR.$queryRawUnsafe<{ lag: number }[]>(
      `SELECT EXTRACT(EPOCH FROM now() - pg_last_xact_replay_timestamp())::float AS lag`
    )
    const lagSec = row?.[0]?.lag ?? null
    return NextResponse.json({ ok: true, lagSec })
  } catch (e: any) {
    return NextResponse.json({ ok: false, reason: "not-replica-or-no-permission" })
  }
}
