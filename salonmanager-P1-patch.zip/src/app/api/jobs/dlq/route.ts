import { NextResponse } from "next/server"
import { getRedis } from "@/lib/redis"
import { auth } from "@/auth"

export async function GET() {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const r = getRedis(); if (!r) return NextResponse.json({ error: "No Redis" }, { status: 500 })
  const list = await r.lrange("queue:jobs:dlq", 0, 49)
  return NextResponse.json({ items: list.map(s => JSON.parse(s)) })
}

export async function POST(req: Request) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const r = getRedis(); if (!r) return NextResponse.json({ error: "No Redis" }, { status: 500 })
  const { count = 10 } = await req.json().catch(() => ({})) as { count?: number }
  let moved = 0
  for (let i = 0; i < count; i++) {
    const item = await r.rpop("queue:jobs:dlq")
    if (!item) break
    const parsed = JSON.parse(item)
    await r.rpush("queue:jobs", JSON.stringify({ ...(parsed.job || parsed) }))
    moved++
  }
  return NextResponse.json({ replayed: moved })
}
