import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { auth } from "@/auth"
import { edgeRateLimit } from "@/lib/edge-rate"

export async function middleware(req: NextRequest) {
  const resHeaders = new Headers()
  const rid = req.headers.get("x-request-id") || crypto.randomUUID()
  resHeaders.set("x-request-id", rid)

  const url = req.nextUrl
  const path = url.pathname

  // Edge Rate-Limit for API routes
  if (path.startsWith("/api/")) {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
      || req.headers.get("cf-connecting-ip")
      || "0.0.0.0"
    const isAuth = path.startsWith("/api/auth")
    const ok = await edgeRateLimit(isAuth ? "auth" : "api", String(ip), isAuth ? 20 : 120, 60)
    if (!ok) {
      return new NextResponse(JSON.stringify({ error: "Too many requests" }), { status: 429, headers: { ...Object.fromEntries(resHeaders), "Content-Type": "application/json" } })
    }
  }

  // Simple RBAC gate (server-side routes still validate)
  const session = await auth()
  const protectedPaths = [
    { prefix: "/owner", roles: ["OWNER", "ADMIN"] },
    { prefix: "/staff", roles: ["STAFF", "ADMIN"] },
    { prefix: "/me", roles: ["CUSTOMER", "ADMIN", "OWNER", "STAFF"] }
  ]
  for (const p of protectedPaths) {
    if (path.startsWith(p.prefix)) {
      if (!session?.user) return NextResponse.redirect(new URL("/login", url), { headers: resHeaders })
      const role = (session.user as any).role as string
      if (!p.roles.includes(role)) return NextResponse.redirect(new URL("/", url), { headers: resHeaders })
    }
  }
  return NextResponse.next({ headers: resHeaders })
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] }
