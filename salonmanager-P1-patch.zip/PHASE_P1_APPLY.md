# Apply Guide – PHASE P1 (Reliability & Scalability)

## 1) ENV
Append to `.env` / `.env.example`:
```
UPSTASH_REDIS_REST_URL="https://<upstash-id>.upstash.io"
UPSTASH_REDIS_REST_TOKEN="<rest-token>"
# Optional
UPLOADTHING_DELETE_KEY="<server-delete-key>"
```

## 2) Idempotency in critical POSTs
Example for `src/app/api/bookings/route.ts`:
```ts
import { withIdempotency } from "@/lib/idempotency"

export async function POST(req: Request) {
  const session = await requireUser()
  return withIdempotency(req, `booking:create:${(session.user as any).id}`, async () => {
    // ... existing create logic ...
    return NextResponse.json(created, { status: 201 })
  })
}
```
Add the import at top, wrap the existing logic with `withIdempotency`.

## 3) Read-after-write hint after mutations
In any POST/PATCH that changes state:
```ts
import { setReadPrimaryHint } from "@/lib/consistency"
// after successful write:
setReadPrimaryHint(5)
```

## 4) Middleware
If you already have `src/middleware.ts`, merge in the Edge rate-limit section at the top
and keep any existing redirects/guards you implemented. The provided file is safe to replace.

## 5) DLQ
`/api/jobs/dlq` (GET list, POST replay) requires ADMIN. Link it from your admin area if you like.

## 6) Replica lag
Check `/api/ops/replica-lag` when `DATABASE_READ_URL` is configured. If it returns `{ ok: true, lagSec: N }` use that to inform your read-after-write window if needed.

## 7) Metrics endpoint
`/api/ops/metrics` now includes DLQ size and a rough Redis key count.
