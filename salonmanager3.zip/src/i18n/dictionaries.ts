export const dict = {
  de: {
    findSalon: "Finde deinen Salon",
    login: "Login",
    register: "Registrieren",
    myBookings: "Meine Buchungen",
    view: "Ansehen"
  },
  en: {
    findSalon: "Find your salon",
    login: "Login",
    register: "Register",
    myBookings: "My bookings",
    view: "View"
  }
}
export type Locale = keyof typeof dict
