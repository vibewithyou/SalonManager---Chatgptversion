"use client"

import { createContext, useContext } from "react"
import { dict, type Locale } from "./dictionaries"

const I18nCtx = createContext<{ t: (k: keyof typeof dict["de"]) => string }>({ t: (k) => String(k) })

export function I18nProvider({ locale = "de", children }: { locale?: Locale; children: React.ReactNode }) {
  const d = dict[locale]
  return <I18nCtx.Provider value={{ t: (k) => d[k] ?? String(k) }}>{children}</I18nCtx.Provider>
}

export function useT() {
  return useContext(I18nCtx).t
}
