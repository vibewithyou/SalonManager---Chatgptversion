import { auth } from "@/auth"
import { Role } from "@prisma/client"

export async function requireUser() {
  const session = await auth()
  if (!session?.user) throw new Error("UNAUTHORIZED")
  return session
}

export function ensureRole(role: Role | Role[], userRole: Role) {
  const allowed = Array.isArray(role) ? role : [role]
  if (!allowed.includes(userRole)) throw new Error("FORBIDDEN")
}
