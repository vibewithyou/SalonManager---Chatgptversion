import { NextResponse } from "next/server"
import { getAvailableSlots } from "@/lib/availability"

export async function GET(req: Request, { params }: { params: { id: string } }) {
  const url = new URL(req.url)
  const serviceId = url.searchParams.get("serviceId")
  const date = url.searchParams.get("date")

  if (!serviceId || !date) return NextResponse.json({ error: "Missing params" }, { status: 400 })
  const slots = await getAvailableSlots({ salonId: params.id, serviceId, date })
  return NextResponse.json(slots.map(s => ({ start: s.start, end: s.end, staffId: s.staffId })))
}
