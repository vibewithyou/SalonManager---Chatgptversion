import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { serviceSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.ADMIN], (session.user as any).role)

  const salon = await prisma.salon.findUnique({ where: { id: params.id } })
  if (!salon) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if ((session.user as any).role !== "ADMIN" && salon.ownerId !== (session.user as any).id)
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const body = await req.json()
  const data = serviceSchema.parse({ ...body, salonId: params.id })
  const created = await prisma.service.create({ data })
  return NextResponse.json(created, { status: 201 })
}
