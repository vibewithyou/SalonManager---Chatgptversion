import { createUploadthing, type FileRouter } from "uploadthing/next"
import { prisma } from "@/lib/prisma"

const f = createUploadthing()

export const ourFileRouter = {
  imageUploader: f({ image: { maxFileSize: "10MB", maxFileCount: 10 } })
    .input(z => z.object({ salonId: z.string().cuid() }))
    .middleware(async ({ input }) => {
      // Option: RBAC prüfen (Owner des Salons) – Schritt 2 Middleware deckt Bereiche ab
      return { salonId: input.salonId }
    })
    .onUploadComplete(async ({ file, metadata }) => {
      // Speichere Bild als Media (type=IMAGE)
      await prisma.media.create({
        data: { salonId: metadata.salonId, type: "IMAGE", url: file.url, alt: file.name }
      })
      return { url: file.url }
    })
} satisfies FileRouter

export type OurFileRouter = typeof ourFileRouter
