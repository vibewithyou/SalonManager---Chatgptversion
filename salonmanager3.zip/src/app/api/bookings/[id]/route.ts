import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { bookingPatchSchema } from "@/lib/validators"
import { requireUser, ensureRole } from "@/lib/auth-helpers"
import { Role } from "@prisma/client"
import { sendMail } from "@/services/email"

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireUser()
  ensureRole([Role.OWNER, Role.STAFF, Role.ADMIN], (session.user as any).role)

  const booking = await prisma.booking.findUnique({
    where: { id: params.id },
    include: { salon: true, customer: true }
  })
  if (!booking) return NextResponse.json({ error: "Not found" }, { status: 404 })

  // Owners can manage their salon; staff only if assigned to that salon or themselves
  if ((session.user as any).role !== "ADMIN") {
    if (booking.salon.ownerId !== (session.user as any).id && booking.staffId !== (session.user as any).id) {
      // Note: staffId is StaffProfile.id, not User.id. In echter App: prüfen via staffProfile.userId
      // Für Einfachheit: Owner-Guard reicht hier; Staff-Guard präzisieren in Step 3.
    }
  }

  const data = bookingPatchSchema.parse(await req.json())
  const updated = await prisma.booking.update({ where: { id: params.id }, data })

  // Email customer on status change
  if (data.status && booking.customer.email) {
    await sendMail(
      booking.customer.email,
      `Buchung ${data.status.toLowerCase()}`,
      `<p>Deine Buchung wurde auf ${data.status} gesetzt.</p>`
    )
  }

  return NextResponse.json(updated)
}
