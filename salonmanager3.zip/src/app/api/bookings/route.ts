import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { bookingCreateSchema } from "@/lib/validators"
import { requireUser } from "@/lib/auth-helpers"
import { sendMail } from "@/services/email"

export async function GET(req: Request) {
  const session = await requireUser()
  const url = new URL(req.url)
  const mine = url.searchParams.get("mine") === "1"

  if (mine) {
    const list = await prisma.booking.findMany({
      where: { customerId: (session.user as any).id },
      include: { salon: true, service: true },
      orderBy: { start: "desc" }
    })
    return NextResponse.json(list)
  }
  // admin/staff/owner could get all — keep it simple: return forbidden for now
  return NextResponse.json({ error: "Forbidden" }, { status: 403 })
}

export async function POST(req: Request) {
  const session = await requireUser()
  const body = bookingCreateSchema.parse(await req.json())

  // compute end from service duration
  const svc = await prisma.service.findUnique({ where: { id: body.serviceId }, include: { salon: true } })
  if (!svc) return NextResponse.json({ error: "Service not found" }, { status: 404 })
  if (svc.salonId !== body.salonId) return NextResponse.json({ error: "Mismatch" }, { status: 400 })

  const end = new Date(body.start.getTime() + svc.durationMin * 60000)

  const created = await prisma.booking.create({
    data: {
      salonId: body.salonId,
      serviceId: body.serviceId,
      customerId: (session.user as any).id,
      start: body.start,
      end,
      note: body.note,
      imageUrl: body.imageUrl
    }
  })

  // Email notify owner (simple)
  if (svc.salon.email) {
    await sendMail(
      svc.salon.email,
      "Neue Buchungsanfrage",
      `<p>Neue Anfrage für ${svc.name} am ${body.start.toLocaleString()}.</p>`
    )
  }

  return NextResponse.json(created, { status: 201 })
}
