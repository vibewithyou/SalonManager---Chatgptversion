export default function Impressum() {
  return (
    <div className="prose prose-invert">
      <h1 className="text-gold">Impressum</h1>
      <p>Demo-Inhalt. Trage hier deine Anbieterkennzeichnung ein.</p>
    </div>
  )
}
