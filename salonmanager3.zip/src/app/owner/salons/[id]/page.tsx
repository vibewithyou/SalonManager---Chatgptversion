import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"
import Link from "next/link"

export default async function OwnerSalonDetail({ params }: { params: { id: string } }) {
  const session = await auth()
  if (!session?.user) return <div className="card">Bitte einloggen.</div>
  const salon = await prisma.salon.findUnique({
    where: { id: params.id },
    include: { services: true, openingHours: true, bookings: { include: { service: true, customer: true } } }
  })
  if (!salon) return <div className="card">Nicht gefunden</div>

  return (
    <div className="grid gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gold">{salon.name}</h1>
        <div className="text-sm text-muted">Slug: {salon.slug}</div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <section className="card">
          <h2 className="mb-2 font-medium">Stammdaten</h2>
          <dl className="grid grid-cols-3 gap-2 text-sm">
            <dt className="text-muted">Adresse</dt><dd className="col-span-2">{salon.address}, {salon.city}</dd>
            <dt className="text-muted">Koordinaten</dt><dd className="col-span-2">{salon.latitude},{salon.longitude}</dd>
            <dt className="text-muted">Status</dt><dd className="col-span-2">{salon.isPublished ? "Veröffentlicht" : "Entwurf"}</dd>
          </dl>
          <Link className="underline hover:text-gold text-sm" href={`/owner/salons/${salon.id}/edit`}>Bearbeiten</Link>
        </section>

        <section className="card">
          <h2 className="mb-2 font-medium">Leistungen</h2>
          <ul className="mb-3 grid gap-2">
            {salon.services.map(s=>(
              <li key={s.id} className="flex items-center justify-between border border-border rounded p-2">
                <div>{s.name}</div>
                <div className="text-gold">{(s.priceCents/100).toFixed(2)} € • {s.durationMin} min</div>
              </li>
            ))}
          </ul>
          <Link className="underline hover:text-gold text-sm" href={`/owner/salons/${salon.id}/services`}>Verwalten</Link>
        </section>

        <section className="card md:col-span-2">
          <h2 className="mb-2 font-medium">Buchungen (Letzte)</h2>
          <ul className="grid gap-2">
            {salon.bookings.slice(0,6).map(b=>(
              <li key={b.id} className="flex items-center justify-between border border-border rounded p-2 text-sm">
                <span>{new Date(b.start).toLocaleString()} – {b.service.name}</span>
                <span className={`badge ${b.status.toLowerCase()}`}>{b.status}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  )
}
