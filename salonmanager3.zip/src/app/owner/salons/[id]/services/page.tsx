import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"
import { revalidatePath } from "next/cache"

async function addService(_: any, formData: FormData) {
  "use server"
  const session = await auth()
  if (!session?.user) throw new Error("UNAUTHORIZED")
  const salonId = String(formData.get("salonId"))
  const name = String(formData.get("name"))
  const durationMin = Number(formData.get("durationMin"))
  const priceCents = Math.round(Number(formData.get("priceEuro")) * 100)
  await fetch(`${process.env.NEXTAUTH_URL}/api/salons/${salonId}/services`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ salonId, name, durationMin, priceCents })
  })
  revalidatePath(`/owner/salons/${salonId}/services`)
}

export default async function ServicesPage({ params }: { params: { id: string } }) {
  const session = await auth()
  if (!session?.user) return <div className="card">Bitte einloggen.</div>
  const salon = await prisma.salon.findUnique({ where: { id: params.id }, include: { services: true } })
  if (!salon) return <div className="card">Nicht gefunden</div>

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-semibold text-gold">Leistungen – {salon.name}</h1>
      <form action={addService.bind(null)} className="card grid gap-3 max-w-lg">
        <input type="hidden" name="salonId" value={salon.id} />
        <input className="input" name="name" placeholder="Name" required />
        <div className="grid grid-cols-2 gap-3">
          <input className="input" name="durationMin" type="number" placeholder="Dauer (Min.)" required />
          <input className="input" name="priceEuro" type="number" step="0.01" placeholder="Preis (€)" required />
        </div>
        <button className="btn">Hinzufügen</button>
      </form>
      <ul className="grid gap-2">
        {salon.services.map(s=>(
          <li key={s.id} className="card flex items-center justify-between">
            <div>{s.name}</div>
            <div className="text-gold">{(s.priceCents/100).toFixed(2)} € • {s.durationMin} min</div>
          </li>
        ))}
      </ul>
    </div>
  )
}
