import { PrismaClient, Role, BookingStatus } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  // Users
  const adminPass = await bcrypt.hash("Admin123!", 10)
  const ownerPass = await bcrypt.hash("Owner123!", 10)
  const staffPass = await bcrypt.hash("Staff123!", 10)
  const custPass  = await bcrypt.hash("Customer123!", 10)

  const admin = await prisma.user.upsert({
    where: { email: "admin@demo.tld" },
    update: {},
    create: { email: "admin@demo.tld", hashedPassword: adminPass, role: Role.ADMIN, name: "Admin" }
  })
  const owner = await prisma.user.upsert({
    where: { email: "owner@demo.tld" },
    update: {},
    create: { email: "owner@demo.tld", hashedPassword: ownerPass, role: Role.OWNER, name: "Owner One" }
  })
  const staffUser1 = await prisma.user.upsert({
    where: { email: "staff1@demo.tld" },
    update: {},
    create: { email: "staff1@demo.tld", hashedPassword: staffPass, role: Role.STAFF, name: "Staff One" }
  })
  const staffUser2 = await prisma.user.upsert({
    where: { email: "staff2@demo.tld" },
    update: {},
    create: { email: "staff2@demo.tld", hashedPassword: staffPass, role: Role.STAFF, name: "Staff Two" }
  })
  const customer = await prisma.user.upsert({
    where: { email: "customer@demo.tld" },
    update: {},
    create: { email: "customer@demo.tld", hashedPassword: custPass, role: Role.CUSTOMER, name: "Customer" }
  })

  // Tags
  const [barber, hair, nails] = await prisma.$transaction([
    prisma.tag.upsert({ where: { name: "Barber" }, update: {}, create: { name: "Barber" } }),
    prisma.tag.upsert({ where: { name: "Haare" }, update: {}, create: { name: "Haare" } }),
    prisma.tag.upsert({ where: { name: "Nägel" }, update: {}, create: { name: "Nägel" } })
  ])

  // Demo Salon
  const salon = await prisma.salon.create({
    data: {
      ownerId: owner.id,
      name: "BARBERs Freiberg",
      slug: "barbers-freiberg",
      description: "Moderner Barber-Salon im Herzen von Freiberg.",
      phone: "+49 123 456789",
      email: "contact@barbers-freiberg.tld",
      website: "https://barbers.example",
      address: "Hauptstraße 1",
      city: "Freiberg",
      postalCode: "09599",
      country: "DE",
      latitude: 50.9167,
      longitude: 13.35,
      isPublished: true,
      tags: { create: [{ tagId: barber.id }, { tagId: hair.id }] }
    }
  })

  // Services
  const [cut, shave] = await prisma.$transaction([
    prisma.service.create({ data: { salonId: salon.id, name: "Haarschnitt", durationMin: 30, priceCents: 2500 } }),
    prisma.service.create({ data: { salonId: salon.id, name: "Rasur", durationMin: 20, priceCents: 1800 } })
  ])

  // Staff profiles + schedules
  const sp1 = await prisma.staffProfile.create({
    data: { userId: staffUser1.id, salonId: salon.id, displayName: "Alex", bio: "Meister Barbier" }
  })
  const sp2 = await prisma.staffProfile.create({
    data: { userId: staffUser2.id, salonId: salon.id, displayName: "Sam", bio: "Stylist/in" }
  })

  const now = new Date()
  const dayMs = 24 * 60 * 60 * 1000
  for (let d = 0; d < 7; d++) {
    const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() + d, 9, 0, 0)
    // 9-17 Uhr verfügbar
    await prisma.schedule.create({
      data: { staffId: sp1.id, start: day, end: new Date(day.getTime() + 8 * 60 * 60 * 1000) }
    })
    await prisma.schedule.create({
      data: { staffId: sp2.id, start: day, end: new Date(day.getTime() + 8 * 60 * 60 * 1000) }
    })
    // Öffnungszeiten 9-18
    await prisma.openingHour.create({
      data: {
        salonId: salon.id,
        weekday: (day.getDay() + 6) % 7, // 0=So->6; 1=Mo->0 ...
        openTime: "09:00",
        closeTime: "18:00"
      }
    })
  }

  // Demo Booking (pending)
  await prisma.booking.create({
    data: {
      salonId: salon.id,
      serviceId: cut.id,
      customerId: customer.id,
      staffId: sp1.id,
      start: new Date(now.getTime() + dayMs + 10 * 60 * 1000),
      end: new Date(now.getTime() + dayMs + 40 * 60 * 1000),
      note: "Bitte mit Kontur",
      status: BookingStatus.PENDING
    }
  })
}

main().then(async () => {
  await prisma.$disconnect()
}).catch(async (e) => {
  console.error(e)
  await prisma.$disconnect()
  process.exit(1)
})
