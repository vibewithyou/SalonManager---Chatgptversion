import { NextResponse } from "next/server"
import { getSessionOrThrow } from "@/lib/user"
import { createCheckoutSession } from "@/services/stripe"

export async function POST() {
  const session = await getSessionOrThrow()
  const email = (session.user as any).email as string
  const url = await createCheckoutSession((session.user as any).id, email)
  return NextResponse.json({ url })
}
