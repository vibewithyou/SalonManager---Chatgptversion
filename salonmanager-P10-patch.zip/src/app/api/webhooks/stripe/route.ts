import { NextResponse } from "next/server"
import { stripe } from "@/services/stripe"
import { prisma } from "@/lib/prisma"

export async function POST(req: Request) {
  const sig = req.headers.get("stripe-signature") || ""
  const raw = await req.text()
  let evt: any
  try {
    evt = stripe.webhooks.constructEvent(raw, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 })
  }

  try {
    switch (evt.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const sub = evt.data.object
        const customerId = sub.customer as string
        const user = await prisma.user.findFirst({ where: { stripeCustomerId: customerId } })
        if (user) {
          await prisma.user.update({
            where: { id: user.id },
            data: {
              plan: sub.status === "canceled" ? "FREE" : "PRO",
              planStatus: sub.status,
              planCurrentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end * 1000) : null,
            }
          })
        }
        break
      }
      default:
        break
    }
  } catch (e) {
    // log if needed
  }

  return NextResponse.json({ ok: true })
}

// App Router: no need for bodyParser override here; we use req.text() above.
