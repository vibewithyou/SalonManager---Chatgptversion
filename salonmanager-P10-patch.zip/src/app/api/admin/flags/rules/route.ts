import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"
import { z } from "zod"

const ruleSchema = z.object({
  flagKey: z.string().min(1),
  role: z.string().optional().nullable(),
  userId: z.string().optional().nullable(),
  salonId: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  percentage: z.number().int().min(0).max(100).nullable().optional()
})

export async function POST(req: Request) {
  const session = await auth()
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const body = ruleSchema.parse(await req.json())
  const created = await prisma.flagRule.create({
    data: {
      flagKey: body.flagKey,
      role: body.role || null,
      userId: body.userId || null,
      salonId: body.salonId || null,
      city: body.city || null,
      percentage: body.percentage ?? null
    }
  })
  return NextResponse.json(created, { status: 201 })
}
