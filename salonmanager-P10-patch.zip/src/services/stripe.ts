import Stripe from "stripe"
import { prisma } from "@/lib/prisma"

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" })

export async function ensureCustomer(userId: string, email: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (user?.stripeCustomerId) return user.stripeCustomerId
  const c = await stripe.customers.create({ email })
  await prisma.user.update({ where: { id: userId }, data: { stripeCustomerId: c.id } })
  return c.id
}

export async function createCheckoutSession(userId: string, email: string) {
  const customer = await ensureCustomer(userId, email)
  const price = process.env.STRIPE_PRICE_MONTHLY!
  const trialDays = Number(process.env.STRIPE_TRIAL_DAYS || "0")
  const url = process.env.NEXTAUTH_URL!
  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer,
    line_items: [{ price, quantity: 1 }],
    success_url: `${url}/owner/salons?upgrade=success`,
    cancel_url: `${url}/owner/salons?upgrade=cancel`,
    subscription_data: trialDays ? { trial_period_days: trialDays } : undefined,
  })
  return session.url!
}
