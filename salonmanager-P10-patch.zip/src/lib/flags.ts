import { prisma } from "@/lib/prisma"
import { getRedis } from "./redis"

const MEM_CACHE = new Map<string, { v: boolean; ts: number }>()
const TTL = 30_000

// Base ON/OFF flag with in-memory + Redis + DB
export async function getFlag(key: string, fallback = false) {
  const now = Date.now()
  const m = MEM_CACHE.get(key)
  if (m && now - m.ts < TTL) return m.v

  const r = getRedis?.()
  if (r) {
    const rv = await r.get(`flag:${key}`)
    if (rv !== null) {
      const v = rv === "1"
      MEM_CACHE.set(key, { v, ts: now })
      return v
    }
  }
  const row = await prisma.featureFlag.findUnique({ where: { key } })
  const v = row?.enabled ?? fallback
  MEM_CACHE.set(key, { v, ts: now })
  if (r) await r.setex(`flag:${key}`, 60, v ? "1" : "0")
  return v
}

export async function setFlag(key: string, enabled: boolean, note?: string) {
  const row = await prisma.featureFlag.upsert({ where: { key }, create: { key, enabled, note }, update: { enabled, note } })
  const r = getRedis?.()
  if (r) await r.setex(`flag:${key}`, 60, enabled ? "1" : "0")
  MEM_CACHE.set(key, { v: enabled, ts: Date.now() })
  return row
}

type Ctx = { userId?: string; role?: string; salonId?: string; city?: string; seed?: string }

// Targeted evaluation: applies rules only if base flag is enabled
export async function evalFlag(key: string, ctx: Ctx = {}, fallback = false) {
  const base = await getFlag(key, fallback)
  if (!base) return false

  const r = getRedis?.()
  const cacheKey = `flagRules:${key}`
  let rules: any[] | null = null
  if (r) {
    const raw = await r.get(cacheKey)
    if (raw) rules = JSON.parse(raw)
  }
  if (!rules) {
    rules = await prisma.flagRule.findMany({ where: { flagKey: key } })
    if (r) await r.setex(cacheKey, 60, JSON.stringify(rules))
  }

  if (rules.length === 0) return base
  const seed = ctx.seed ?? ctx.userId ?? ctx.salonId ?? "0"
  const hash = simpleHash(seed) % 100

  for (const rule of rules) {
    if (rule.role && rule.role !== ctx.role) continue
    if (rule.userId && rule.userId !== ctx.userId) continue
    if (rule.salonId && rule.salonId !== ctx.salonId) continue
    if (rule.city && rule.city !== ctx.city) continue
    if (typeof rule.percentage === "number" && hash >= rule.percentage) continue
    return true
  }
  return false
}

function simpleHash(s: string) {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}
