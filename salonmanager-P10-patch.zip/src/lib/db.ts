import { PrismaClient } from "@prisma/client"

// Primary (writes)
export const prismaW = new PrismaClient()

// Optional read-replica (reads)
export const prismaR = process.env.DATABASE_READ_URL
  ? new PrismaClient({ datasources: { db: { url: process.env.DATABASE_READ_URL } } })
  : prismaW

export function db(readonly = false) {
  return readonly ? prismaR : prismaW
}
