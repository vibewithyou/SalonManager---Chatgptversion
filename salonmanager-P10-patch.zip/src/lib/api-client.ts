import { Zodios } from "@zodios/core"
import { api } from "./api-contract"

export const apiClient = new Zodios(api)
// Example usage (client):
// const res = await apiClient.get("/api/salons", { queries: { page: 1 } })
