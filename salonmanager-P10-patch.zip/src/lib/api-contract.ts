import { z } from "zod"
import { makeApi } from "@zodios/core"

export const Salon = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
  city: z.string(),
  address: z.string(),
  latitude: z.number(),
  longitude: z.number(),
})

export const SalonsList = z.object({
  total: z.number(),
  page: z.number(),
  pageSize: z.number(),
  items: z.array(Salon.extend({
    services: z.array(z.object({ priceCents: z.number() })).optional(),
    media: z.array(z.object({ url: z.string().url() })).optional(),
  })),
})

export const BookingCreate = z.object({
  salonId: z.string(),
  serviceId: z.string(),
  start: z.coerce.date(),
  note: z.string().optional(),
  imageUrl: z.string().url().optional(),
})

export const Booking = z.object({
  id: z.string(),
  salonId: z.string(),
  serviceId: z.string(),
  start: z.coerce.date(),
  end: z.coerce.date(),
  status: z.enum(["PENDING","CONFIRMED","DECLINED","CANCELLED"]),
})

export const api = makeApi([
  {
    method: "get",
    path: "/api/salons",
    alias: "listSalons",
    requestFormat: "json",
    parameters: [
      { name: "page", type: "Query", schema: z.coerce.number().optional() },
      { name: "pageSize", type: "Query", schema: z.coerce.number().optional() },
      { name: "sort", type: "Query", schema: z.enum(["new","priceAsc","priceDesc"]).optional() },
      { name: "query", type: "Query", schema: z.string().optional() },
    ],
    response: SalonsList,
  },
  {
    method: "post",
    path: "/api/bookings",
    alias: "createBooking",
    requestFormat: "json",
    parameters: [{ name: "body", type: "Body", schema: BookingCreate }],
    response: Booking,
  },
])
