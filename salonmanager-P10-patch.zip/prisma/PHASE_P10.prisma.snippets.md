```prisma
// --- Feature Flags with Targeting ---
model FeatureFlag {
  key        String   @id
  enabled    Boolean  @default(false)
  note       String?
  updatedAt  DateTime @updatedAt
  createdAt  DateTime @default(now())
  rules      FlagRule[]
}

model FlagRule {
  id         String   @id @default(cuid())
  flagKey    String
  flag       FeatureFlag @relation(fields: [flagKey], references: [key], onDelete: Cascade)
  // Targeting (AND-filters)
  role       String?   // "CUSTOMER" | "STAFF" | "OWNER" | "ADMIN"
  userId     String?
  salonId    String?
  city       String?
  percentage Int?      // 0..100 rollout
  createdAt  DateTime  @default(now())
  updatedAt  DateTime  @updatedAt

  @@index([flagKey, role, userId, salonId, city])
}

// --- User billing fields (Stripe) ---
model User {
  // ...existing fields...
  stripeCustomerId       String?
  plan                   String?   // "FREE" | "PRO"
  planStatus             String?   // "active" | "trialing" | "canceled" | "past_due"
  planCurrentPeriodEnd   DateTime?
}
```
