# Phase P10 — Targeted Flags, API Contracts, Stripe, k6, Read Replicas
Generated: 2025-08-16T14:42:44.223776Z

This bundle contains **new/changed files** for Phase P10 as drop-in patches.
Unzip at your repo root, then follow the steps below.

## Quick Apply
1) Unzip this archive at your project root.
2) Merge schema snippets from `prisma/PHASE_P10.prisma.snippets.md` into your `prisma/schema.prisma`.
3) Add env keys from `.env.example.snippet` to your environment/secrets.
4) Install deps:
   ```bash
   pnpm add @zodios/core @zodios/next stripe
   ```
5) Generate Prisma client & run your migration:
   ```bash
   pnpm prisma:generate
   pnpm prisma:migrate
   ```
6) (Optional) Add the k6 CI step from `ci-snippets/k6-ci-step.md`.
7) Restart dev/build.

## Included files
- `.env.example.snippet` — Stripe + read-replica envs to copy
- `prisma/PHASE_P10.prisma.snippets.md` — schema additions for flags targeting + user billing fields
- `src/lib/flags.ts` — base `getFlag/setFlag` + `evalFlag` with targeting and percentage rollout
- `src/app/api/admin/flags/rules/route.ts` — Admin API to create targeting rules
- `src/app/admin/flags/page.tsx` — Admin UI with basic toggle + targeting rule form
- `src/lib/api-contract.ts` — Zodios contracts (Salon listing, Booking create)
- `src/lib/api-client.ts` — Zodios client
- `src/services/stripe.ts` — Stripe helpers (ensure customer, create checkout session)
- `src/app/api/billing/checkout/route.ts` — starts a Stripe Checkout for subscription
- `src/app/api/webhooks/stripe/route.ts` — webhook handler to sync plan status
- `src/lib/db.ts` — Prisma read/write splitter with optional read-replica
- `tools/k6/search.js` and `tools/k6/booking.js` — load test scripts
- `tools/k6/README.md` — how to run k6 locally & in CI
- `ci-snippets/k6-ci-step.md` — CI example to run k6 via Docker

## Notes
- Imports assume your path aliases from earlier phases (e.g. `@/lib/prisma`, `@/auth`) exist.
- The Stripe webhook route expects **raw body**; the App Router route here uses `req.text()` and constructs the event manually.
- If you already have `src/app/admin/flags/page.tsx`, diff and merge the new “Targeting” section.
- If you run a read-replica, set `DATABASE_READ_URL`. Otherwise `db(true)` falls back to the primary.
