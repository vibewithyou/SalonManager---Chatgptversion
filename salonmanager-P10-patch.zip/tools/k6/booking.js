import http from "k6/http"
import { sleep } from "k6"

export const options = { vus: 10, duration: "30s" }

export default function () {
  const res = http.get(`${__ENV.BASE_URL || "http://localhost:3000"}/salon/barbers-freiberg`)
  if (res.status !== 200) throw new Error("ssr failed")
  sleep(0.5)
}
