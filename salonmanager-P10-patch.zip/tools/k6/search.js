import http from "k6/http"
import { sleep } from "k6"

export const options = {
  stages: [
    { duration: "15s", target: 20 },
    { duration: "30s", target: 50 },
    { duration: "30s", target: 0 },
  ],
}

export default function () {
  const url = `${__ENV.BASE_URL || "http://localhost:3000"}/api/salons?page=1&pageSize=12&sort=new`
  const res = http.get(url)
  if (res.status !== 200) {
    throw new Error("non-200")
  }
  sleep(1)
}
