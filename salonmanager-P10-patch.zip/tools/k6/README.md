# k6 Load Tests

Run locally via Docker:
```bash
docker run --rm --network host -e BASE_URL=http://localhost:3000 -v $PWD/tools/k6:/scripts grafana/k6 run /scripts/search.js
```

Or point at staging:
```bash
docker run --rm -e BASE_URL=https://staging.example.com -v $PWD/tools/k6:/scripts grafana/k6 run /scripts/booking.js
```
