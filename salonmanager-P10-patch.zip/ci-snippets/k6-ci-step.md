Add this job to your GitHub Actions workflow (after build & start):

```yml
  k6:
    needs: build-test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run k6 (via docker)
        run: |
          docker run --network host -e BASE_URL=http://localhost:3000 -v $PWD/tools/k6:/scripts grafana/k6 run /scripts/search.js
```
